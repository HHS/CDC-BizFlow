var p2wConditions = {

    //**Check Field for First Load check */
    checkField: {
        name: 'condEmpInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
        { name : 'PRE_EMP_PHYSICAL_REQUIRED', value: 'No' },
        { name : 'DRUG_TEST_REQUIRED', value: 'No' },
        { name : 'IMMUNIZATION_REQUIRED', value: 'No' },
        { name : 'MOBILITY_AGREEMENT_REQUIRED', value: 'No' },            
        { name : 'FINANCIAL_DISCLOSURE_REQUIRED', value: 'No' },
        { name : 'LICENSE_REQUIRED', value: 'No' },
        { name : 'TRAVEL_REQUIRED', value: 'No' },
        { name : 'MOVING_EXPENSES_AUTHORIZED', value: 'No' },
        { name : 'RELOCATION_INCENTIVE_AUTHORIZED', value: 'No' },
        { name : 'RECRUITMENT_INCENTIVE_AUTHORIZED', value: 'No' },
        { name : 'STUDENT_LOAN_REPAYMENT_AUTHORIZED', value: 'No' },
        { name : 'ANNUAL_LEAVE_FOR_NON_FEDERAL_SERVICE', value: 'No' },
        { name : 'LANGUAGE_REQUIRED', value: 'No' },
        { name : 'OTHER_CONDITIONS', value: '' },
        { name : 'OTHER_INCENTIVES', value: '' },
        { name : 'LANGUAGE', value: '' },		 // defect 20632
        { name : 'FINANCIAL_STATEMENT', value: '' }		 // defect 
    ],
    // Init function/method called from On PageLoad; performs
	// various activities to setup the page UI, hide/show fields
	init: function() {
		
        // PETER START
		/* // defect 20632 -  uncommented this block
        $("input[type=checkbox][name=LANGUAGES_SELECTED]").filter(function(){ return $(this).prop("checked"); }).parent().parent().show();
        $("input[type=checkbox][name=LANGUAGES_SELECTED]").filter(function(){ return !$(this).prop("checked"); }).parent().parent().hide();
		*/
        // This will be added into FormState
		/* defect 20632 - uncommented this block
        $('input[type=checkbox]').on('click', function (e) {
            var checked = $('#' + e.target.id).prop('checked');
            FormState.doAction(StateAction.changeCheckbox(e.target.id, checked));
        });*/       
        // PETER END
		
		
    },

    //setRadioDefaultValue: function(id, value){
    //	FormState.doAction(StateAction.changeRadio(id, value), false);       
    //},
    
	setSelectDefaultValue: function(id, value){
    	FormState.doAction(StateAction.changeSelect(id, value), false);       
    },
	
	setTextDefaultValue: function(id, value){
		FormState.doAction(StateAction.changeText(id, value), false); 
	},
    renderSelectedLanguage: function() {
		
		var langObj = $("#LANGUAGE option");
		var noOfLangs = langObj.length;
		
        for (var index = 1; index <= noOfLangs; index++) {
            var elementID = 'LANGUAGES_SELECTED' + index;
            var selectedLanguageCheckBox = FormState.getState(elementID);
            if (selectedLanguageCheckBox && selectedLanguageCheckBox.dirty === true) {
				if (selectedLanguageCheckBox.value === 'true') {
					$('#' + elementID).parent().parent().show();
				} else {
					$('#' + elementID).parent().parent().hide();
				}
            }
        }
    },
    renderer: function(){
		
        console.log("p2wConditionsOfEmployment renderer Start");
        var self = this;
        CDCCommon.setupFirstLoad(self.checkField, self.fields);

        // PETER START
/*      // defect 20632 - uncommented this block
		var language = FormState.getState('LANGUAGE');
        if (language && language.dirty == true && language.value !== '') {
            var selectedLangCheckBox = $("input[type=checkbox][name=LANGUAGES_SELECTED][value=" + language.value + "]");
            // selectedLangCheckBox.prop('checked', true); 
            // selectedLangCheckBox.parent().parent().show();
            var elementID = selectedLangCheckBox.attr('id');
            FormState.doAction(StateAction.changeCheckbox(elementID, 'true'),false);
            FormState.doAction(StateAction.changeSelect('LANGUAGE', '',''), false); // Clear out Language select box
        }
*/
        //p2wConditions.renderSelectedLanguage();     
           
        // PETER END

		// defect 20632 -- added 
        CDCCommon.renderDisplay('LANGUAGES', '#langList');
        CDCCommon.renderDisplay('FINANCIAL_STATEMENTS', '#fsList');		
		$("#LANGUAGE option[value='']").attr('selected', true);
		//p2wConditions.setSelectDefaultValue('LANGUAGE','Select One');

        var langRFrmState = FormState.getState('LANGUAGE_REQUIRED');		
        $("#LANGUAGE").on('change', function(e) {
            CDCCommon.addData('LANGUAGES', $('#LANGUAGE option:selected').text(), '#langList');
			//FormState.doAction(StateAction.changeSelect('LANGUAGE', '',''), false); // Clear out Language select box
            var formState = FormState.getState('LANGUAGES');
			/*
            if (formState && (formState.value).length > 2) {
                $('#LANGUAGE').val('').attr('_required', false);
            }*/
			$("#LANGUAGE option[value='']").attr('selected', true);
			//p2wConditions.setSelectDefaultValue('LANGUAGE','');
			if( langRFrmState.value==='Yes'){
				if (formState && (formState.value)==undefined) {            					
					//$('#LANGUAGE').val('').attr('_required', true);
					CDCCommon.addRequired('LANGUAGE');
				}
				else{
					//$('#LANGUAGE').val('').attr('_required', false);
					CDCCommon.removeRequired('LANGUAGE');					
				}
			}
			else{
				//$('#LANGUAGE').val('').attr('_required', false);	
				CDCCommon.removeRequired('LANGUAGE');
			}
        });
		
        $('#group_bordered').on('click', '.js-LANGUAGES-delete', function(e) {
            e.preventDefault();
            CDCCommon.removeData('LANGUAGES', $(this).data("item"), '#langList');
            var formState = FormState.getState('LANGUAGES');
            //if (formState && (formState.value).length < 2) {
			/*
			if (formState && ((formState.value)==undefined ||(formState.value)==='' )) {            	
                $('#LANGUAGE').attr('_required', true);
            }*/
			if( langRFrmState.value==='Yes'){
				if (formState && (formState.value)==undefined) {            					
					//$('#LANGUAGE').val('').attr('_required', true);
					CDCCommon.addRequired('LANGUAGE');					
				}
				else{
					//$('#LANGUAGE').val('').attr('_required', false);
					CDCCommon.removeRequired('LANGUAGE');					
				}
			}
			else{
				//$('#LANGUAGE').val('').attr('_required', false);
				CDCCommon.removeRequired('LANGUAGE');				
			}
        });
		
        var fdrFrmState = FormState.getState('FINANCIAL_DISCLOSURE_REQUIRED');
        $("#FINANCIAL_STATEMENT").on('change', function(e) {
            CDCCommon.addData('FINANCIAL_STATEMENTS', $('#FINANCIAL_STATEMENT option:selected').text(), '#fsList');
            var formState = FormState.getState('FINANCIAL_STATEMENTS');
			$("#FINANCIAL_STATEMENT option[value='']").attr('selected', true);			
			//p2wConditions.setSelectDefaultValue('FINANCIAL_STATEMENT','');
            //if (formState && (formState.value).length > 2) {
			if( fdrFrmState.value==='Yes'){
				if (formState && (formState.value)==undefined) {            					
					//$('#FINANCIAL_STATEMENT').val('').attr('_required', true);
					CDCCommon.addRequired('FINANCIAL_STATEMENT');					
				}
				else{
					//$('#FINANCIAL_STATEMENT').val('').attr('_required', false);
					CDCCommon.removeRequired('FINANCIAL_STATEMENT');					
				}
			}
			else{
				//$('#FINANCIAL_STATEMENT').val('').attr('_required', false);
				CDCCommon.removeRequired('FINANCIAL_STATEMENT');				
			}
        });
		
        $('#group_bordered').on('click', '.js-FINANCIAL_STATEMENTS-delete', function(e) {
            e.preventDefault();
            CDCCommon.removeData('FINANCIAL_STATEMENTS', $(this).data("item"), '#fsList');
            var formState = FormState.getState('FINANCIAL_STATEMENTS');
            //if (formState && (formState.value).length < 2) {
			/*if (formState && ((formState.value)==undefined ||(formState.value)==='' )) {            	
                $('#FINANCIAL_STATEMENT').attr('_required', true);
            }*/
			if( fdrFrmState.value==='Yes'){
				if (formState && (formState.value)==undefined) {            					
					$('#FINANCIAL_STATEMENT').val('').attr('_required', true);
				}
				else{
					//$('#FINANCIAL_STATEMENT').val('').attr('_required', false);
					CDCCommon.removeRequired('FINANCIAL_STATEMENT');					
				}
			}
			else{
					//$('#FINANCIAL_STATEMENT').val('').attr('_required', false);
					CDCCommon.removeRequired('FINANCIAL_STATEMENT');					

			}
        });		
        
		//Show Hide Financial Information
		if (fdrFrmState){
			var formState = FormState.getState('FINANCIAL_STATEMENTS');	
			// This condition handles the page load scenario
			if (formState && (formState.value)!=undefined) {
				//$('#FINANCIAL_STATEMENT').val('').attr('_required', false);
				CDCCommon.removeRequired('FINANCIAL_STATEMENT');						
				if(fdrFrmState.dirty === true) {
					if(fdrFrmState.value === 'Yes'){
						hyf.util.showComponent('FINANCIAL_STATEMENT_GROUP');
						hyf.util.showComponent('FS_DISPLAY_DIV');				
						//hyf.util.showComponent('FINANCIAL_STATEMENT');
					} else {
						hyf.util.hideComponent('FINANCIAL_STATEMENT_GROUP');
						hyf.util.hideComponent('FS_DISPLAY_DIV');		
						//hyf.util.hideComponent('FINANCIAL_STATEMENT');
						resetSelections('FINANCIAL_STATEMENTS',formState,'#fsList');
					}
				}else{
					if(fdrFrmState.value === 'Yes'){
						hyf.util.showComponent('FINANCIAL_STATEMENT_GROUP');
						hyf.util.showComponent('FS_DISPLAY_DIV');				
						//hyf.util.showComponent('FINANCIAL_STATEMENT');
					} else {
						hyf.util.hideComponent('FINANCIAL_STATEMENT_GROUP');
						hyf.util.hideComponent('FS_DISPLAY_DIV');		
						//hyf.util.hideComponent('FINANCIAL_STATEMENT');
						resetSelections('FINANCIAL_STATEMENTS',formState,'#fsList');
						
					}			
				}
			}
			else{
				//This condition handles the scenario when the user starts making changes to the original inputs 
				if(fdrFrmState.dirty === true) {
					if(fdrFrmState.value === 'Yes'){
						hyf.util.showComponent('FINANCIAL_STATEMENT_GROUP');
						hyf.util.showComponent('FS_DISPLAY_DIV');				
						//hyf.util.showComponent('FINANCIAL_STATEMENT');
						//$('#FINANCIAL_STATEMENT').val('').attr('_required', true);
						CDCCommon.addRequired('FINANCIAL_STATEMENT');
					} else {
						hyf.util.hideComponent('FINANCIAL_STATEMENT_GROUP');
						hyf.util.hideComponent('FS_DISPLAY_DIV');		
						//hyf.util.hideComponent('FINANCIAL_STATEMENT');
						//$('#FINANCIAL_STATEMENT').val('').attr('_required', false);
						CDCCommon.removeRequired('FINANCIAL_STATEMENT');				
					}
				}else{
					if(fdrFrmState.value === 'Yes'){
						hyf.util.showComponent('FINANCIAL_STATEMENT_GROUP');
						hyf.util.showComponent('FS_DISPLAY_DIV');				
						//hyf.util.showComponent('FINANCIAL_STATEMENT');
						//$('#FINANCIAL_STATEMENT').val('').attr('_required', true);
						CDCCommon.addRequired('FINANCIAL_STATEMENT');	
					} else {
						hyf.util.hideComponent('FINANCIAL_STATEMENT_GROUP');
						hyf.util.hideComponent('FS_DISPLAY_DIV');		
						//hyf.util.hideComponent('FINANCIAL_STATEMENT');
						//$('#FINANCIAL_STATEMENT').val('').attr('_required', false);
						CDCCommon.removeRequired('FINANCIAL_STATEMENT');				
					}			
				}		
				
			}
		}
        
    	//Show Hide License Information
    	var lrFrmState = FormState.getState('LICENSE_REQUIRED');                      
        if (lrFrmState && lrFrmState.dirty === true) {       
            if(lrFrmState.value === 'Yes'){
                hyf.util.showComponent('LICENSE_REQUIRED_GROUP');
            } else {
                FormState.doAction(StateAction.changeText('LICENSE_INFO', ''), false);
                hyf.util.hideComponent('LICENSE_REQUIRED_GROUP');
            }
        }

		//Show Hide Travel Information
    	var trFrmState = FormState.getState('TRAVEL_REQUIRED');    
        if (trFrmState && trFrmState.dirty === true) {        
            if(trFrmState.value === 'Yes'){
                hyf.util.showComponent('DOMESTIC_TRAVEL_PERCENTAGE_GROUP');
                hyf.util.showComponent('INTERNATIONAL_TRAVEL_PERCENTAGE_GROUP');
            } else {
                FormState.doAction(StateAction.changeText('DOMESTIC_TRAVEL_PERCENTAGE', ''), false);
                hyf.util.hideComponent('DOMESTIC_TRAVEL_PERCENTAGE_GROUP');
                FormState.doAction(StateAction.changeText('INTERNATIONAL_TRAVEL_PERCENTAGE', ''), false);
                hyf.util.hideComponent('INTERNATIONAL_TRAVEL_PERCENTAGE_GROUP');
            }
        }        
        
        //Show Hide Language Required
        if (langRFrmState){
			var formState = FormState.getState('LANGUAGES');
			// This condition handles the page load scenario
			if (formState && (formState.value)!=undefined) {
				//$('#LANGUAGE').val('').attr('_required', false);
				CDCCommon.removeRequired('LANGUAGE');				
				if(langRFrmState.dirty == true) {
					if(langRFrmState.value === 'Yes'){
						hyf.util.showComponent('LANGUAGE_REQUIRED_GROUP');
						hyf.util.showComponent('LANGUAGES_SELECTED_GROUP');
						hyf.util.showComponent('LANGUAGES_DISPLAY_DIV');
					} else {
						hyf.util.hideComponent('LANGUAGE_REQUIRED_GROUP');
						hyf.util.hideComponent('LANGUAGES_SELECTED_GROUP');
						hyf.util.hideComponent('LANGUAGES_DISPLAY_DIV');
						resetSelections('LANGUAGES',formState,'#langList' );		
					}
				}else{
					if(langRFrmState.value === 'Yes'){
						hyf.util.showComponent('LANGUAGE_REQUIRED_GROUP');
						hyf.util.showComponent('LANGUAGES_SELECTED_GROUP');
						hyf.util.showComponent('LANGUAGES_DISPLAY_DIV');
					} else {
						hyf.util.hideComponent('LANGUAGE_REQUIRED_GROUP');
						hyf.util.hideComponent('LANGUAGES_SELECTED_GROUP');
						hyf.util.hideComponent('LANGUAGES_DISPLAY_DIV');
						resetSelections('LANGUAGES',formState,'#langList' );		
					}
				}
			}
			else{
				if(langRFrmState.dirty == true) {
					if(langRFrmState.value === 'Yes'){
						hyf.util.showComponent('LANGUAGE_REQUIRED_GROUP');
						hyf.util.showComponent('LANGUAGES_SELECTED_GROUP');
						hyf.util.showComponent('LANGUAGES_DISPLAY_DIV');
						//$('#LANGUAGE').val('').attr('_required', true);
						CDCCommon.addRequired('LANGUAGE');						
					} else {
						hyf.util.hideComponent('LANGUAGE_REQUIRED_GROUP');
						hyf.util.hideComponent('LANGUAGES_SELECTED_GROUP');
						hyf.util.hideComponent('LANGUAGES_DISPLAY_DIV');
						//$('#LANGUAGE').val('').attr('_required', false);
						CDCCommon.removeRequired('LANGUAGE');						
					}
				}else{
					if(langRFrmState.value === 'Yes'){
						hyf.util.showComponent('LANGUAGE_REQUIRED_GROUP');
						hyf.util.showComponent('LANGUAGES_SELECTED_GROUP');
						hyf.util.showComponent('LANGUAGES_DISPLAY_DIV');
						//$('#LANGUAGE').val('').attr('_required', true);
						CDCCommon.addRequired('LANGUAGE');						
					} else {
						hyf.util.hideComponent('LANGUAGE_REQUIRED_GROUP');
						hyf.util.hideComponent('LANGUAGES_SELECTED_GROUP');
						hyf.util.hideComponent('LANGUAGES_DISPLAY_DIV');
						//$('#LANGUAGE').val('').attr('_required', false);
						CDCCommon.removeRequired('LANGUAGE');
					}
				}
			}
		}// end if langRFrmState
		
		function resetSelections(node,formStateInstance, elementID  ){
			var formStateInstanceVal = formStateInstance.value;	
			var formStateInstanceValArr = formStateInstanceVal.split('::');
				for( var j= 0; j < formStateInstanceValArr.length; j++){
					console.log("Removing selected element :  " + j);
					CDCCommon.removeData(node, formStateInstanceValArr[j], elementID); // Defect 20972			
				}
				console.log("All selections reset!");
		}
        console.log("p2wConditionsOfEmployment renderer End");
	}
	
}