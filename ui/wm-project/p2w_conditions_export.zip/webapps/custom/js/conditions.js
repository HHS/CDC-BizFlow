var p2wConditions = {

    //**Flag for indicating whether InitSetup is done or not  */
    initSetupDone: false,

    //**Array of object to hold financialStaementList, used for multi-value field */
    financialStatementList: [],

    languageList: [],

    //**Check Field for First Load check */
    checkField: {
        name: 'condEmpInitComplete',
        value: 'true'
	},
	
    //**Default values for First Load Fields */
    fields: [
        { name : 'PRE_EMP_PHYSICAL_REQUIRED', value: 'No' },
        { name : 'DRUG_TEST_REQUIRED', value: 'No' },
        { name : 'IMMUNIZATION_REQUIRED', value: 'No' },
        { name : 'MOBILITY_AGREEMENT_REQUIRED', value: 'No' },            
        { name : 'FINANCIAL_DISCLOSURE_REQUIRED', value: 'No' },
        { name : 'LICENSE_REQUIRED', value: 'No' },
        { name : 'TRAVEL_REQUIRED', value: 'No' },
        { name : 'MOVING_EXPENSES_AUTHORIZED', value: 'No' },
        { name : 'RELOCATION_INCENTIVE_AUTHORIZED', value: 'No' },
        { name : 'RECRUITMENT_INCENTIVE_AUTHORIZED', value: 'No' },
        { name : 'STUDENT_LOAN_REPAYMENT_AUTHORIZED', value: 'No' },
        { name : 'ANNUAL_LEAVE_FOR_NON_FEDERAL_SERVICE', value: 'No' },
        { name : 'LANGUAGE_REQUIRED', value: 'No' },
        { name : 'OTHER_CONDITIONS', value: '' },
        { name : 'OTHER_INCENTIVES', value: '' },
        { name : 'LANGUAGE', value: '' },		 // defect 20632
        { name : 'LANGUAGES', value: '' },		 // defect 20632
        { name : 'FINANCIAL_STATEMENT', value: '' },		 // defect 
        { name : 'FINANCIAL_STATEMENTS', value: '' }		 // defect 
	],
	
    //**Function for initial setup when the form is loaded */
    initSetup: function() {
        var self = this;

        var fsFieldState = FormState.getState('FINANCIAL_STATEMENTS');
        //CDCCommon.renderDisplay('FINANCIAL_STATEMENTS', '#fsList', self.financialStatementList);  **Done in Renderer as there is a dependency for display 
        if (fsFieldState && fsFieldState.value) {
            CDCCommon.hideField('FINANCIAL_STATEMENT', true);
            CDCCommon.showField('FINANCIAL_STATEMENT');
        }
        FormState.doAction(StateAction.changeSelect('FINANCIAL_STATEMENT', self.financialStatementList[0].value), false);

        var clFieldState = FormState.getState('LANGUAGES');
        //CDCCommon.renderDisplay('LANGUAGES', '#langList'); **Done in Rendered as there is a dependency for display
        if (clFieldState && clFieldState.value) {
            CDCCommon.hideField('LANGUAGE', true);
            CDCCommon.showField('LANGUAGE');
        }
        FormState.doAction(StateAction.changeSelect('LANGUAGE', self.languageList[0].value), false);
    },

    //**Mappers for Autocomplete */
    mappers: {
        DUMMY: function() {
            return {
                _dummy: ""
            };
        }
    },

    //**OnBlur handler for Autocomplete */
    reduxBindFix: function() {
        var control = $(this);
        if (control.hasClass('js-autocomplete')) {
            FormState.doAction(StateAction.changeText(control.attr('id'), control.val()), false);
        }
    },
	
    //**  Init function/method called from On PageLoad; performs various activities to setup the page UI, hide/show fields */
    init: function() {
        var self = this;
        $('#FINANCIAL_STATEMENT > option').each(function() {
            self.financialStatementList.push({
                value: $(this).val(),
                text: $(this).text()
            });
        });
        $('#LANGUAGE > option').each(function() {
            self.languageList.push({
                value: $(this).val(),
                text: $(this).text()
            });
        });
        $("#ADD_FS").on('click', function(e) {
            var fieldState = FormState.getState('FINANCIAL_STATEMENT');
            if (fieldState.value) {
                CDCCommon.addData('FINANCIAL_STATEMENTS', fieldState.text, '#fsList', self.financialStatementList);
                FormState.doAction(StateAction.changeSelect('FINANCIAL_STATEMENT', self.financialStatementList[0].value), true);
                CDCCommon.hideField('FINANCIAL_STATEMENT', true);
                CDCCommon.showField('FINANCIAL_STATEMENT');
                $('#FINANCIAL_STATEMENT').focus();
            }
        });
        $('#group_bordered').on('click', '.js-FINANCIAL_STATEMENTS-delete', function(e) {
            e.preventDefault();
            CDCCommon.removeData('FINANCIAL_STATEMENTS', $(this).data("item"), '#fsList', self.financialStatementList);
            var fieldState = FormState.getState('FINANCIAL_STATEMENTS');
            if (fieldState && (!fieldState.value || (fieldState.value).length === 0)) {
                CDCCommon.hideField('FINANCIAL_STATEMENT');
                CDCCommon.showField('FINANCIAL_STATEMENT', true);
            }
        });
        $("#ADD_LANG").on('click', function(e) {
            CDCCommon.addData('LANGUAGES', $('#LANGUAGE').val(), '#langList', self.languageList);
            FormState.doAction(StateAction.changeSelect('LANGUAGE', self.languageList[0].value), true);
            CDCCommon.hideField('LANGUAGE', true);
            CDCCommon.showField('LANGUAGE');
            $('#LANGUAGE').focus();
        });
        $('#group_bordered').on('click', '.js-LANGUAGES-delete', function(e) {
            e.preventDefault();
            CDCCommon.removeData('LANGUAGES', $(this).data("item"), '#langList', self.languageList);
            var fieldState = FormState.getState('LANGUAGES');
            if (fieldState && (!fieldState.value || (fieldState.value).length === 0)) {
                CDCCommon.hideField('LANGUAGE');
                CDCCommon.showField('LANGUAGE', true);
            }
        });

        CDCCommon.setAutoComplete('group_bordered', self.mappers, self.reduxBindFix);
    },

    //**Rendered method that is called everytime there is a field change by Redux Form */
	renderer: function() {
        console.log("p2wConditionsOfEmployment renderer Start");
        var self = this;
        CDCCommon.setupFirstLoad(self.checkField, self.fields);
        if (!self.initSetupDone) {
            self.initSetup();
        }
        self.actionOnChange('FINANCIAL_DISCLOSURE_REQUIRED');
        self.actionOnChange('LICENSE_REQUIRED');
        self.actionOnChange('TRAVEL_REQUIRED');
        self.actionOnChange('LANGUAGE_REQUIRED');
        self.initSetupDone = true;

        console.log("p2wConditionsOfEmployment renderer End");
	},

    //**Called from rendered when specific field(s) are changed */
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        if (fieldState && (fieldState.dirty || !self.initSetupDone)) {
            switch (field) {
                case 'FINANCIAL_DISCLOSURE_REQUIRED':
                    if (fieldState.value === 'Yes') {
                        var fsFieldState = FormState.getState('FINANCIAL_STATEMENTS')
                        CDCCommon.showField('FINANCIAL_STATEMENT', !(fsFieldState && fsFieldState.value));
                        $('#ADD_FS').removeClass('hidden');
                    } else {
                        CDCCommon.hideField('FINANCIAL_STATEMENT', true);
                        $('#ADD_FS').addClass('hidden');
                        $('#FINANCIAL_STATEMENT_DISPLAY').addClass('hidden');
                        if (self.initSetupDone) {
                            FormState.doAction(StateAction.changeText('FINANCIAL_STATEMENTS', ''), false);
                        }
                    }
                    CDCCommon.renderDisplay('FINANCIAL_STATEMENTS', '#fsList', self.financialStatementList);
                    break;
				case 'LICENSE_REQUIRED':
                    if (fieldState.value === 'Yes') {
                        CDCCommon.showField('LICENSE_INFO', true);
                    } else {
                        CDCCommon.hideField('LICENSE_INFO', true, '');
                    }
                    break;
				case 'TRAVEL_REQUIRED':
                    if (fieldState.value === 'Yes') {
                        CDCCommon.showField('DOMESTIC_TRAVEL_PERCENTAGE', true);
                        CDCCommon.showField('INTERNATIONAL_TRAVEL_PERCENTAGE', true);
                    } else {
                        CDCCommon.hideField('DOMESTIC_TRAVEL_PERCENTAGE', true, '');
                        CDCCommon.hideField('INTERNATIONAL_TRAVEL_PERCENTAGE', true, '');
                    }
                    break;
				case 'LANGUAGE_REQUIRED':
                    if (fieldState.value === 'Yes') {
                        var langFieldState = FormState.getState('LANGUAGES')
                        CDCCommon.showField('LANGUAGE', !(langFieldState && langFieldState.value));
                        $('#ADD_LANG').removeClass('hidden');
                    } else {
                        CDCCommon.hideField('LANGUAGE', true);
                        $('#ADD_LANG').addClass('hidden');
                        $('#LANGUAGE_DISPLAY').addClass('hidden');
                        if (self.initSetupDone) {
                            FormState.doAction(StateAction.changeText('LANGUAGES', ''), false);
                        }
                    }
                    CDCCommon.renderDisplay('LANGUAGES', '#langList', self.languageList);
                    break;
            }
        }
    }
	
}