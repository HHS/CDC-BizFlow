var p2wPosition = {

    //**For storing Grade List */
    gradeList: [],
    //**For storing Appointment Type List */
    appointmentTypeList: [],
    //**For storing Area of Consideration List */
    aocList: [],
    //**For storing Work Schedule List */
    workScheduleList: [],
    //**Flag indicating whether initialization is done or not; needed for renderer function, otherwise it calls init section all the time */
    initSetupDone: false,
    //**Check Field for First Load check */
    checkField: {
        name: 'posInitComplete',
        value: 'true'
    },
    dutyStations: [],
    //**Default values for First Load Fields */
    fields: [
        { name: 'POS_JOB_REQ_NUM', value: '' },
        { name: 'POS_TITLE', value: '' },
        { name: 'POS_TITLES_SERIES', value: '' },
        { name: 'POS_FUNCTIONAL_TITLE', value: '' },
        { name: 'POS_PAY_PLAN_CODE', value: '' },
        { name: 'POS_SERIES', value: '' },
        { name: 'POS_GRADE_ID', firstValue: true },
        { name: 'POS_GRADE_IDS', value: '' },
        { name: 'POS_IS_PROMOTIONAL', firstValue: true },
        { name: 'POS_SENSITIVITY_ID', firstValue: true },
        { name: 'POS_SUPERVISORY_OR_NOT', firstValue: true },
        { name: 'POS_CAN', value: '' },
        { name: 'POS_IS_BF_OR_VICE', firstValue: true },
        { name: 'POS_BF_VICE_NAME', firstValue: true },
        { name: 'POS_NO_BF_VICE_RSN', value: '' },
        { name: 'POS_DUTY_STATION', value: '' },
        { name: 'POS_DUTY_STATIONS', value: '' },
        { name: 'POS_NUM_VACANCIES', value: '' },
        { name: 'POS_APPT_TYPE_ID', firstValue: true },
        { name: 'POS_NTE', value: '' },
        { name: 'POS_AOC', firstValue: true },
        { name: 'POS_MP_TYPE', firstValue: true },
        { name: 'POS_DE_TYPE', firstValue: true },
        { name: 'POS_PATHWAY_TYPE', firstValue: true },
        { name: 'POS_AOC_1', firstValue: true },
        { name: 'POS_MP_TYPE_1', firstValue: true },
        { name: 'POS_DE_TYPE_1', firstValue: true },
        { name: 'POS_NAME_REQUEST', value: '' },
        { name: 'POS_IS_OPEN_CONTINUOUS', firstValue: true },
        { name: 'POS_DAYS_TO_ADVERTISE', value: '' },
        { name: 'POS_WORK_SCHED', firstValue: true },
        { name: 'POS_HOURS_PER_WEEK', value: '' },
        { name: 'POS_REMARKS', value: '' }
    ],

    //**Function to get Hiring Method: Potential Output's Title5, Title42, SES/SL */
    getHiringMethod: function(fieldState) {
        var self = this;
        var hiringMethod = '';
        if (!fieldState) {
            fieldState = FormState.getState('HM_ID');
        }
        if (fieldState && fieldState.text) {
            if (fieldState.text.indexOf('Title 5') === 0) {
                hiringMethod = 'Title5';
            } else if (fieldState.text.indexOf('Title 42') === 0) {
                hiringMethod = 'Title42';
            } else if (fieldState.text.indexOf('SES/SL') === 0) {
                hiringMethod = 'SES/SL';
            }
        }
        return hiringMethod;
    },

    //**Function to reset inUseByMain Flag and Full Performance Level */
    resetFPL: function() {
        var self = this;

        var fplFieldState = FormState.getState('POS_FULL_PERF_LEVEL');

        var gradesFieldState = FormState.getState('POS_GRADE_IDS');
        var selectedGrades = [];
        if (gradesFieldState && gradesFieldState.value && gradesFieldState.value !== '') {
            var grades = gradesFieldState.value.split('::');
            for (var i = 0; i < grades.length; i++) {
                selectedGrades.push(grades[i]);
            }   
        }

        var fplDropDown = $("#POS_FULL_PERF_LEVEL");
        fplDropDown.find('option').remove();
        fplDropDown.append('<option value="">Select One</option>');
        var value = '';
        if (selectedGrades.length !== 0) {
            var minFPLStartLocation = 0;
            for (var i = 0; i < self.gradeList.length; i++) {
                if (self.gradeList[i].value !== '') {
                    if (CDCCommon.searchArray(selectedGrades, self.gradeList[i].value).index !== -1) {
                        if (minFPLStartLocation < i) minFPLStartLocation = i;
                    }
                }
            }

            for (var i = minFPLStartLocation; i < self.gradeList.length; i++) {
                if (self.gradeList[i].value !== '' && self.gradeList[i].text !== '00') {
                    fplDropDown.append('<option value="' + self.gradeList[i].value + '">' + self.gradeList[i].text + '</option>');
                }
            }
            if (!self.initSetupDone) {
                if (fplFieldState && fplFieldState.value) {
                    value = fplFieldState.value;
                }
            }
        }
        FormState.doAction(StateAction.changeSelect('POS_FULL_PERF_LEVEL', value), false);
    },

    setGradesDropDown: function(hiringMethod) {
        var self = this;
        var grDropDown = $("#POS_GRADE_ID");
        var selectedGrades = FormState.getState('POS_GRADE_IDS');
        var selectedGradesArray = [];
        if (selectedGrades && selectedGrades.value && selectedGrades.value !== '') {
            selectedGradesArray = selectedGrades.value.split("::");
        }
        grDropDown.find('option').remove();
        for(var i = 0; i < self.gradeList.length; i++) {
            var add = false;
            if (self.gradeList[i].value === '') {
                add = true;
            }
            else {
                switch (hiringMethod) {
                    case 'Title5':
                        if (self.gradeList[i].text !== '00') {
                            add = CDCCommon.searchArray(selectedGradesArray, self.gradeList[i].value).index === -1;
                        }
                        break;
                    case 'Title42':
                    case 'SES/SL':
                        if (self.gradeList[i].text === '00') {
                            add = CDCCommon.searchArray(selectedGradesArray, self.gradeList[i].value).index === -1;
                        }
                        break;
                }
            }
            if (add) {
                grDropDown.append('<option value="' + self.gradeList[i].value + '">' + self.gradeList[i].text + '</option>');
            }
        }
        FormState.doAction(StateAction.changeSelect('POS_GRADE_ID', ''), false);
    },

    //**Function to reset Grades upon change in Hiring Method */
    resetGrades: function(hiringMethod, refresh) {
        var self = this;
        if (refresh) {
            FormState.doAction(StateAction.changeText('POS_GRADE_IDS', ''), false);
            CDCCommon.renderDisplay('POS_GRADE_IDS', '#grList', self.gradeList);
            self.setGradesDropDown(hiringMethod);
            CDCCommon.hideField('POS_GRADE_ID', true);
            CDCCommon.showField('POS_GRADE_ID', true);
        }
    },

    //**Function to reset Promotion Potential upon change in Hiring Method */
    resetPromtionPotential: function(hiringMethod, refresh) {
        var self = this;
        var show = true;
        switch (hiringMethod) {
            case 'Title5':
                break;
            case 'Title42':
                show = false;
                break;
            case 'SES/SL':
                show = false;
                break;
        }
        if (refresh) {
            CDCCommon.showHideField(show, 'POS_IS_PROMOTIONAL', false, '');
        } else {
            CDCCommon.showHideField(show, 'POS_IS_PROMOTIONAL', false);
        }
    },

    //**Function to show/hide Not to Exceed Date based on Appointment Type */
    resetNotToExceed: function(apptTypeValue, refresh) {
        var self = this;
        var searchResult = CDCCommon.searchArray(self.appointmentTypeList, apptTypeValue, 'value');
        if (apptTypeValue === '' || (searchResult && searchResult.index !== -1 && (searchResult.data.text === 'Permanent' || searchResult.data.text === 'Indefinite'))) {
            if (refresh) {
                FormState.doAction(StateAction.changeText('POS_NTE', ''), false);
            }
            CDCCommon.hideField('POS_NTE', true);
        } else {
            CDCCommon.showField('POS_NTE', true);
        }
    },

    //**Function to reset Appointment Type upon change in Hiring Method */
    resetApptType: function(hiringMethod, refresh) {
        var self = this;
        var apptTypeDropDown = $('#POS_APPT_TYPE_ID');
        apptTypeDropDown.find('option').remove();
        var firstValue;
        for (var i = 0; i < self.appointmentTypeList.length; i++) {
            var add = false;
            switch (self.appointmentTypeList[i].text) {
                case 'Select One':
                case 'Permanent':
                case 'Temporary':
                    if (hiringMethod === 'Title5' || hiringMethod === 'SES/SL') {
                        add = true;
                    }
                    break;
                case 'Term':
                case 'Temp Promotion':
                    if (hiringMethod === 'Title5') {
                        add = true;
                    }
                    break;
                case 'Indefinite':
                    if (hiringMethod === 'Title42') {
                        add = true;
                    }
                    break;
            }
            if (add) {
                if (!firstValue && firstValue !== "") {
                    firstValue = self.appointmentTypeList[i].value;
                }
                apptTypeDropDown.append('<option value="' + self.appointmentTypeList[i].value + '">' + self.appointmentTypeList[i].text + '</option>');
            }
        }
        if (refresh) {
            var fieldState = FormState.getState('POS_APPT_TYPE_ID');
            if (fieldState) {
                FormState.doAction(StateAction.changeSelect('POS_APPT_TYPE_ID', '' + firstValue), false);
            }
        }
        self.resetNotToExceed(firstValue, refresh);
    },

    //**Function to show/hide Name Request upon change in Hiring Method */
    resetNameRequest: function(hiringMethod, refresh) {
        var self = this;
        var show = true;
        switch (hiringMethod) {
            case 'Title5':
                break;
            case 'Title42':
                show = false;
                break;
            case 'SES/SL':
                show = false;
                break;
        }
        if (refresh) {
            CDCCommon.showHideField(show, 'POS_NAME_REQUEST', false, '');
        } else {
            CDCCommon.showHideField(show, 'POS_NAME_REQUEST', false);
        }
    },

    //**Function to reset Area of Consideration and related fields upon change in Hiring Method */
    resetAOC: function(hiringMethod, refresh) {
        var self = this;
        var dropDown = $('#POS_AOC');
        dropDown.find('option').remove();
        var firstValue;
        for (var i = 0; i < self.aocList.length; i++) {
            switch (self.aocList[i].text) {
                case 'Pathways':
                    if (hiringMethod === 'Title5') {
                        dropDown.append('<option value="' + self.aocList[i].value + '">' + self.aocList[i].text + '</option>');
                        if (!firstValue && firstValue !== "") firstValue = self.aocList[i].value;
                    }
                    break;
                case 'All Sources':
                    if (hiringMethod === 'Title42') {
                        dropDown.append('<option value="' + self.aocList[i].value + '">' + self.aocList[i].text + '</option>');
                        if (!firstValue && firstValue !== "") firstValue = self.aocList[i].value;
                    }
                    break;
                default: //**For MP, DE and Select One */
                    if (hiringMethod === 'Title5' || hiringMethod === 'SES/SL') {
                        dropDown.append('<option value="' + self.aocList[i].value + '">' + self.aocList[i].text + '</option>');
                        if (!firstValue && firstValue !== "") firstValue = self.aocList[i].value;
                    }
                    break;
            }
        }
        if (refresh) {
            FormState.doAction(StateAction.changeSelect('POS_AOC', '' + firstValue), false);
            CDCCommon.showHideField(firstValue === 'MP', 'POS_MP_TYPE', true, '');
            CDCCommon.showHideField(firstValue === 'DE', 'POS_DE_TYPE', true, '');
            CDCCommon.showHideField(firstValue === 'Pathways', 'POS_PATHWAY_TYPE', true, '');
            CDCCommon.hideField('POS_AOC_1', true, '');
            CDCCommon.hideField('POS_MP_TYPE_1', true, '');
            CDCCommon.hideField('POS_DE_TYPE_1', true, '');
            $('#btnAddAOC').addClass('hidden');
            $('#btnDeleteAOC').addClass('hidden');
            if (hiringMethod === 'Title5' || hiringMethod === 'SES/SL') {
                $('#btnAddAOC').removeClass('hidden');
            }
        }
    },

    //**Function to reset Backfill/Vice Name and Reason upon change in Hiring Method as well as Backfill/Vice */
    resetBFViceNameReason: function(fieldState, refresh) {
        CDCCommon.hideField('POS_BF_VICE_NAME', true);
        CDCCommon.hideField('POS_NO_BF_VICE_RSN', true);
        if (!fieldState) {
            fieldState = FormState.getState('POS_IS_BF_OR_VICE');
        }
        if (fieldState) {
            if (fieldState.value === 'No') {
                if (refresh) {
                    FormState.doAction(StateAction.changeText('POS_BF_VICE_NAME', ''), false);
                }
                CDCCommon.showField('POS_NO_BF_VICE_RSN', true);
            } else if (fieldState.value === 'Yes') {
                if (refresh) {
                    FormState.doAction(StateAction.changeText('POS_NO_BF_VICE_RSN', ''), false);
                }
                CDCCommon.showField('POS_BF_VICE_NAME', true);
            }
        }
    },

    //**Function for initial setup when the form is loaded */
    initSetup: function() {
        var self = this;

        var hiringMethod = self.getHiringMethod();
        var grFieldState = FormState.getState('POS_GRADE_IDS');
        CDCCommon.renderDisplay('POS_GRADE_IDS', '#grList', self.gradeList);
        if (grFieldState && grFieldState.value) {
            CDCCommon.hideField('POS_GRADE_ID', true, '');
            CDCCommon.showField('POS_GRADE_ID');
        }
        //FormState.doAction(StateAction.changeSelect('POS_GRADE_ID', self.gradeList[0].value), false);
        self.setGradesDropDown(hiringMethod);

        var tsFieldState = FormState.getState('POS_TITLES_SERIESES');
        CDCCommon.renderDisplay('POS_TITLES_SERIESES', '#ptSrList');
        if (tsFieldState && tsFieldState.value) {
            CDCCommon.hideField('POS_TITLE', true, '');
            CDCCommon.showField('POS_TITLE');
            CDCCommon.hideField('POS_SERIES', true, '');
            CDCCommon.showField('POS_SERIES');
        }
        
        CDCCommon.renderDisplay('POS_DUTY_STATIONS', '#dsList');
        /***** Duty Station is not Not Requried and hence Unconditional hide/show *****/
        CDCCommon.hideField('POS_DUTY_STATION', false, '');
        CDCCommon.showField('POS_DUTY_STATION');

    },

    //**Function that performs action when a particular field is changed (called from renderer function) */
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        var hiringMethod = self.getHiringMethod();
        if (fieldState && (fieldState.dirty || !this.initSetupDone)) {
            switch (field) {
                //**When Hiring Method changes; This form-control is on General Tab */
                case 'HM_ID':
                    //**Show/hide/reset appropriate Pay Plan, Grades, Promotional Potential, Full Performance Level, Appointment-Type, AOC and Request Name */
                    $('#position_main_lg').removeClass('hidden');
                    $('#position_error_lg').addClass('hidden');
                    if (hiringMethod === '') {
                        $('#position_main_lg').addClass('hidden');
                        $('#position_error_lg').removeClass('hidden');
                    } else {
                        self.resetGrades(hiringMethod, self.initSetupDone);
                        self.resetPromtionPotential(hiringMethod, self.initSetupDone);
                        self.resetApptType(hiringMethod, self.initSetupDone);
                        self.resetBFViceNameReason(null, self.initSetupDone); //**Null for POS_IS_BF_OR_VICE fieldState when called from HM_ID change */
                        self.resetAOC(hiringMethod, self.initSetupDone);
                        self.resetNameRequest(hiringMethod, self.initSetupDone);
                    }
                    break;
                    /**When Bacfill/Vice changes */
                case 'POS_IS_BF_OR_VICE':
                    self.resetBFViceNameReason(fieldState, self.initSetupDone);
                    break;
                    //**When Promotional Potential changes */
                case "POS_IS_PROMOTIONAL":
                    if (fieldState.value === 'Yes') {
                        if (hiringMethod === 'Title5'  && self.initSetupDone) {
                            self.resetFPL();
                            CDCCommon.showField('POS_FULL_PERF_LEVEL', true);
                        }
                    } else {
                        FormState.doAction(StateAction.changeSelect('POS_FULL_PERF_LEVEL', ''), false);
                        CDCCommon.hideField('POS_FULL_PERF_LEVEL', true);
                    }
                    break;
                case 'POS_AOC':
                    CDCCommon.hideField('POS_MP_TYPE', true);
                    CDCCommon.hideField('POS_DE_TYPE', true);
                    CDCCommon.hideField('POS_PATHWAY_TYPE', true);
                    CDCCommon.hideField('POS_AOC_1', true);
                    CDCCommon.hideField('POS_MP_TYPE_1', true);
                    CDCCommon.hideField('POS_DE_TYPE_1', true);
                    $('#btnAddAOC').addClass('hidden');
                    $('#btnDeleteAOC').addClass('hidden');
                    if (self.initSetupDone) {
                        FormState.doAction(StateAction.changeText('POS_MP_TYPE', ''), false);
                        FormState.doAction(StateAction.changeText('POS_DE_TYPE', ''), false);
                        FormState.doAction(StateAction.changeText('POS_PATHWAY_TYPE', ''), false);
                    }
                    if (fieldState.value === 'Pathways') {
                        CDCCommon.showField('POS_PATHWAY_TYPE', true);
                        FormState.doAction(StateAction.changeText('POS_AOC_1', ''), false);
                        FormState.doAction(StateAction.changeText('POS_MP_TYPE_1', ''), false);
                        FormState.doAction(StateAction.changeText('POS_DE_TYPE_1', ''), false);
                    } else if (fieldState.value === 'All Sources') {
                        FormState.doAction(StateAction.changeText('POS_AOC_1', ''), false);
                        FormState.doAction(StateAction.changeText('POS_MP_TYPE_1', ''), false);
                        FormState.doAction(StateAction.changeText('POS_DE_TYPE_1', ''), false);
                    } else if (fieldState.value === 'MP') {
                        CDCCommon.showField('POS_MP_TYPE', true);
                        var aoc1 = FormState.getState('POS_AOC_1');
                        if (aoc1) {
                            if (aoc1.value === 'DE') {
                                CDCCommon.showField('POS_AOC_1', true);
                                CDCCommon.showField('POS_DE_TYPE_1', true);
                                $('#btnDeleteAOC').removeClass('hidden');
                            } else {
                                FormState.doAction(StateAction.changeText('POS_AOC_1', ''), false);
                                FormState.doAction(StateAction.changeText('POS_MP_TYPE_1', ''), false);
                                FormState.doAction(StateAction.changeText('POS_DE_TYPE_1', ''), false);
                                $('#btnAddAOC').removeClass('hidden');
                            }
                        }
                    } else if (fieldState.value === 'DE') {
                        CDCCommon.showField('POS_DE_TYPE', true);
                        var aoc1 = FormState.getState('POS_AOC_1');
                        if (aoc1) {
                            if (aoc1.value === 'MP') {
                                CDCCommon.showField('POS_AOC_1', true);
                                CDCCommon.showField('POS_DE_TYPE_1', true);
                                $('#btnDeleteAOC').removeClass('hidden');
                            } else {
                                FormState.doAction(StateAction.changeText('POS_AOC_1', ''), false);
                                FormState.doAction(StateAction.changeText('POS_MP_TYPE_1', ''), false);
                                FormState.doAction(StateAction.changeText('POS_DE_TYPE_1', ''), false);
                                $('#btnAddAOC').removeClass('hidden');
                            }
                        }
                    }
                    break;
                    //**When Area of Consideration (Additional) changes */
                case 'POS_AOC_1':
                    CDCCommon.hideField('POS_MP_TYPE_1', true);
                    CDCCommon.hideField('POS_DE_TYPE_1', true);
                    $('#POS_AOC_1 option').prop('disabled', 'disabled');
                    $('#POS_AOC_1 option[value="' + fieldState.value + '"]').removeAttr('disabled');
                    if (fieldState.value === 'MP') {
                        CDCCommon.showField('POS_MP_TYPE_1', true);
                    } else if (fieldState.value === 'DE') {
                        CDCCommon.showField('POS_DE_TYPE_1', true);
                    }
                    break;
                    //**When Type of Appointment changes */
                case 'POS_APPT_TYPE_ID':
                    self.resetNotToExceed(fieldState.value, self.initSetupDone);
                    break;
                    //**When Open and Continuous changes */
                case 'POS_IS_OPEN_CONTINUOUS':
                    if (fieldState.value === 'No') {
                        CDCCommon.showField('POS_DAYS_TO_ADVERTISE', true);
                    } else {
                        CDCCommon.hideField('POS_DAYS_TO_ADVERTISE', true, '');
                    }
                    break;
                    //**When Work Schedule changes */
                case 'POS_WORK_SCHED':
                    if (fieldState.value === '') {
                        CDCCommon.hideField('POS_HOURS_PER_WEEK', true);
                        $('#POS_HOURS_PER_WEEK').attr('_regularexpression', '');
                    } else {
                        var searchResult = CDCCommon.searchArray(self.workScheduleList, fieldState.value, 'value');
                        if ((searchResult.data.text) === 'Part-time') {
                            $('#POS_HOURS_PER_WEEK').attr('_regularexpression', '^1[6789]|2[0-9]|3[1-2]');
                        } else if ((searchResult.data.text) === 'Full-time') {
                            $('#POS_HOURS_PER_WEEK').attr('_regularexpression', '^3[2-9]|4[0]');
                        }
                    }
                    if (self.initSetupDone) {
                        if (fieldState.value !== '') {
                            CDCCommon.showField('POS_HOURS_PER_WEEK', true, '');
                            $('#POS_HOURS_PER_WEEK').focus();
                        }
                    }
                    break;
                case "POS_REMARKS":
                    var length = fieldState.value.length;
                    var maxLength = $('#POS_REMARKS').attr("_maxlength");
                    if (!isNaN(maxLength)) {
                        if (parseInt(length) > parseInt(maxLength)) {
                            FormState.doAction(StateAction.changeText('POS_REMARKS', fieldState.value.substring(0, parseInt(maxLength)), false));
                            length = maxLength;
                        }
                        $('#remarksSizeDisplay').text("Now: " + length + " / Max: " + maxLength);
                    }
                    else {
                        $('#remarksSizeDisplay').text("");
                    }
                    break;
            }
        }
    },

    //**Renderer function that is called from REDUX setup */
    renderer: function() {
        console.log('p2wPosition renderer Start');
        var self = this;
        CDCCommon.setupFirstLoad(self.checkField, self.fields);

        if (!self.initSetupDone) {
            self.resetFPL();
            self.initSetup();
        }
        self.actionOnChange('HM_ID');
        self.actionOnChange('POS_IS_BF_OR_VICE');
        self.actionOnChange('POS_IS_PROMOTIONAL');
        self.actionOnChange('POS_AOC');
        self.actionOnChange('POS_AOC_1');
        self.actionOnChange('POS_APPT_TYPE_ID');
        self.actionOnChange('POS_IS_OPEN_CONTINUOUS');
        self.actionOnChange('POS_WORK_SCHED');
        self.actionOnChange('POS_REMARKS');
        self.initSetupDone = true;
        console.log('p2wPosition renderer End');
    },

    //**Mappers for Autocomplete */
    mappers: {
        POS_DUTY_STATION: function() {
            return {
                DS_VALUE: $('DS_VALUE', this).text()
            }
        },
        POS_PAY_PLAN_CODE: function() {
            return {
                PAYPLAN_CODE: $('PAYPLAN_CODE', this).text(),
                PAYPLAN_DISPLAY: $('PAYPLAN_DISPLAY', this).text()
            }
        },
        POS_SERIES: function() {
            return {
                SERIES_CODE: $('SERIES_CODE', this).text(),
                SERIES_DISPLAY: $('SERIES_DISPLAY', this).text()
            }
        }
    },

    //**OnBlur handler for Autocomplete */
    reduxBindFix: function() {
        var control = $(this);
        if (control.hasClass('js-autocomplete')) {
            FormState.doAction(StateAction.changeText(control.attr('id'), control.val()), false);
            // if (control.attr('id') === 'POS_DUTY_STATION') {
            //     CDCCommon.addData('POS_DUTY_STATIONS', control.val(), '#dsList');
            //     control.val("");
            // }
        }
    },

    //**Init function (called from onLoad page event) */
    init: function() {
        console.log('p2wPosition Init Start');
        var self = this;

        //**Set numeric only entry */
        $('.js-numericOnly').bind('keypress', function(e) {
            if (e.keyCode === '9' || e.keyCode === '16') {
                return;
            }
            var code;
            if (e.keyCode) code = e.keyCode;
            else if (e.which) code = e.which;
            if (e.which === 46)
                return false;
            if (code === 8 || code === 46 || code === 45)
                return true;
            if (code < 48 || code > 57)
                return false;
        });

        //**Load Grade list from Drop-down */
        $("#POS_GRADE_ID > option").each(function() {
            self.gradeList.push({
                value: $(this).val(),
                text: $(this).text()
            });
        });

        //**Load Appointment Type list from Drop-down */
        $('#POS_APPT_TYPE_ID > option').each(function() {
            self.appointmentTypeList.push({
                value: $(this).val(),
                text: $(this).text()
            });
        });

        //**Load Area of Consideration list from Drop-down */
        $('#POS_AOC > option').each(function() {
            self.aocList.push({
                value: $(this).val(),
                text: $(this).text()
            });
        });

        //**Load Work Schedule list from Drop-down */
        $('#POS_WORK_SCHED > option').each(function() {
            self.workScheduleList.push({
                value: $(this).val(),
                text: $(this).text()
            });
        });

        //** Set Click Event Handler for Add and Delete (X) Position/Series buttons*/
        $("#ADD_POS_SR").on('click', function() {
            var title = $('#POS_TITLE').val();
            var series = $('#POS_SERIES').val();
            if (title && title !== '' && series && series !== '') {
                CDCCommon.addData('POS_TITLES_SERIESES', title + '%%' + series, '#ptSrList');
                FormState.doAction(StateAction.changeSelect('POS_SERIES', ''), true);
                FormState.doAction(StateAction.changeSelect('POS_TITLE', ''), true);
                CDCCommon.hideField('POS_TITLE', true);
                CDCCommon.showField('POS_TITLE');
                CDCCommon.hideField('POS_SERIES', true);
                CDCCommon.showField('POS_SERIES');
                $('#POS_TITLE').focus();
            }
        });
        $('#position_main_lg').on('click', '.js-POS_TITLES_SERIESES-delete', function(e) {
            e.preventDefault();
            CDCCommon.removeData('POS_TITLES_SERIESES', $(this).data("item"), '#ptSrList');
            var fieldState = FormState.getState('POS_TITLES_SERIESES');
            if (fieldState && (!fieldState.value || (fieldState.value).length === 0)) {
                CDCCommon.hideField('POS_TITLE');
                CDCCommon.showField('POS_TITLE', true);
                CDCCommon.hideField('POS_SERIES');
                CDCCommon.showField('POS_SERIES', true);
            }
        });

        //** Set Click Event Handler for Add and Delete (X) Grade buttons*/
        $("#ADD_GR").on('click', function() {
            var hiringMethod = self.getHiringMethod();
            var fieldState = FormState.getState('POS_GRADE_ID');
            if (fieldState && fieldState.value) {
                CDCCommon.addData('POS_GRADE_IDS', fieldState.value, '#grList', self.gradeList);
                self.setGradesDropDown(hiringMethod);
                //FormState.doAction(StateAction.changeSelect('POS_GRADE_ID', self.gradeList[0].value), true);
                CDCCommon.hideField('POS_GRADE_ID', true);
                CDCCommon.showField('POS_GRADE_ID');
                if (hiringMethod === "Title5") {
                    self.resetFPL();
                }
                $('#POS_GRADE_ID').focus();
            }
        });
        $('#POSITION_MAIN_GRID').on('click', '.js-POS_GRADE_IDS-delete', function(e) {
            e.preventDefault();
            var hiringMethod = self.getHiringMethod();
            CDCCommon.removeData('POS_GRADE_IDS', $(this).data("item"), '#grList', self.gradeList);
            self.setGradesDropDown(hiringMethod);
            var fieldState = FormState.getState('POS_GRADE_IDS');
            if (fieldState && (!fieldState.value || (fieldState.value).length === 0)) {
                CDCCommon.hideField('POS_GRADE_ID');
                CDCCommon.showField('POS_GRADE_ID', true);
            }
            if (hiringMethod === "Title5") {
                self.resetFPL();
            }
        });

        //** Set Click Event Handler for Add and Delete (X) Duty Stations buttons*/
        $("#ADD_DS").on('click', function() {
            CDCCommon.addData('POS_DUTY_STATIONS', $('#POS_DUTY_STATION').val(), '#dsList');
            FormState.doAction(StateAction.changeSelect('POS_DUTY_STATION', ''), true);
            $('#POS_DUTY_STATION').focus();
        });
        $('#position_main_lg').on('click', '.js-POS_DUTY_STATIONS-delete', function(e) {
            e.preventDefault();
            CDCCommon.removeData('POS_DUTY_STATIONS', $(this).data("item"), '#dsList');
        });

        
        //**Make sure NTE is in future */
        $('#POS_NTE').on('change', function() {
            var selectedDateText = $(this).val();
            if (selectedDateText) {
                var selectedDate = new Date(selectedDateText);
                var now = new Date();
                if (!(selectedDate > now)) {
                    alert('NTE must be in future -OR- Invalid NTE Date');
                    FormState.doAction(StateAction.changeText('POS_NTE', ''), true);
                    $(this).focus();
                }
            }
        });

        $('#btnAddAOC').click('on', function() {
            var aoc = FormState.getState('POS_AOC');
            CDCCommon.showField('POS_AOC_1', true, '');
            $('#POS_AOC_1').val('');
            CDCCommon.hideField('POS_MP_TYPE_1', true, '');
            $('#POS_MP_TYPE_1').val('');
            CDCCommon.hideField('POS_DE_TYPE_1', true, '');
            $('#POS_DE_TYPE_1').val('');
            $('#POS_AOC_1 option').removeAttr('disabled');
            $('#POS_AOC_1 option[value="' + aoc.value + '"]').prop('disabled', 'disabled');
            $('#btnAddAOC').addClass('hidden');
            $('#btnDeleteAOC').removeClass('hidden');
        });
        $('#btnDeleteAOC').click('on', function() {
            CDCCommon.hideField('POS_AOC_1', true, '');
            $('#POS_AOC_1').val('');
            CDCCommon.hideField('POS_MP_TYPE_1', true, '');
            $('#POS_MP_TYPE_1').val('');
            CDCCommon.hideField('POS_DE_TYPE_1', true, '');
            $('#POS_DE_TYPE_1').val('');
            $('#btnDeleteAOC').addClass('hidden');
            $('#btnAddAOC').removeClass('hidden');
        });

        CDCCommon.setAutoComplete('position_main_lg', self.mappers, self.reduxBindFix);

        console.log('p2wPosition Init End');
    }
};