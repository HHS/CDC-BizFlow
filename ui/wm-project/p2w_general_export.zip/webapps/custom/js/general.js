/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var p2wGen = {
    checkField: {
        name: 'genInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
        { name: 'ADMIN_CD', value: "" },
        { name: 'ORG_NAME', value: "" },
        { name: 'HM_ID', firstValue: true },
        { name: 'SO_AutoComplete', value: "" },
        { name: 'SO_EMAIL', value: "" },
        { name: 'CIO_AutoComplete', value: "" },
        { name: 'CIO_EMAIL', value: "" },
        { name: 'HROS_AutoComplete', value: "" },
        { name: 'HROS_EMAIL', value: "" },
        { name: 'CLASS_SPEC_AutoComplete', value: "" },
        { name: 'CLASS_SPEC_EMAIL', value: "" },
        { name: 'SCC_NAME', value: "" },
        { name: 'SCC_EMAIL', value: "" },
        { name: 'SCC_ORG', value: "" },
        { name: 'SME_REQ', firstValue: true },
        { name: 'SME_NAME_1', value: "" },
        { name: 'SME_EMAIL_1', value: "" },
        { name: 'SME_ORG_1', value: "" },
        { name: 'SME_INTERNAL_1', firstValue: true },
        { name: 'SME_NAME_2', value: "" },
        { name: 'SME_EMAIL_2', value: "" },
        { name: 'SME_ORG_2', value: "" },
        { name: 'SME_INTERNAL_2', firstValue: true },
        { name: 'SME_NAME_3', value: "" },
        { name: 'SME_EMAIL_3', value: "" },
        { name: 'SME_ORG_3', value: "" },
        { name: 'SME_INTERNAL_3', firstValue: true },
        { name: 'SME_NAME_4', value: "" },
        { name: 'SME_EMAIL_4', value: "" },
        { name: 'SME_ORG_4', value: "" },
        { name: 'SME_INTERNAL_4', firstValue: true },
        { name: 'SME_NAME_5', value: "" },
        { name: 'SME_EMAIL_5', value: "" },
        { name: 'SME_ORG_5', value: "" },
        { name: 'SME_INTERNAL_5', firstValue: true },
        { name: 'STF_VAL', firstValue: true },
        { name: 'STF_VAL_JUST', value: "" },
        { name: 'HHS_APPROVE', firstValue: true },
        { name: 'HHS_APPROVE_JUST', value: "" },
        { name: 'PBMS_ID', value: "" },
        { name: 'HIRE_GUIDE_VAL', firstValue: true },
        { name: 'HIRE_GUIDE_VAL_JUST', value: "" },
        { name: 'CIO_ID', value: "" },
        { name: 'CIO_PART_ID', value: "" },
        { name: 'SO_ID', value: "" },
        { name: 'SO_PART_ID', value: "" },
        { name: 'HROS_ID', value: "" },
        { name: 'HROS_PART_ID', value: "" },
        { name: 'CLASS_SPEC_ID', value: "" },
        { name: 'CLASS_SPEC_PART_ID', value: "" }
    ],
    renderer: function() {
        var self = this;
        var initRequiredFrmState = FormState.getState('genInitRequired');
        CDCCommon.setupFirstLoad(self.checkField, self.fields);

        self.actionOnChange('SME_REQ');
        self.actionOnChange('SME_INTERNAL_1');
        self.actionOnChange('SME_INTERNAL_2');
        self.actionOnChange('SME_INTERNAL_3');
        self.actionOnChange('SME_INTERNAL_4');
        self.actionOnChange('SME_INTERNAL_5');

        self.actionOnChange('STF_VAL');
        self.actionOnChange('HIRE_GUIDE_REV');
        self.actionOnChange('HM_ID');
        self.actionOnChange('HHS_APPROVE');

        self.actionOnChange("SO_PART_ID");
        self.actionOnChange("CIO_PART_ID");
        self.actionOnChange("HROS_PART_ID");
        self.actionOnChange("CLASS_SPEC_PART_ID");
    },
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        if (fieldState && fieldState.dirty) {
            switch (field) {
                case "HM_ID":
                    if ((fieldState.value).indexOf('Title 42') < 0) {
                        CDCCommon.hideField('SCC_NAME', true, '');
                        CDCCommon.hideField('SCC_EMAIL', true, '');
                        CDCCommon.hideField('SCC_ORG', true, '');
                        CDCCommon.hideField('HHS_APPROVE', true);
                        CDCCommon.hideField('HHS_APPROVE_JUST', true, '');
                    } else {
                        CDCCommon.showField('SCC_NAME', false);
                        CDCCommon.showField('SCC_EMAIL', false);
                        CDCCommon.showField('SCC_ORG', false);
                        CDCCommon.showField('HHS_APPROVE', true);
                        CDCCommon.showField('HHS_APPROVE_JUST', true);
                    }
                    break;
                case "STF_VAL":
                case "HIRE_GUIDE_REV":
                    if (fieldState.value === 'Yes') {
                        CDCCommon.hideField(field + "_JUST", true, '');
                    } else {
                        CDCCommon.showField(field + "_JUST", true);
                    }
                    break;
                case "HHS_APPROVE":
                    var hmFieldState = FormState.getState('HM_ID')
                    if (fieldState.value === 'Yes') {
                        CDCCommon.hideField(field + "_JUST", true, '');
                    } else if ((fieldState.value).indexOf('Title 42') > -1) {
                        CDCCommon.showField(field + "_JUST", true);
                    }
                    break;
                case "SME_REQ":
                    if (fieldState.value === 'Yes') {
                        $('#SME_INFO_ROW_3').removeClass('hidden');
                        CDCCommon.showField('SME_NAME_1', true);
                        var additionalFld = FormState.getState('SME_NAME_2');
                        if (additionalFld && additionalFld.value !== '') {
                            $('#ADD_SMEs').trigger('click');
                        } else {
                            self.hideSMEs(false);
                        }
                    } else {
                        self.hideSMEs(true);
                    }
                    break;
                case "SME_INTERNAL_1":
                case "SME_INTERNAL_2":
                case "SME_INTERNAL_3":
                case "SME_INTERNAL_4":
                case "SME_INTERNAL_5":
                    var rowNum = field.slice(-1);
                    if (fieldState.value === 'No') {
                        $('#SME_NAME_' + rowNum).autocomplete('destroy');
                        $('#SME_EMAIL_' + rowNum).attr("readonly", false).attr('disabled', false).parent().removeClass('isDisabled');
                        $('#SME_ORG_' + rowNum).attr("readonly", false).attr('disabled', false).parent().removeClass('isDisabled');
                    } else if (!$('#SME_NAME_' + rowNum).data('autocomplete')) {
                        CDCCommon.setAutoComplete('SME_NAME_' + rowNum + '_container', self.mappers, self.reduxBindFix);
                        $('SME_EMAIL_' + rowNum).attr("readonly", true).attr('disabled', true).parent().addClass('isDisabled');
                        $('#SME_ORG_' + rowNum).attr("readonly", true).attr('disabled', true).parent().addClass('isDisabled');
                    }
                    break;
                case "SO_PART_ID":
                case "CIO_PART_ID":
                case "HROS_PART_ID":
                case "CLASS_SPEC_PART_ID":
                    if ((fieldState.value).indexOf('[U]') < 0) {
                        FormState.doAction(StateAction.changeText(fieldState.id, '[U]' + fieldState.value), false);
                    }
                    break;
            }
        }
    },
    hideSMEs: function(primary) {

        if (primary) {
            CDCCommon.hideField('SME_NAME_1', true, '');
            $('#SME_NAME_1').val('');
            FormState.doAction(StateAction.changeText('SME_EMAIL_1', ''), false);
            $('#SME_EMAIL_1').val('');
            FormState.doAction(StateAction.changeText('SME_ORG_1', ''), false);
            $('#SME_ORG_1').val('');
            $('#SME_INFO_ROW_3').addClass('hidden');
        }

        CDCCommon.hideField('SME_NAME_2', true, '');
        $('#SME_NAME_2').val('');
        FormState.doAction(StateAction.changeText('SME_EMAIL_2', ''), false);
        $('#SME_EMAIL_2').val('');
        FormState.doAction(StateAction.changeText('SME_ORG_2', ''), false);
        $('#SME_ORG_2').val('');
        FormState.doAction(StateAction.changeText('SME_NAME_3', ''), false);
        $('#SME_NAME_3').val('');
        FormState.doAction(StateAction.changeText('SME_EMAIL_3', ''), false);
        $('#SME_EMAIL_3').val('');
        FormState.doAction(StateAction.changeText('SME_ORG_3', ''), false);
        $('#SME_ORG_3').val('');
        FormState.doAction(StateAction.changeText('SME_NAME_4', ''), false);
        $('#SME_NAME_4').val('');
        FormState.doAction(StateAction.changeText('SME_EMAIL_4', ''), false);
        $('#SME_EMAIL_4').val('');
        FormState.doAction(StateAction.changeText('SME_ORG_4', ''), false);
        $('#SME_ORG_4').val('');
        FormState.doAction(StateAction.changeText('SME_NAME_5', ''), false);
        $('#SME_NAME_5').val('');
        FormState.doAction(StateAction.changeText('SME_EMAIL_5', ''), false);
        $('#SME_EMAIL_5').val('');
        FormState.doAction(StateAction.changeText('SME_ORG_5', ''), false);
        $('#SME_ORG_5').val('');


        $('#SME_INFO_ROW_4').addClass('hidden').ch
        $('#SME_INFO_ROW_5').addClass('hidden');
        $('#SME_INFO_ROW_6').addClass('hidden');
        $('#SME_INFO_ROW_7').addClass('hidden');
        $('#ADD_SMEs').val("Add Additional S.M.E's");

    },
    manageParticipant: function(partState) {
        if (partState && (partState.value).indexOf('[U]') < 0) {
            FormState.doAction(StateAction.changeText(partState.id, '[U]' + partState.value), false);
        }
    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        CDCCommon.setAutoComplete('group_general', this.mappers, this.reduxBindFix);
        $('#SME_INFO_GRD').on('click', '#ADD_SMEs', function(e) {
            e.preventDefault();
            var state = ($('#ADD_SMEs').val() === "Remove Additional S.M.E's") ? "REMOVE" : "ADD";
            if (state === "REMOVE") {
                p2wGen.hideSMEs(false);
            } else {
                $(this).val("Remove Additional S.M.E's").data('state', "REMOVE");
                CDCCommon.showField('SME_NAME_2', true);
                $('#SME_INFO_ROW_4').removeClass('hidden');
                $('#SME_INFO_ROW_5').removeClass('hidden');
                $('#SME_INFO_ROW_6').removeClass('hidden');
                $('#SME_INFO_ROW_7').removeClass('hidden');
            }

        });
    },
    reduxBindFix: function() {
        if (!$(this).data('autocomplete')) {
            FormState.doAction(StateAction.changeText($(this).attr('id'), $(this).val()), false);
        }
    },
    mappers: {

        ADMIN_CD: function() {
            return {
                AC_ADMIN_CD: $("AC_ADMIN_CD", this).text(),
                AC_ADMIN_CD_DESCR: $('AC_ADMIN_CD_DESCR', this).text()
            }
        },
        ORG_NAME: function() {
            return {
                AC_ADMIN_CD: $("AC_ADMIN_CD", this).text(),
                AC_ADMIN_CD_DESCR: $('AC_ADMIN_CD_DESCR', this).text()
            }
        },
        SO_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        },
        CIO_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        },
        HROS_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        },
        CLASS_SPEC_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        },
        SCC_NAME: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        },
        SME_NAME_1: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        },
        SME_NAME_2: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        },
        SME_NAME_3: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        },
        SME_NAME_4: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        },
        SME_NAME_5: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        }
    }
}