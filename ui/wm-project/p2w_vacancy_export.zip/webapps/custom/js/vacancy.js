/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var p2wVac = {
    checkField: {
        name: 'vacInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
        { name: 'FIELD_ID', value: "" }
    ],
    vacancies: {},
    renderer: function() {
        var self = this;

    },
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        if (fieldState && fieldState.dirty) {
            switch (field) {
                case "FIELD_ID":
                    break;
            }
        }
    },
    setVacancyData: function() {
        var self = this;
        var getVacancyData = $.ajax({ dataType: 'xml', method: 'GET', url: '/bizflowwebmaker/cdc_api/USAStaffing.do', cache: 'false' }).done(
            function(xml) {
                var oXML = $(xml).find('Vacancy_Announcement'),
                    data = {};

                oXML.each(function() {
                    var VIN = jQuery(this).find('Vacancy_Identification_Number').first().text();
                    data[VIN] = {};
                    jQuery(this).each(function() {
                        var payPlan = jQuery(this).find('Pay_Plan').text();
                        data[VIN] = {
                            VIN: VIN,
                            VAN: $('Vacancy_Announcement_Number', this).text(), //this could be multiple
                            AOC: $('Area_Of_Consideration', this).text(),
                            ANN_TYPE: $('Announcement_Type', this).text(),
                            CERTIFICATES: $('Certificate', this).map(function(cert, idx) {
                                return {
                                    CERT_NUM: $('Certificate_Number', this).text(),
                                    GRADE: $('Grade', this).text(),
                                    SERIES: $('Series', this).text(),
                                    CERT_TYPE: $('Certificate_Type', this).text(),
                                    DATE_CERT_ISS: self.formatDisplayDate($('Date_Certificate_Issued', this).text()),
                                    DATE_CERT_SENT_SO: self.formatDisplayDate($('Date_Certificate_Sent_To_SO', this).text()),
                                    CERT_EXT: '',
                                    NEW_CERT_EXP: self.formatDisplayDate(''),
                                    CERT_CANCEL: '',
                                    POS_TITLE: $('Position_Title', this).text(),
                                    PAY_PLAN: payPlan
                                }
                            }),
                            TOT_NUM_APP: $('Total_Number_Of_Applicants', this).text(),
                            TOT_QUAL_APP: $('Total_Number_Of_Eligible_Applicants', this).text(),
                            TOT_REF_APP: $('Total_Number_Of_Unique_Referred_Applicants', this).text(),
                            NOTIFY_QUAL_STAT: self.formatDisplayDate($('Date_Applicants_Notified_Eligibility_Status', this).text()),
                            NOTIFY_REF_APP: self.formatDisplayDate($('Date_Applicants_Notified_Referral_Status', this).text()),
                            SEL_MADE: '',
                            ACT_TAKEN: '',
                            HIRE_ACTION: self.formatDisplayDate(''),
                            HIRE_DEC_HR: self.formatDisplayDate('')
                        }

                    });
                });

                self.setVacancies(data);

            });
    },
    formatDisplayDate: function(dateStr) {
        var rtn = (dateStr) ? $.datepicker.formatDate('mm/dd/yy', new Date(dateStr)) : dateStr;
        return rtn;
    },
    setVacancies: function(data) {
        var self = this;
        self.vacancies = data;
        var $VIN = $('#VIN');
        $VIN.empty();
        for (var vacancy in self.vacancies) {
            $VIN.append('<option value="' + vacancy + '">' + vacancy + '</option>');
        };

        if ($VIN.children().size() > 1) {
            $VIN.append('<option value="" selected>Select One</option>');
            $VIN.on('change', function() {
                self.setVINDisplay()
            });
        }

        self.setVINDisplay();
    },
    setVINDisplay: function() {
        var self = this;
        var $VIN = $('#VIN');
        var $CERT_NUM = $('#CERT_NUM');

        if ($VIN.val() && $VIN.val() != '') {
            var vacancy = self.vacancies[$VIN.val()]
            $('#VAN').val(vacancy.VAN);
            $('#CERT_ANN_TYPE').val(vacancy.ANN_TYPE);
            $('#TOT_NUM_APP').val(vacancy.TOT_NUM_APP);
            $('#TOT_QUAL_APP').val(vacancy.TOT_QUAL_APP);
            $('#TOT_REF_APP').val(vacancy.TOT_REF_APP);
            $('#NOTIFY_QUAL_STAT').val(vacancy.NOTIFY_QUAL_STAT);
            $('#NOTIFY_REF_APP').val(vacancy.NOTIFY_REF_APP);
            $('#SEL_MADE').val(vacancy.SEL_MADE);
            $('#ACT_TAKEN').val(vacancy.ACT_TAKEN);
            $('#HIRE_ACTION').val(vacancy.HIRE_ACTION);
            $('#HIRE_DEC_HR').val(vacancy.HIRE_DEC_HR);
            $('#CERT_NUM').empty();
            self.clearCertData();
            jQuery(vacancy.CERTIFICATES).each(function() {
                $CERT_NUM.append('<option value="' + this.CERT_NUM + '">' + this.CERT_NUM + '</option>');
            });

            if ($CERT_NUM.children().length > 1) {
                $CERT_NUM.append('<option value="" selected>Select One</option>');
                $CERT_NUM.on('change', function() { self.setCERTDisplay() });
            } else {
                self.setCERTDisplay();
            }

        } else {
            self.clearPage();
        }
    },
    setCERTDisplay: function() {
        var self = this;
        var $CERT_NUM = $('#CERT_NUM');

        if ($CERT_NUM.val() && $CERT_NUM.val() != '') {
            var cert;
            jQuery(self.vacancies[$('#VIN').val()].CERTIFICATES).each(function() {
                if (this.CERT_NUM === $('#CERT_NUM').val()) {
                    cert = this;
                }
            });
            if (cert) {
                $("#CERT_TYPE").val(cert.CERT_TYPE);
                $("#DATE_CERT_ISS").val(cert.DATE_CERT_ISS);
                $("#DATE_CERT_SENT_SO").val(cert.DATE_CERT_SENT_SO);
                $("#DATE_CERT_EXP").val(cert.DATE_CERT_EXP);
                $("#CERT_EXT").val(cert.CERT_EXT);
                $("#NEW_CERT_EXP").val(cert.NEW_CERT_EXP);
                $("CERT_CANCEL").val(cert.CERT_CANCEL);
                $("#CERT_POS_TITLE").val(cert.POS_TITLE);
                $("#CERT_PAY_PLAN").val(cert.PAY_PLAN);
                $("#CERT_SERIES").val(cert.SERIES);
                $("#CERT_GRADE").val(cert.GRADE);
            } else {
                self.clearCertData();
            }
        }

    },
    clearPage: function() {
        var self = this;
        $('#VAN').val('');
        $('#CERT_ANN_TYPE').val('');
        $('#TOT_NUM_APP').val('');
        $('#TOT_QUAL_APP').val('');
        $('#TOT_REF_APP').val('');
        $('#NOTIFY_QUAL_STAT').val('');
        $('#NOTIFY_REF_APP').val('');
        $('#SEL_MADE').val('');
        $('#ACT_TAKEN').val('');
        $('#HIRE_ACTION').val('');
        $('#HIRE_DEC_HR').val('');
        $('#CERT_NUM').empty().append('<option value="">Select a VIN to load Certificates</option>');
        self.clearCertData();
    },
    clearCertData: function() {
        $("#CERT_TYPE").val('');
        $("#DATE_CERT_ISS").val('');
        $("#DATE_CERT_SENT_SO").val('');
        $("#DATE_CERT_EXP").val('');
        $("#CERT_EXT").val('');
        $("#CERT_CANCEL").val('');
        $("#NEW_CERT_EXP").val('');
        $("#CERT_POS_TITLE").val('');
        $("#CERT_PAY_PLAN").val('');
        $("#CERT_SERIES").val('');
        $("#CERT_GRADE").val('');
    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        var self = this;

        self.setVacancyData();
        $('#USA_STAFFING').on('click', function(e) {
            e.preventDefault();
            var vin = $('#VIN').val();
            if (vin != '') {
                window.open('https://usastaffing.gov/staffing/vacancy/edit/' + vin, '_blank');
            }
        });
    }
}