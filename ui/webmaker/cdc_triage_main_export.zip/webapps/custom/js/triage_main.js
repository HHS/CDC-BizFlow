var triageMain = {

    initialXML: "",

    CONST_ALL_FORM_READONLY_FALSE: false,
    CONST_ALL_FORM_READONLY_TRUE: true,

    activityList: [{
        name: 'Determine Staffing Need',
        usergroup: [],
        tabs: ['tab1', 'tab8', 'tab9', 'tab10'],
        readonly: [],
        mandatoryCommentButtons: []
    }],

    tabList: [{
        id: 'tab1',
        targetUrl: '/cdc_triage_general/general.do',
        targetGroup: 'partial_tab1',
        name: 'General',
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function() {
            if (triageGen.postEnableTab !== undefined) {
                triageGen.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (triageGen.postDisableTab !== undefined) {
                triageGen.postDisableTab(triageMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        postClearTabContents: function() {
        },
        renderer: function() {
            triageGen.renderer();
        },
        mainContainer: function() {
                return triageMain;
            }
    }, {
        id: 'tab8',
        targetUrl: '/apt_resources/resources.do',
        targetGroup: 'partial_tab8',
        name: 'Resources',
        loaded: false,
        completed: false,
        disabledHeader: false,
        renderer: function() {
            aptResources.renderer();
        },
        mainContainer: function() {
            return triageMain;
        }
    }, {
        id: 'tab9',
        targetUrl: '/p2w_common/showAttachment.do',
        targetGroup: 'partial_tab9',
        name: 'Documents',
        loaded: false,
        completed: false,
        disabledHeader: false
    }, {
        id: 'tab10',
        targetUrl: '/p2w_common/showComment.do?proctype=Triage',
        targetGroup: 'partial_tab10',
        name: 'Notes',
        loaded: false,
        completed: false,
        disabledHeader: false
    }],

    initBasedOnActivity: function() {
        
        if (BFUtility.isReadOnly() === true) {
            $('#bottomSection').hide();
            $('#layout_TabPreviousNext').hide();
            if (triageGen.postDisableTab !== undefined) {
                triageGen.postDisableTab(triageMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            return;
        }

        BFLog.log('DEBUG', 'triageMain - initBasedOnActivity - START');

        var activityName = BFActivityOption.getActivityName();

        if (activityName === 'Determine Staffing Need') {
            $('#h_hardStopRequired').val('true');
            $('#actionButton_Activity1').removeClass('hide')

            hyf.util.disableComponent('button_SendEmailForPreConsultation');

            triageMain.addButtonHandler('button_Submit1', true, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_preConsultReq', value: 'No'
            }]);

            triageMain.addButtonHandler('button_SendEmailForPreConsultation', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_preConsultReq', value: 'Yes'
            }]);

        } else {
            BFLog.log('DEBUG', 'triageMain - initBasedOnActivity() - No activity name matched [' + activityName + ']');
        }
        
        BFLog.log('DEBUG', 'triageMain - initBasedOnActivity - END');
    },

    addButtonHandler: function(buttonID, validationRequired, mandatoryDocValidationRequired, buttonOptions) {
        if (buttonID != null && buttonOptions != null) {
            $('#' + buttonID).off('click').click(function() {

                if (validationRequired === true) {
                    var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
                    for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                        var validated = TabManager.validateTab(activeTabs[tabIndex]);
                        if (validated === false) {
                            return;
                        }
                    }

                    if (mandatoryDocValidationRequired === true) {
                        var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
                        if (mandatoryDocumentsValid !== 'true') {
                            TabManager.enableTabHeader('tab9');
                            TabManager.enableTab('tab9');
                            $('#' + TabManager.getAnchorID('tab9')).click();
                            bootbox.alert('Please upload the missing required document(s).');
                            return;
                        }
                    }
                }

                //setting comments required to complete workitem, adding button ids.
                var isCommentsRequired = false;
                var isCommentsEntered = false;
                var witemContext = basicWIHActionClient.getWorkitemContext();
                for (var i = 0; i < triageMain.activityList.length; i++) {
                    var activityInfo = triageMain.activityList[i];
                    if (activityInfo.name === witemContext.Activity.Name) {
                        console.log("found current activity info in triageMain.activityList - " + activityInfo.name);

                        if (typeof activityInfo.mandatoryCommentButtons != 'undefined') {
                            if (activityInfo.mandatoryCommentButtons.length > 0) {

                                //Checking action button(s) required to enter comments
                                for (var i = 0; i < activityInfo.mandatoryCommentButtons.length; i++) {
                                    buttonInfo = activityInfo.mandatoryCommentButtons[i];
                                    if (buttonID === buttonInfo) {
                                        console.log("found button requrired to enter a comment - " + buttonID);
                                        isCommentsRequired = true;
                                        var comments = basicWIHActionClient.getComments();
                                        for (var i = 0; i < comments.length; i++) {
                                            var comment = comments[i];
                                            //Current user has entered a comment in current workitem
                                            if (comment.activitySeq == witemContext.Activity.Sequence &&
                                                comment.workitemSeq == witemContext.Workitem.Sequence &&
                                                comment.creatorID == witemContext.User.MemberID) {

                                                isCommentsEntered = true;
                                                break;
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        break; //found the same activity from configuration.
                    };
                };

                console.log("isCommentsRequired=" + isCommentsRequired + ", isCommentsEntered=" + isCommentsEntered);
                if (isCommentsRequired && (isCommentsEntered == false)) {
                    basicWIHActionClient.setCommentRequired(true);
                };

                //set field value
                buttonOptions.forEach(function(option) {
                    try {
                        $('#' + option.id).val(option.value);
                    } catch (e) {
                        console.error("Cannot find field " + option.id);
                    }
                });
                
                var xml = FormState.getFinalStateXML();
                $('#h_formData').val(xml);

                BFUtility.greyOutScreen(true);

                BFUtility.submitFormPage(buttonID, 'saveNewForm');
            });
        } else {
            BFLog.log('DEBUG', 'triageMain - addButtonHandler() - buttonID or buttonOption is null.');
        }
    },

    loadForm: function() {
        console.log("triageMain.loadForm");
        var xml = $('#h_formData').val();
        FormState.initWithXML(triageMain.renderer, xml);
        _.forEach(triageMain.tabList, function(tab) {
            if (typeof tab.renderer === 'function') {
                FormState.addRenderer(tab.renderer);
            }
        });
        FormState.doRender();
    },

    onAllTabLoaded: function() {
        console.log("triageMain.onAllTabLoaded");

        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);
        BFUtility.initMaxSize(tabs);
        BFUtility.setDateIconTabOrder(tabs);

        triageMain.showHidePreNextButtons();
        $(document).on('ON_TAB_CHANGE', triageMain.onTabChange);

        //
        if (typeof triageGen.onTabLoaded != "undefined") {
            triageGen.onTabLoaded();
        }
        //store form data when form is loaded, it will be use to check if form is changed when user exits the form.
        setTimeout(triageMain.storeInitialXML, 1000);
    },

    //store form data when form is loaded, it will be use to check if form is changed when user exits the form.
    storeInitialXML: function() {
        initialXML = FormState.getFinalStateXML();
    },

    onErrorTabChange: function() {
        var tabId = TabManager.getSelectedTabID();
        triageMain.errorMsg(tabId);
    },

    onTabChange: function() {
        console.log("triageMain.onTabChange");
        if (BFUtility.isReadOnly() === false) {
            var xml = FormState.getFinalStateXML();
            $('#h_formData').val(xml);
            BFUtility.callPartialPage(null, 'saveTabContent.do', null, 'layoutForResponse2');
        }

        triageMain.showHidePreNextButtons();
    },

    renderer: function() {
        console.log("triageMain.renderer");

    },

    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        var activityName = BFActivityOption.getActivityName();
    },

    showHidePreNextButtons: function() {
        var selectedTabID = TabManager.getSelectedTabID();
        var activeTabs = BFActivityOption.getTabList();

        var currentTabIndex = 0;
        for (var index = 0; index < activeTabs.length; index++) {
            if (activeTabs[index] === selectedTabID) {
                currentTabIndex = index;
                break;
            }
        }

        if (currentTabIndex === 0) {
            hyf.util.disableComponent('button_Previous');
            hyf.util.enableComponent('button_Next');
        } else if (currentTabIndex === activeTabs.length - 1) {
            hyf.util.enableComponent('button_Previous');
            hyf.util.disableComponent('button_Next');
        } else {
            BFUtility.enableComponents(['button_Previous', 'button_Next'])
        }
    },

    saveForm: function(e) {
        // store current tabid to reset after page reload
        $('#h_currentTabID').val(TabManager.getSelectedTabID());
        //var triageType = $("#TRIAGE_TYPE").val();
        //FormState.doAction(StateAction.changeSelect('TRIAGE_TYPE', triageType), true);
        var xml = FormState.getFinalStateXML();
        $('#h_formData').val(xml);
        BFUtility.saveForm(e);
    },

    exitForm: function(btnId) {
        //TAEHO 05/31/2018 customize WIH exit message
        var xml = FormState.getFinalStateXML();
        var isFormChangedAfterLoaded = false;
        if (initialXML === xml || initialXML === "") {
            basicWIHActionClient.exit({confirmMsg: null,
                            eventFn: function(){return true}});
        } else {
            basicWIHActionClient.exit({confirmMsg: "Are you sure you want to quit without saving?",
                            eventFn: function(){return true}});
        }
    },

    cancelForm: function(btnId) {
        //TODO: populating cancellation reason from lookup table
        var reasons = LookupManager.findByLTYPE('CancellationReason');
        var options = '<option value>Select one</option>';
        reasons.forEach(function(reason) {
            options = options + '<option value=' + reason.LABEL + '>' + reason.LABEL + '</option>';
        });

        var dialog = bootbox.dialog({
            title: 'Reason for Cancellation',
            message: '<span>Cancellation Reason</span><span class="mandatory" style="" title="Mandatory field"> * </span><span>:&nbsp;</span><select name="CancellationReason">' + options + '</select>',
            onEscape: true,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success',
                    callback: function() {
                        var message = $('div.bootbox select option:selected').text();
                        if (message == null || message.length == 0) {
                            return false;
                        }

                        setTimeout(function() {
                            BFUtility.greyOutScreen(true);
                            $('#WIH_complete_requested').val('true');
                            $('#pv_requestStatus').val('Request Cancelled');
                            $('#pv_CancelReason').val(message);
                            BFUtility.submitFormPage(btnId, 'saveNewForm');
                        }, 0);
                    }
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-danger'
                }
            }
        });

        $('div.bootbox button.btn-success').prop('disabled', true);

        $('div.bootbox select').on('change keyup', function() {
            var message = $('div.bootbox select option:selected').val();
            if (message == '') {
                $('div.bootbox button.btn-success').prop('disabled', true);
            } else {
                $('div.bootbox button.btn-success').prop('disabled', false);
            }
    });
    },

    restoreBizFlowParameter: function() {
        var sessionInfo = $('#sessioninfo').attr('value');
        if (sessionInfo != null && sessionInfo.length > 0) { // Backup
            $('#sessioninfo2').attr('value', $('#sessioninfo').attr('value'));
            $('#procid2').attr('value', $('#procid').attr('value'));
            $('#actseq2').attr('value', $('#actseq').attr('value'));
            $('#workseq2').attr('value', $('#workseq').attr('value'));
            $('#appseq2').attr('value', $('#appseq').attr('value'));
            $('#isarchive2').attr('value', $('#isarchive').attr('value'));
            $('#readOnly2').attr('value', $('#readOnly').attr('value'));
        } else { // Restore
            $('#sessioninfo').attr('value', $('#sessioninfo2').attr('value'));
            $('#procid').attr('value', $('#procid2').attr('value'));
            $('#actseq').attr('value', $('#actseq2').attr('value'));
            $('#workseq').attr('value', $('#workseq2').attr('value'));
            $('#appseq').attr('value', $('#appseq2').attr('value'));
            $('#isarchive').attr('value', $('#isarchive2').attr('value'));
            $('#readOnly').attr('value', $('#readOnly2').attr('value'));
        }
    },

    errorMsg: function(tab) {
        var cnt = 0;
        var $errList = $('#errlist-' + tab);
        var $errCnt = $('#errcnt-' + tab);
        if ($errList.length > 0) {
            $errList.empty();
            $errCnt.text();
            $('span.hasError').each(function(key, value) {
                if (typeof $(":first-child", this).data('wm-error-msg') != 'undefined') { //Taeho 03/08/2018 - skip 'undefined' items.
                    cnt++;
                    $errList.append("<li>" + $(":first-child", this).data('wm-error-msg') + "</li>");
                }
            });
            if (cnt > 0) {
                $errCnt.text('There are ' + cnt + ' errors on the form.');
                $('#reqmsg-' + tab).focus()
            }
        }
    },
    //
    // Main ENTRY POINT
    //
    init: function() {
        BFLog.setLogLevel('DEBUG');
        BFLog.log('DEBUG', 'triageMain - init START');

        BFActivityOption.init(triageMain.activityList);

        LookupManager.init();
        // In order to send the BizFlow parameters to tab projects so that they can use the workitem context
        triageMain.restoreBizFlowParameter();

        // Notes:
        //  Tabs in Appointment tab are dynamically changed based upon Activity name, Request Type, and Employee Type.
        //  Therefore, Appointment Main form cannnot use pre-defined tab configuration above.
        //  The form must overwrite the tab configuration with activity name and field values.
        

        TabManager.initTab(triageMain.tabList, triageMain.loadForm);
        $(document).on('HHS_ALL_TAB_LOADED', triageMain.onAllTabLoaded);

        //--------------------------------
        // static button event handler
        //----------------------------------------
        // save
        $('#button_SaveWorkitem').on('click', triageMain.saveForm);

        // Exit
        $('#button_ExitWIH').on('click', (function() {
            triageMain.exitForm('button_ExitWIH');
        }).bind(this));

        // Cancel
        $('#button_CancelWorkitem').on('click', (function() {
            triageMain.cancelForm('button_CancelWorkitem');
        }).bind(this));

        // Previous
        $('#button_Previous').off('click').click(function(e) {
            TabManager.loadPreviousTab();
        });

        // Next
        $('#button_Next').off('click').click(function(e) {
            TabManager.loadNextTab();
        });

        // Request Date
        var requestedDateString = $('#h_creationdate').val();
        if (requestedDateString != null && requestedDateString.length > 0) {
            var requestedDate = new Date(requestedDateString); // requestedDateString is GMT
            var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
            var requestedDateLabel = BFUtility.getDateString({ isUTC: false, dateFormat: 'mm/dd/yyyy' }, newDate);
            $('#initiatedDate').text(requestedDateLabel);
        }

        hyf.util.disableComponent('button_Previous');
        hyf.util.enableComponent('button_Next');

        triageMain.initBasedOnActivity();

        // set focus on the current tab
        $('a.selectedTab').focus();

        // For section 508 compliant date picker icon
        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });

        //TAEHO #164173 - Remove Attachment section in left-hand pane
        var ui = basicWIHActionClient.getUI();
        ui.getPane(ui.PANE_ATTACHMENT).hide();

        triageMain.overwriteWIHCommentButtonEventHandlers();

        BFLog.log('DEBUG', 'triageMain - init END');
    },

    setTabConfiguration: function(actName, tabs, readOnlyTabs) {
        if (actName != null)
        var len = triageMain.activityList.length;
        for (i=0; i<len; i++) {
            if (triageMain.activityList[i].name === actName) {
                if (tabs != null) {
                    triageMain.activityList[i].tabs = tabs;
                }
                if (readOnlyTabs != null) {
                    triageMain.activityList[i].tabs = tabs;
                }
                break;
            }
        }
    },

    checkUserRoleByRoleName: function(roleName) {
        var ret = false;
        try {
            var currentUser_UserGroups = $('#h_currentUserRoles').val();
            if (currentUser_UserGroups !== null && roleName !== null) {
                if (-1 < currentUser_UserGroups.indexOf(":" + roleName + ";")) {
                    ret = true;
                }
            }
        } catch (e) {
            ret = false;
        } finally {
            return ret;
        }
    },

    isCurrentUserHSAssistant: function() {
        return triageMain.checkUserRoleByRoleName("HR Assistants")
    },

    getCurrentProcessName: function() {
        var processName = BFActivityOption.getCurrentProcessName();
        return processName;
    },

    getCurrentActivityName: function() {
        var activityName = BFActivityOption.getActivityName();
        return activityName;
    },

    //Taeho
    addCommentEx: function() {
        try {
            window.parent.wihDiscussion.add();
            $("#btnRefreshComments").click();
        } catch (e) {
            console.log(e);
        }
    },

    //Taeho
    deleteCommentEx: function(procid, commentid) {
        try {
            var CONFIRM_DELETE_COMMENT = "Click OK to delete, or Cancel";
            if (confirm(CONFIRM_DELETE_COMMENT)) {
                window.parent.wihDiscussion.remove(procid, commentid);
            }
            $("#btnRefreshComments").click();
        } catch (e) {
            console.log(e);
        }
    },

    //Taeho
    modifyCommentEx: function() {
        try {
            var currentCommentProcID = window.parent.currentCommentProcID;
            var currentCommentID = window.parent.currentCommentID;
            window.parent.wihDiscussion.modify(currentCommentProcID, currentCommentID);
            $("#btnRefreshComments").click();
        } catch (e) {
            console.log(e);
        }
    },

    //Taeho
    overwriteWIHCommentButtonEventHandlers: function() {
        var old_addComment;
        if (typeof window.parent.addComment != "undefined") {
            old_addComment = window.parent.addComment;
            window.parent.addComment = triageMain.addCommentEx;
        }

        var old_deleteComment;
        if (typeof window.parent.deleteComment != "undefined") {
            old_deleteComment = window.parent.deleteComment;
            window.parent.deleteComment = triageMain.deleteCommentEx;
        }

        var old_modifyComment;
        if (typeof window.parent.modifyComment != "undefined") {
            old_modifyComment = window.parent.modifyComment;
            window.parent.modifyComment = triageMain.modifyCommentEx;
        }
    },
    searchBizFlowMember: function(nameFieldId, emailFieldId, memberid) {
    var ajax_url = '/bizflowwebmaker/cdc_api/SearchCommon.do?memberid=';
    var dataFromApi = {};
    if (memberid != null) {
        memberid.replace("[U]", "");
        CDCCommon.ajaxCallXML(ajax_url + memberid)
            .done(function(data) {
                dataFromApi = $('record', data).map(function() {
                    return {
                        memberid: $("MEMBERID", this).text(),
                        name: $('NAME', this).text(),
                        email: $('EMAIL', this).text(),
                        pvmid: $('PVMID', this).text(),
                    };
                }).get();
                if (dataFromApi.length > 0 && dataFromApi != null) {
                    $("#" + nameFieldId).val(dataFromApi[0].name);
                    $("#" + emailFieldId).val(dataFromApi[0].email);
                    FormState.doAction(StateAction.changeText(nameFieldId, dataFromApi[0].name), false);
                    FormState.doAction(StateAction.changeText(emailFieldId, dataFromApi[0].email), false);
                }
            });
    }
    return dataFromApi;
}
}