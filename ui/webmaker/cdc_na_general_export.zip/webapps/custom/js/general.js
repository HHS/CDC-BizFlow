/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var naGen = {
    initSetupDone: false,
    lookup_paractions: [
        {"HM_ID": "Title 5", "PARActions":["Promotion", "Promotion NTE", "Change to Lower Grade", "Extension", "Reassignment"]},
        {"HM_ID": "Title 42", "PARActions":["Conversion", "Conversion NTE" , "Stipend Increase" , "Extension" , "Reassignment"]},
        {"HM_ID": "SES/SL/ST", "PARActions":["Conversion", "Conversion NTE" , "Stipend Increase" , "Extension" , "Reassignment"]}
    ],
    checkField: {
        name: 'genInitComplete',
        value: 'true'
    },
    
    //**Default values for First Load Fields */
    fields: [
        { name: 'HM_ID', firstValue: true },
        { name: 'PAR_ACTION_TYPE', firstValue: true },
        { name: 'TR_PRE_CONSUL_REQD', firstValue: true },
        
        { name: 'PAR_ACTION', value: "" },
        { name: 'ADMIN_CD', value: "" },
        { name: 'EMPL_ID', value: "" },
        { name: 'EMPL_NAME', value: "" },
        { name: 'POS_JOB_REQ_NUM', value: "" },
        { name: 'ORG_NAME', value: "" },
        { name: 'ORG_NAME_LVL1', value: "" },
        { name: 'ORG_NAME_LVL2', value: "" },
        { name: 'ORG_NAME_LVL3', value: "" },
        { name: 'ORG_NAME_LVL4', value: "" },
        { name: 'ORG_NAME_LVL5', value: "" },

        { name: 'SO_AutoComplete', value: "" },
        { name: 'SO_EMAIL', value: "" },
        { name: 'CIO_AutoComplete', value: "" },
        { name: 'CIO_EMAIL', value: "" },
        { name: 'HROS_AutoComplete', value: "" },
        { name: 'HROS_EMAIL', value: "" },
        { name: 'CLASS_SPEC_AutoComplete', value: "" },
        { name: 'CLASS_SPEC_EMAIL', value: "" },
        { name: 'HROA_AutoComplete', value: "" },
        { name: 'HROA_EMAIL', value: "" },
        
        { name: 'CAPHR_REMARKS', value: '' },
        
        { name: 'PROPOSED_EFFECTIVE_DATE', value: '' },
        { name: 'TR_PRE_CONSUL_MTG_DATE', value: '' }
    ],
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        if (fieldState && fieldState.dirty) {
            switch (field) {
                case "ADMIN_CD":
                    var ajax_url = '/bizflowwebmaker/cdc_api/Organization.do?parentOrg=';

                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL1', ''), false);
                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL2', ''), false);
                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL3', ''), false);
                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL4', ''), false);
                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL5', ''), false);

                    if (fieldState.value.length > 0) {
                        CDCCommon.ajaxCallXML(ajax_url + fieldState.value + '!')
                            .done(function(data) {
                                var dataFromApi = $('record', data).map(function() {
                                    return {
                                        fldid: $("FLDID", this).text(),
                                        org_desc: $('ORG_DESC', this).text(),
                                        ac_admin_cd: $('AC_ADMIN_CD', this).text()
                                    };
                                }).get();

                                $.map(dataFromApi, function(item) {
                                    FormState.doAction(StateAction.changeText(item['fldid'], item['org_desc']), true);
                                    return null;
                                });
                            });
                    }
                    $('#ADMIN_CD').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');
                    break;
                    
                case "HM_ID":
                    var hiringMethod = FormState.getState('HM_ID');
                    var parActionTypeState = FormState.getState('PAR_ACTION_TYPE');                    
                    var parActionTypeOptions;
                    var parActionType = $('#PAR_ACTION_TYPE');

                    if(self.initSetupDone === true ){
                        parActionType.find('option').remove();
                        parActionType.append('<option value="">Select One</option>');                     
                    }
                    
                    //if(hiringMethod && hiringMethod.value === 'Title 5'){
                    if(hiringMethod && hiringMethod.value === self.lookup_paractions[0].HM_ID && hiringMethod.value === 'Title 5'){
                        //parActionTypeOptions = LookupManager.findByLTYPE('Title5_ParActionType');
                        parActionTypeOptions = self.lookup_paractions[0].PARActions ;
                        
                    } else {
                        //parActionTypeOptions = LookupManager.findByLTYPE('NonTitle5_ParActionType');
                        parActionTypeOptions = self.lookup_paractions[1].PARActions ;
                    }
                    
                    parActionTypeOptions.forEach(function(parActionTypeOption){
                        //parActionType.append('<option value="' + parActionTypeOption.LABEL + '">' + parActionTypeOption.LABEL + '</option>');
                        parActionType.append('<option value="' + parActionTypeOption + '">' + parActionTypeOption + '</option>');
                    });
                    $('#pv_hiringMethod').val(fieldState.value);
                    $('#HM_ID').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');
                break;
                    
                case 'PAR_ACTION_TYPE':
                    FormState.doAction(StateAction.changeSelect('PAR_ACTION_TYPE', fieldState.value), false);
                    $('#pv_parActionType').val(fieldState.value);
                break;
                
                case 'PAR_ACTION':
                    if(self.initSetupDone === true){
                        FormState.doAction(StateAction.changeSelect('PAR_ACTION', fieldState.value,fieldState.value), false);
                        $('#pv_parAction').val(fieldState.value);
                    } else {
                        var parActionVal = FormState.getState('PAR_ACTION');               
                        if(parActionVal && parActionVal.value ) {
                            if(self.getTriageType() !==undefined && self.getTriageType() === 'PAR'){
                                FormState.doAction(StateAction.changeSelect('PAR_ACTION', parActionVal.value,parActionVal.value), false);
                                $('#pv_parAction').val(parActionVal.value);
                            } else {
                                FormState.doAction(StateAction.changeSelect('PAR_ACTION', '',''), false);    
                                $('#pv_parAction').val('');
                            }      
                        } else {}
                    }
                    $('#PAR_ACTION').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');                    
                break;                

                case 'EMPL_ID':
                    if(self.getTriageType() === 'PAR'){
                        $('#EMPL_ID').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');
                    } else {
                        $('#EMPL_ID').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');
                    }
                    //$('#pv_empId').val(fieldState.value);                        
                break;                

                case 'EMPL_NAME':
                    if(self.getTriageType() === 'PAR'){
                        $('#EMPL_NAME').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');
                    } else {
                        $('#EMPL_NAME').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');                    
                    }                     
                    //$('#pv_empName').val(fieldState.value);
                break;                

                case 'POS_JOB_REQ_NUM':
                    if(self.getTriageType() === 'JR'){
                        $('#POS_JOB_REQ_NUM').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');
                    } else {
                        CDCCommon.hideField('POS_JOB_REQ_NUM', true, '');
                    }
                    //$('#pv_jobRequestNumber').val(fieldState.value);                    
                break;                
                
                case 'PROPOSED_EFFECTIVE_DATE':
                    if (fieldState.value) {
                        var dateParts = fieldState.value.split('/');
                        var dateString = dateParts[2] + '/' + dateParts[0] + '/' + dateParts[1] + ' 12:00:00';
                        $('#pv_effectiveDate').val(dateString);
                    }
                    if(self.getTriageType() === 'PAR'){
                        $('#PROPOSED_EFFECTIVE_DATE').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');
                    } else {
                        $('#PROPOSED_EFFECTIVE_DATE').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');                    
                    }                     
                    break;
                    
                case 'TR_PRE_CONSUL_REQD':
                    var preConsultRequired = fieldState.value;                    
                    var pv_isPreConsultEmailSent = $("#pv_isPreConsultEmailSent").val();
                    if (preConsultRequired && "Yes" === preConsultRequired) {
                        hyf.util.disableComponent('button_Submit1');
                        hyf.util.enableComponent('button_SendEmailForPreConsultation');
                        hyf.util.showComponent("lg_PreConsultationMeetingDate", false, null, null);                        
                    } else {
                        hyf.util.enableComponent('button_Submit1');
                        hyf.util.disableComponent('button_SendEmailForPreConsultation');
                        if (pv_isPreConsultEmailSent && "Yes" === pv_isPreConsultEmailSent) {
                            hyf.util.showComponent("lg_PreConsultationMeetingDate", false, null, null);
                        } else {
                            hyf.util.hideComponent("lg_PreConsultationMeetingDate", false, null, null);
                            $('#TR_PRE_CONSUL_MTG_DATE').val("");                            
                        }
                    }                    
                    $('#pv_preConsultReq').val(fieldState.value);
                    break;
                    
                case 'TR_PRE_CONSUL_MTG_DATE':
                    if (fieldState.value) {
                        var datePartsMtg = fieldState.value.split('/');
                        var dateStringMtg = datePartsMtg[2] + '/' + datePartsMtg[0] + '/' + datePartsMtg[1] + ' 12:00:00';
                        $('#button_Submit1').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');
                        $('#pv_meetingDate').val(dateStringMtg);                        
                    } else {}
                break;
                    
            }
        }
    },
    renderer: function() {
        console.log('naGen renderer Start');
        var self = this;
		if (!self.initSetupDone){
			self.initSetup();
			self.initSetupDone = true;
		}
        
        self.actionOnChange('PAR_ACTION');
        self.actionOnChange('ADMIN_CD');
        self.actionOnChange('HM_ID');
        self.actionOnChange('PAR_ACTION_TYPE');        
        self.actionOnChange('PROPOSED_EFFECTIVE_DATE');
        self.actionOnChange('EMPL_ID');       
        self.actionOnChange('EMPL_NAME');
        self.actionOnChange('POS_JOB_REQ_NUM');        
        //self.actionOnChange('TR_PRE_CONSUL_REQD');        
        //self.actionOnChange('TR_PRE_CONSUL_MTG_DATE');     
        
        console.log('naGen renderer End');
    },
	initSetup: function(){
		CDCCommon.setupFirstLoad(self.checkField, self.fields);
	},
    getTriageType: function() {
        var triageType = FormState.getState('TRIAGE_TP');
        return triageType.value;
    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        CDCCommon.setAutoComplete('group_general', this.mappers, this.reduxBindFix);
        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });
        
        $('#PROPOSED_EFFECTIVE_DATE').on('change', function() {
            var selectedDateText = $(this).val();
            if (selectedDateText) {
                var selectedDate = new Date(selectedDateText);
                var now = new Date();
                if (!(selectedDate > now)) {
                    alert('NTE must be in future -OR- Invalid NTE Date');
                    FormState.doAction(StateAction.changeText('PROPOSED_EFFECTIVE_DATE', ''), true);
                    $(this).focus();
                }else{ 
                    $('#button_Submit1').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');
                    $('#pv_effectiveDate').val(selectedDate);
                }
            }
        });
        
    },
    mappers: {

        ADMIN_CD: function() {
            return {
                AC_ADMIN_CD: $("AC_ADMIN_CD", this).text(),
                AC_ADMIN_CD_DESCR: $('AC_ADMIN_CD_DESCR', this).text()
            }
        },
        SO_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        },
        CIO_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        },
        HROS_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        },
        CLASS_SPEC_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        },
        HROA_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        }
    },
    reduxBindFix: function() {
        if (!$(this).data('autocomplete')) {
            FormState.doAction(StateAction.changeText($(this).attr('id'), $(this).val()), false);
        }
    }
}