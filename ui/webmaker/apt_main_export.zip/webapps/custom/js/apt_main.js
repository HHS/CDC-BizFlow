var aptMain = {

    initialXML: "",

    CONST_ALL_FORM_READONLY_FALSE: false,
    CONST_ALL_FORM_READONLY_TRUE: true,

    activityList: [{
        name: 'Prepare Draft ATC',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab8', 'tab9'],
        readonly: [],
        mandatoryCommentButtons: []
    }, {
        name: 'Track Clearances and Finalize Package/ATC',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab8', 'tab9'],
        readonly: [],
        mandatoryCommentButtons: []
    }, {
        name: 'Provide Second ATC Approval',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab8', 'tab9'],
        readonly: ['tab1', 'tab2', 'tab3'],
        mandatoryCommentButtons: ['button_Return3']
    }, {
        name: 'Provide Third ATC Approval',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab8', 'tab9'],
        readonly: ['tab1', 'tab2', 'tab3'],
        mandatoryCommentButtons: ['button_Return4']
    }, {
        name: 'Verify Position Build',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab8', 'tab9'],
        readonly: ['tab1', 'tab2', 'tab3'],
        mandatoryCommentButtons: ['button_Return5']
    }, {
        name: 'Complete TSA Processing',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab8', 'tab9'],
        readonly: ['tab1', 'tab2', 'tab3', 'tab4'],
        mandatoryCommentButtons: ['button_Return6', 'button_ReturnToPMSteward']
    }, {
        name: 'Provide TSA Approval',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab8', 'tab9'],
        readonly: ['tab1', 'tab2', 'tab3', 'tab4'],
        mandatoryCommentButtons: ['button_Return7', 'button_ReturnToPMSteward7', 'button_ReturnToTSAProcessor7']
    }],

    tabList: [{
        id: 'tab1',
        targetUrl: '/apt_general/general.do',
        targetGroup: 'partial_tab1',
        name: 'General',
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function() {
            if (aptGen.postEnableTab !== undefined) {
                aptGen.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (aptGen.postDisableTab !== undefined) {
                aptGen.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        postClearTabContents: function() {
        },
        renderer: function() {
            aptGen.renderer();
        },
        mainContainer: function() {
                return aptMain;
            }
    }, {
        id: 'tab2',
        targetUrl: '/apt_atc/atc.do',        
        targetGroup: 'partial_tab2',
        name: 'Approval to Commit',
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function () {
            return true;
        },
        postEnableTab: function() {
            if (aptAtc.postEnableTab !== undefined) {
                aptAtc.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (aptAtc.postDisableTab !== undefined) {
                aptAtc.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function () {
            aptAtc.renderer();
        },
        mainContainer: function() {
            return aptMain;  
        }
    }, {
        id: 'tab3',
        targetUrl: '/apt_staffing_approval/staffing_approval.do',        
        targetGroup: 'partial_tab3',
        name: 'Staffing Approval & Tracking',       
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function () {
            return true;
        },
        postEnableTab: function() {
            if (aptStaffApp.postEnableTab !== undefined) {
                aptStaffApp.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (aptStaffApp.postDisableTab !== undefined) {
                aptStaffApp.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function () {
            aptStaffApp.renderer();            
        },
        mainContainer: function() {
            return aptMain;  
        }
    }, {
        id: 'tab4',
        targetUrl: '/apt_pm_approval/pm_approval.do',        
        targetGroup: 'partial_tab4',
        name: 'Position Build Approval',        
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function () {
            return true;
        },
        postEnableTab: function() {
            if (aptPMApp.postEnableTab !== undefined) {
                aptPMApp.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (aptPMApp.postDisableTab !== undefined) {
                aptPMApp.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function () {
            aptPMApp.renderer();
        },
        mainContainer: function() {
            return aptMain;  
        }
    }, {
        id: 'tab5',
        targetUrl: '/apt_tsa_approval/tsa_approval.do',        
        targetGroup: 'partial_tab5',
        name: 'TSA Processing',
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function () {
            return true;
        },
        postEnableTab: function() {
            if (aptTSAApp.postEnableTab !== undefined) {
                aptTSAApp.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (aptTSAApp.postDisableTab !== undefined) {
                aptTSAApp.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function () {
            aptTSAApp.renderer();
        },
        mainContainer: function() {
            return aptMain;
        }
    }, {
        id: 'tab8',
        targetUrl: '/apt_resources/resources.do',
        targetGroup: 'partial_tab8',
        name: 'Resources',
        loaded: false,
        completed: false,
        disabledHeader: false,
        renderer: function() {
            aptResources.renderer();
        },
        mainContainer: function() {
            return aptMain;
        }
    }, {
        id: 'tab9',
        targetUrl: '/p2w_common/showAttachment.do',
        targetGroup: 'partial_tab9',
        name: 'Documents',
        loaded: false,
        completed: false,
        disabledHeader: false
    }],

    initBasedOnActivity: function() {
        
        if (BFUtility.isReadOnly() === true) {
            $('#bottomSection').hide();
            $('#layout_TabPreviousNext').hide();
            if (aptGen.postDisableTab !== undefined) {
                aptGen.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (aptAtc.postDisableTab !== undefined) {
                aptAtc.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_TRUE);
            }   
            if (aptStaffApp.postDisableTab !== undefined) {
                aptStaffApp.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (aptPMApp.postDisableTab !== undefined) {
                aptPMApp.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (aptTSAApp.postDisableTab !== undefined) {
                aptTSAApp.postDisableTab(aptMain.CONST_ALL_FORM_READONLY_TRUE);
            }            
            return;
        }

        BFLog.log('DEBUG', 'aptMain - initBasedOnActivity - START');

        var activityName = BFActivityOption.getActivityName();

        if (activityName === 'Prepare Draft ATC') {
            $('#h_hardStopRequired').val('true');
            $('#actionButton_Activity1').removeClass('hide');
            
            //The button will be always visible but disabled until user types in an HR Staffing Assistant at the first step (PREPARE DREAFT ATC)
            //in Appointment process. The button will be hidden once the task is forwarded.
            //hasForwardedToHRSA will be set to Yes once HR Staffing Specialist forwards workitem to HR Staffing Assistant.ss
            var pv_hasForwardedToHRSA = $("#pv_hasForwardedToHRSA").val();
            hyf.util.disableComponent('button_Forward_HRSA');
            if (pv_hasForwardedToHRSA === 'Yes') {
                $('#button_Forward_HRSA').addClass('hide');
            };            

            aptMain.addButtonHandler('button_Submit1', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_forwardHRSAssistant', value: 'No'
            }]);

            aptMain.addButtonHandler('button_Forward_HRSA', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_forwardHRSAssistant', value: 'Yes'
            }]);

        } else if (activityName === 'Track Clearances and Finalize Package/ATC') {
            $('#h_hardStopRequired').val('true');
            $('#actionButton_Activity2').removeClass('hide');
            aptMain.addButtonHandler('button_Submit2', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'No'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);

        } else if (activityName === 'Provide Second ATC Approval') {
            $('#h_hardStopRequired').val('true');
            $('#actionButton_Activity3').removeClass('hide');

            aptMain.addButtonHandler('button_Submit3', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'No'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);

            aptMain.addButtonHandler('button_Return3', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'Yes'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);


        } else if (activityName === 'Provide Third ATC Approval') {
            $('#h_hardStopRequired').val('true');
            $('#actionButton_Activity4').removeClass('hide');

            aptMain.addButtonHandler('button_Submit4', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'No'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);

            aptMain.addButtonHandler('button_Return4', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'Yes'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);
        
        } else if (activityName === 'Verify Position Build') {
            $('#h_hardStopRequired').val('true');
            $('#actionButton_Activity5').removeClass('hide');

            aptMain.addButtonHandler('button_Submit5', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'No'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);

            aptMain.addButtonHandler('button_Return5', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'Yes'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);


        } else if (activityName === 'Complete TSA Processing') {
            $('#h_hardStopRequired').val('true');
            $('#actionButton_Activity6').removeClass('hide');

            aptMain.addButtonHandler('button_Submit6', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'No'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);

            aptMain.addButtonHandler('button_ReturnToPMSteward', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'No'
            }, { id: 'pv_returnToPmSteward', value: 'Yes'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);

            aptMain.addButtonHandler('button_Return6', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'Yes'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);


        } else if (activityName === 'Provide TSA Approval') {
            $('#h_hardStopRequired').val('false');
            $('#actionButton_Activity7').removeClass('hide');

            aptMain.addButtonHandler('button_Submit7', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'No'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);

            aptMain.addButtonHandler('button_Return7', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'Yes'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);

            aptMain.addButtonHandler('button_ReturnToPMSteward7', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'No'
            }, { id: 'pv_returnToPmSteward', value: 'Yes'
            }, { id: 'pv_returnToTsaProcessor', value: 'No'
            }]);

            aptMain.addButtonHandler('button_ReturnToTSAProcessor7', false, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { id: 'pv_returnToHrStaffer', value: 'No'
            }, { id: 'pv_returnToPmSteward', value: 'No'
            }, { id: 'pv_returnToTsaProcessor', value: 'Yes'
            }]);

        } else {
            BFLog.log('DEBUG', 'aptMain - initBasedOnActivity() - No activity name matched [' + activityName + ']');
        }
        
        BFLog.log('DEBUG', 'aptMain - initBasedOnActivity - END');
    },

    addButtonHandler: function(buttonID, validationRequired, mandatoryDocValidationRequired, buttonOptions) {
        if (buttonID != null && buttonOptions != null) {
            $('#' + buttonID).off('click').click(function() {

                if (validationRequired === true) {
                    var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
                    for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                        var validated = TabManager.validateTab(activeTabs[tabIndex]);
                        if (validated === false) {
                            return;
                        }
                    }

                    if (mandatoryDocValidationRequired === true) {
                        var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
                        if (mandatoryDocumentsValid !== 'true') {
                            TabManager.enableTabHeader('tab9');
                            TabManager.enableTab('tab9');
                            $('#' + TabManager.getAnchorID('tab9')).click();
                            bootbox.alert('Please upload the missing required document(s).');
                            return;
                        }
                    }
                }

                if (buttonID === "button_Forward_HRSA") {
                    var hrsAssistant = $('#HROA_AutoComplete').val();
                    if (hrsAssistant == "") {
                        bootbox.alert("Please select the HR Staffing Assistant on the General tab")
                        return;
                    } else {
                        if ($('#pv_hrStaffingAssistant').val() != "") {                        
                            $('#pv_atcPreparer').val($('#pv_hrStaffingAssistant').val())
                        }
                    }
                }

                //setting comments required to complete workitem, adding button ids.
                var isCommentsRequired = false;
                var isCommentsEntered = false;
                var witemContext = basicWIHActionClient.getWorkitemContext();
                for (var i = 0; i < aptMain.activityList.length; i++) {
                    var activityInfo = aptMain.activityList[i];
                    if (activityInfo.name === witemContext.Activity.Name) {
                        console.log("found current activity info in aptMain.activityList - " + activityInfo.name);

                        if (typeof activityInfo.mandatoryCommentButtons != 'undefined') {
                            if (activityInfo.mandatoryCommentButtons.length > 0) {

                                //Checking action button(s) required to enter comments
                                for (var i = 0; i < activityInfo.mandatoryCommentButtons.length; i++) {
                                    buttonInfo = activityInfo.mandatoryCommentButtons[i];
                                    if (buttonID === buttonInfo) {
                                        console.log("found button requrired to enter a comment - " + buttonID);
                                        isCommentsRequired = true;
                                        var comments = basicWIHActionClient.getComments();
                                        for (var i = 0; i < comments.length; i++) {
                                            var comment = comments[i];
                                            //Current user has entered a comment in current workitem
                                            if (comment.activitySeq == witemContext.Activity.Sequence &&
                                                comment.workitemSeq == witemContext.Workitem.Sequence &&
                                                comment.creatorID == witemContext.User.MemberID) {

                                                isCommentsEntered = true;
                                                break;
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        break; //found the same activity from configuration.
                    };
                };

                console.log("isCommentsRequired=" + isCommentsRequired + ", isCommentsEntered=" + isCommentsEntered);
                if (isCommentsRequired && (isCommentsEntered == false)) {
                    basicWIHActionClient.setCommentRequired(true);
                };

                //set field value
                buttonOptions.forEach(function(option) {
                    try {
                        $('#' + option.id).val(option.value);
                    } catch (e) {
                        console.error("Cannot find field " + option.id);
                    }
                });
                
                //#210050, 210051 User Story - Update PVs to switch participant from group to current user.
                if (buttonID === "button_Submit5" 
                        || buttonID === "button_Return5" 
                        || buttonID === "button_Submit6"
                        || buttonID === "button_ReturnToPMSteward"  
                        || buttonID === "button_Return6") {
                    var actName = BFActivityOption.getActivityName();
                    if (actName === "Verify Position Build") {
                        $('#pv_pmSteward').val("[U]" + $('#h_currentUserMemberID').val());
                    } else if (actName === "Complete TSA Processing") {
                        $('#pv_tsaProcessor').val("[U]" + $('#h_currentUserMemberID').val());
                    }
                }

                var xml = FormState.getFinalStateXML();
                $('#h_formData').val(xml);

                BFUtility.greyOutScreen(true);

                BFUtility.submitFormPage(buttonID, 'saveNewForm');
            });
        } else {
            BFLog.log('DEBUG', 'aptMain - addButtonHandler() - buttonID or buttonOption is null.');
        }
    },

    loadForm: function() {
        console.log("aptMain.loadForm");
        var xml = $('#h_formData').val();
        FormState.initWithXML(aptMain.renderer, xml);
        _.forEach(aptMain.tabList, function(tab) {
            if (typeof tab.renderer === 'function') {
                FormState.addRenderer(tab.renderer);
            }
        });
        FormState.doRender();
    },

    onAllTabLoaded: function() {
        console.log("aptMain.onAllTabLoaded");

        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);
        BFUtility.initMaxSize(tabs);
        BFUtility.setDateIconTabOrder(tabs);

        aptMain.showHidePreNextButtons();
        $(document).on('ON_TAB_CHANGE', aptMain.onTabChange);

        if (activityName === 'Complete TSA Processing' || activityName === 'Provide TSA Approval') {
            var hiringMethod = "";
            if (FormState.getState("HM_ID") !== undefined) {
                hiringMethod = FormState.getState("HM_ID").value;
            }
            if (hiringMethod !== "Title 42") {
                $('#button_ReturnToPMSteward').removeClass('hide');
                $('#button_ReturnToPMSteward7').removeClass('hide');
            }
            if (hiringMethod !== "Title 5") {
                TabManager.hideTabHeader("tab4");
                BFActivityOption.removeTabFromCurrentActivity(activityName, "tab4");
            }
        }

        //store form data when form is loaded, it will be use to check if form is changed when user exits the form.
        setTimeout(aptMain.storeInitialXML, 1000);
    },

    //store form data when form is loaded, it will be use to check if form is changed when user exits the form.
    storeInitialXML: function() {
        initialXML = FormState.getFinalStateXML();
    },

    onErrorTabChange: function() {
        var tabId = TabManager.getSelectedTabID();
        aptGen.errorMsg(tabId);
    },

    onTabChange: function() {
        console.log("aptMain.onTabChange");
        if (BFUtility.isReadOnly() === false) {
            var xml = FormState.getFinalStateXML();
            $('#h_formData').val(xml);
            BFUtility.callPartialPage(null, 'saveTabContent.do', null, 'layoutForResponse2');
        }

        aptMain.showHidePreNextButtons();
    },

    renderer: function() {
        console.log("aptMain.renderer");
        //aptMain.actionOnChange('HM_ID');
        aptMain.actionOnChange('HROA_AutoComplete');
    },

    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        var activityName = BFActivityOption.getActivityName();
        if (fieldState !== undefined) {
            switch (field) {
                case 'HM_ID':
                    if (activityName === "Prepare Draft ATC") {
                        var pv_hasForwardedToHRSA = $("#pv_hasForwardedToHRSA").val();
                        if (pv_hasForwardedToHRSA === 'Yes') {
                            $('#button_Forward_HRSA').addClass('hide');
                        } else {
                            if (fieldState.value === "" || fieldState.value === "Title 42") {
                                $('#button_Forward_HRSA').addClass('hide');
                            } else {
                                $('#button_Forward_HRSA').removeClass('hide');
                            }
                        }
                    }
                    break;
                case 'HROA_AutoComplete':
                    if (activityName === "Prepare Draft ATC") {
                        var pv_hasForwardedToHRSA = $("#pv_hasForwardedToHRSA").val();
                        if (pv_hasForwardedToHRSA === 'Yes') {
                            $('#button_Forward_HRSA').addClass('hide');
                        } else {
                            if (fieldState.value !== "") {
                                hyf.util.enableComponent('button_Forward_HRSA');
                            } else {
                                hyf.util.disableComponent('button_Forward_HRSA');
                            }
                        }
                    } else {
                        $('#button_Forward_HRSA').addClass('hide');
                    }
                    break;
                default:
                    break;
            }
        }
    },

    showHidePreNextButtons: function() {
        var selectedTabID = TabManager.getSelectedTabID();
        var activeTabs = BFActivityOption.getTabList();

        var currentTabIndex = 0;
        for (var index = 0; index < activeTabs.length; index++) {
            if (activeTabs[index] === selectedTabID) {
                currentTabIndex = index;
                break;
            }
        }

        if (currentTabIndex === 0) {
            hyf.util.disableComponent('button_Previous');
            hyf.util.enableComponent('button_Next');
        } else if (currentTabIndex === activeTabs.length - 1) {
            hyf.util.enableComponent('button_Previous');
            hyf.util.disableComponent('button_Next');
        } else {
            BFUtility.enableComponents(['button_Previous', 'button_Next'])
        }
    },

    saveForm: function(e) {
        // store current tabid to reset after page reload
        $('#h_currentTabID').val(TabManager.getSelectedTabID()); 
        var xml = FormState.getFinalStateXML();
        $('#h_formData').val(xml);
        BFUtility.saveForm(e);
    },

    exitForm: function(btnId) {
        //TAEHO 05/31/2018 customize WIH exit message
        var xml = FormState.getFinalStateXML();
        var isFormChangedAfterLoaded = false;
        if (initialXML === xml || initialXML === "") {
            basicWIHActionClient.exit({confirmMsg: null,
                            eventFn: function(){return true}});
        } else {
            basicWIHActionClient.exit({confirmMsg: "Are you sure you want to quit without saving?",
                            eventFn: function(){return true}});
        }
    },

    cancelForm: function(btnId) {
        //TODO: populating cancellation reason from lookup table
        var reasons = LookupManager.findByLTYPE('CancellationReason');
        var options = '<option value>Select one</option>';
        reasons.forEach(function(reason) {
            options = options + '<option value=' + reason.LABEL + '>' + reason.LABEL + '</option>';
        });

        var dialog = bootbox.dialog({
            title: 'Reason for Cancellation',
            message: '<span>Cancellation Reason</span><span class="mandatory" style="" title="Mandatory field"> * </span><span>:&nbsp;</span><select name="CancellationReason">' + options + '</select>',
            onEscape: true,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success',
                    callback: function() {
                        var message = $('div.bootbox select option:selected').text();
                        if (message == null || message.length == 0) {
                            return false;
                        }

                        setTimeout(function() {
                            BFUtility.greyOutScreen(true);
                            $('#WIH_complete_requested').val('true');
                            $('#pv_requestStatus').val('Request Cancelled');
                            $('#pv_CancelReason').val(message);
                            BFUtility.submitFormPage(btnId, 'saveNewForm');
                        }, 0);
                    }
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-danger'
                }
            }
        });

        $('div.bootbox button.btn-success').prop('disabled', true);

        $('div.bootbox select').on('change keyup', function() {
            var message = $('div.bootbox select option:selected').val();
            if (message == '') {
                $('div.bootbox button.btn-success').prop('disabled', true);
            } else {
                $('div.bootbox button.btn-success').prop('disabled', false);
            }
        });
    },

    reasonForReturn_onchange: function() {
        console.log('aptMain.reasonForReturn_onchange');
    },
    
    rejectForm: function(btnId) {
        var reasons = LookupManager.findByLTYPE('ReasonForReturn_Appointment_TSA');
        var options = '<option value>Select one</option>';
        reasons.forEach(function(reason) {
            options = options + '<option value=' + reason.NAME + '>' + reason.LABEL + '</option>';
        });

        var dialog = bootbox.dialog({
            title: 'Reason for Return',
            message: '<p>Please select the reason(s) you are returning the case for modification. User the Comments box to provide more details if necessary.</p>'
                    + '<span>Return Reason</span><span class="mandatory" style="" title="Mandatory field"> * </span>'
                    + '<span>:&nbsp;</span>'
                    + '<select id="reasonForReturn" name="reasonForReturn" onchange="aptMain.reasonForReturn_onchange">' + options + '</select>'
                    + '<br/>'
                    + 'Comments<br/>'
                    + '<textarea></textarea>',
            onEscape: true,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success',
                    callback: function() {
                        var message = $('div.bootbox select option:selected').text();
                        if (message == null || message.length == 0) {
                            return false;
                        }

                        setTimeout(function() {
                            //BFUtility.greyOutScreen(true);
                            //$('#WIH_complete_requested').val('true');
                            //$('#pv_requestStatus').val('Request Cancelled');
                            $('#pv_CancelReason').val(message);
                            //BFUtility.submitFormPage(btnId, 'saveNewForm');
                        }, 0);
                    }
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-danger'
                }
            }
        });

        $('div.bootbox button.btn-success').prop('disabled', true);

        $('div.bootbox select').on('change keyup', function() {
            var message = $('div.bootbox select option:selected').val();
            if (message == '') {
                $('div.bootbox button.btn-success').prop('disabled', true);
            } else {
                $('div.bootbox button.btn-success').prop('disabled', false);
            }
        });
    },

    restoreBizFlowParameter: function() {
        var sessionInfo = $('#sessioninfo').attr('value');
        if (sessionInfo != null && sessionInfo.length > 0) { // Backup
            $('#sessioninfo2').attr('value', $('#sessioninfo').attr('value'));
            $('#procid2').attr('value', $('#procid').attr('value'));
            $('#actseq2').attr('value', $('#actseq').attr('value'));
            $('#workseq2').attr('value', $('#workseq').attr('value'));
            $('#appseq2').attr('value', $('#appseq').attr('value'));
            $('#isarchive2').attr('value', $('#isarchive').attr('value'));
            $('#readOnly2').attr('value', $('#readOnly').attr('value'));
        } else { // Restore
            $('#sessioninfo').attr('value', $('#sessioninfo2').attr('value'));
            $('#procid').attr('value', $('#procid2').attr('value'));
            $('#actseq').attr('value', $('#actseq2').attr('value'));
            $('#workseq').attr('value', $('#workseq2').attr('value'));
            $('#appseq').attr('value', $('#appseq2').attr('value'));
            $('#isarchive').attr('value', $('#isarchive2').attr('value'));
            $('#readOnly').attr('value', $('#readOnly2').attr('value'));
        }
    },

    errorMsg: function(tab) {
        var cnt = 0;
        var $errList = $('#errlist-' + tab);
        var $errCnt = $('#errcnt-' + tab);
        if ($errList.length > 0) {
            $errList.empty();
            $errCnt.text();
            $('span.hasError').each(function(key, value) {
                if (typeof $(":first-child", this).data('wm-error-msg') != 'undefined') { //Taeho 03/08/2018 - skip 'undefined' items.
                    cnt++;
                    $errList.append("<li>" + $(":first-child", this).data('wm-error-msg') + "</li>");
                }
            });
            if (cnt > 0) {
                $errCnt.text('There are ' + cnt + ' errors on the form.');
                $('#reqmsg-' + tab).focus()
            }
        }
    },
    //
    // Main ENTRY POINT
    //
    init: function() {
        BFLog.setLogLevel('DEBUG');
        BFLog.log('DEBUG', 'aptMain - init START');

        BFActivityOption.init(aptMain.activityList);

        LookupManager.init();
        // In order to send the BizFlow parameters to tab projects so that they can use the workitem context
        aptMain.restoreBizFlowParameter();

        // Notes:
        //  Tabs in Appointment tab are dynamically changed based upon Activity name, Request Type, and Employee Type.
        //  Therefore, Appointment Main form cannnot use pre-defined tab configuration above.
        //  The form must overwrite the tab configuration with activity name and field values.
        
        var activityName = BFActivityOption.getActivityName();
        if (BFUtility.isReadOnly() === true) {
            /*
            var readonlyTabs = ['tab1', 'tab2', 'tab3'];
            BFActivityOption.setReadOnlyTabList(activityName, readonlyTabs);
            */
        }
        
        TabManager.initTab(aptMain.tabList, aptMain.loadForm);
        $(document).on('HHS_ALL_TAB_LOADED', aptMain.onAllTabLoaded);

        //--------------------------------
        // static button event handler
        //----------------------------------------
        // save
        $('#button_SaveWorkitem').on('click', aptMain.saveForm);

        // Exit
        $('#button_ExitWIH').on('click', (function() {
            aptMain.exitForm('button_ExitWIH');
        }).bind(this));

        // Cancel
        $('#button_CancelWorkitem').on('click', (function() {
            //aptMain.cancelForm('button_CancelWorkitem');
            aptMain.rejectForm('button_CancelWorkitem');
        }).bind(this));

        // Previous
        $('#button_Previous').off('click').click(function(e) {
            TabManager.loadPreviousTab();
        });

        // Next
        $('#button_Next').off('click').click(function(e) {
            TabManager.loadNextTab();
        });

        // Request Date
        var requestedDateString = $('#h_creationdate').val();
        if (requestedDateString != null && requestedDateString.length > 0) {
            var requestedDate = new Date(requestedDateString); // requestedDateString is GMT
            var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
            var requestedDateLabel = BFUtility.getDateString({ isUTC: false, dateFormat: 'mm/dd/yyyy' }, newDate);
            $('#initiatedDate').text(requestedDateLabel);
        }

        hyf.util.disableComponent('button_Previous');
        hyf.util.enableComponent('button_Next');

        aptMain.initBasedOnActivity();

        // set focus on the current tab
        $('a.selectedTab').focus();

        // For section 508 compliant date picker icon
        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });

        //TAEHO #164173 - Remove Attachment section in left-hand pane
        var ui = basicWIHActionClient.getUI();
        ui.getPane(ui.PANE_ATTACHMENT).hide();

        if ($("#WIH_complete_requested").val() === "true") {
            try {
                aptMain.generateFiles();
            } catch (e) {
                alert("OF-8 generation error " + e);
            }
        }

        BFLog.log('DEBUG', 'aptMain - init END');
    },

    setTabConfiguration: function(actName, tabs, readOnlyTabs) {
        if (actName != null)
        var len = aptMain.activityList.length;
        for (i=0; i<len; i++) {
            if (aptMain.activityList[i].name === actName) {
                if (tabs != null) {
                    aptMain.activityList[i].tabs = tabs;
                }
                if (readOnlyTabs != null) {
                    aptMain.activityList[i].tabs = tabs;
                }
                break;
            }
        }
    },

    generateFiles: function() {
    
        console.log("generateFiles...");

        var item = basicWIHActionClient.getWorkitemContext();            
        var xml = $('#h_formData').val();
        FormState.initWithXML(aptMain.renderer, xml); //initialize formstate to access field values below

        var fdata = {
                        processid: item.Process.ID,
                        activityid: item.Activity.Sequence,
                        workitemseq: item.Workitem.Sequence,
        }

        var activityName = BFActivityOption.getActivityName();

        console.log("generateFiles... generating ATC file(s) when to complete the workitem");
        $.ajax({
                    type: 'POST',
                    url: '/bizflow/solutions/hhs/cdc/generate_atc.jsp',
                    data: fdata,
                    dataType: 'json',
                    cache: false,
                    success: function (response) {
                    }
                });
    },

    checkUserRoleByRoleName: function(roleName) {
        var ret = false;
        try {
            var currentUser_UserGroups = $('#h_currentUserRoles').val();
            if (currentUser_UserGroups !== null && roleName !== null) {
                if (-1 < currentUser_UserGroups.indexOf(":" + roleName + ";")) {
                    ret = true;
                }
            }
        } catch (e) {
            ret = false;
        } finally {
            return ret;
        }
    },

    isCurrentUserHSAssistant: function() {
        return aptMain.checkUserRoleByRoleName("HR Assistants")
    }

}