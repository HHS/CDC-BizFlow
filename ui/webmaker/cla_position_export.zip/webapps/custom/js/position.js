var claPosition = {

    //**For storing Grade List */
    gradeList: [],
    //**For storing Max Number of Grades Allowed - if changed, controls should be added/removed on the form */
    maxGrades: 9,
    //**Flag indicating whether initialization is done or not; needed for renderer function, otherwise it calls init section all the time */
    initSetupDone: false,
    //**Check Field for First Load check */
    checkField: {
        name: 'posInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
        { name: 'POS_TITLE', value: "" },
        { name: 'POS_ORG_TITLE', value: "" },
        { name: 'POS_PAY_PLAN_CODE', value: "" },
        { name: 'POS_SERIES', value: "" },
        { name: 'POS_TITLES_SERIES', value: '' },
        { name: 'POS_GRADE_ID', firstValue: true },
        { name: 'POS_GRADE_IDS', value: "" },
        { name: 'POS_GRADE_RELATED', value: "" },
        { name: 'POS_IS_PROMOTIONAL', firstValue: true },
        { name: 'POS_SENSITIVITY_ID', firstValue: true },
        { name: 'POS_SUPERVISORY_OR_NOT', firstValue: true },
        { name: 'POS_IS_BF_OR_VICE', firstValue: true },
        { name: 'POS_BF_VICE_NAME', firstValue: true },
        { name: 'POS_NO_BF_VICE_RSN', value: "" },
        { name: 'POS_SERVICE', firstValue: true },
        { name: 'POS_CAN', value: "" },
        { name: 'POS_EMPL_OFFICE', value: "" },
        { name: 'POS_DUTY_STATIONS', value: "" },
        { name: 'POS_REMARKS', value: "" }
    ],

    //**Function to get Hiring Method: Potential Output's Title 5, Title 42, SES/SL/ST */
    /*getHiringMethod: function(fieldState) {
        var self = this;
        var hiringMethod = '';
        if (!fieldState) {
            fieldState = FormState.getState('HM_ID');
        }
        if (fieldState && fieldState.text) {
            if (fieldState.text.indexOf('Title 5') === 0) {
                hiringMethod = 'Title 5';
            } else if (fieldState.text.indexOf('Title 42') === 0) {
                hiringMethod = 'Title 42';
            } else if (fieldState.text.indexOf('SES/SL/ST') === 0) {
                hiringMethod = 'SES/SL/ST';
            }
        }
        return hiringMethod;
    },
    */
    
    getHiringMethod: function() {
        var hiringMethod = FormState.getState('HM_ID');
        if (hiringMethod && hiringMethod.value) {
            return hiringMethod.value;
        } else {
            return "";
        }
    },
    
    //**Function to reset inUseByMain Flag and Full Performance Level */
    resetFPL: function() {
        var self = this;

        var fplFieldState = FormState.getState('POS_FULL_PERF_LEVEL');

        var gradesFieldState = FormState.getState('POS_GRADE_IDS');
        var selectedGrades = [];
        if (gradesFieldState && gradesFieldState.value && gradesFieldState.value !== '') {
            var grades = gradesFieldState.value.split('::');
            for (var i = 0; i < grades.length; i++) {
                selectedGrades.push(grades[i]);
            }
        }

        var fplDropDown = $("#POS_FULL_PERF_LEVEL");
        fplDropDown.find('option').remove();
        fplDropDown.append('<option value="">Select One</option>');
        var value = '';
        if (selectedGrades.length !== 0) {
            var minFPLStartLocation = 0;
            for (var i = 0; i < self.gradeList.length; i++) {
                if (self.gradeList[i].value !== '') {
                    if (CDCCommon.searchArray(selectedGrades, self.gradeList[i].value).index !== -1) {
                        if (minFPLStartLocation < i) minFPLStartLocation = i;
                    }
                }
            }

            for (var i = minFPLStartLocation; i < self.gradeList.length; i++) {
                if (self.gradeList[i].value !== '' && self.gradeList[i].text !== '00') {
                    fplDropDown.append('<option value="' + self.gradeList[i].value + '">' + self.gradeList[i].text + '</option>');
                }
            }
            if (!self.initSetupDone) {
                if (fplFieldState && fplFieldState.value) {
                    value = fplFieldState.value;
                }
            }
        }
        FormState.doAction(StateAction.changeSelect('POS_FULL_PERF_LEVEL', value), false);
    },

    setGradesDropDown: function(hiringMethod) {
        var self = this;
        var grDropDown = $("#POS_GRADE_ID");
        var selectedGrades = FormState.getState('POS_GRADE_IDS');
        var selectedGradesArray = [];
        if (selectedGrades && selectedGrades.value && selectedGrades.value !== '') {
            selectedGradesArray = selectedGrades.value.split("::");
        }
        grDropDown.find('option').remove();
        for (var i = 0; i < self.gradeList.length; i++) {
            var add = false;
            if (self.gradeList[i].value === '') {
                add = true;
            } else {
                switch (hiringMethod) {
                    case 'Title 5':
                        if (self.gradeList[i].text !== '00') {
                            add = CDCCommon.searchArray(selectedGradesArray, self.gradeList[i].value).index === -1;
                        }
                        break;
                    case 'Title 42':
                        if (self.gradeList[i].text === '00') {
                            CDCCommon.addData('POS_GRADE_IDS', '1300', '#grList', self.gradeList);
                            CDCCommon.hideField('POS_GRADE_ID', true);
                            CDCCommon.showField('POS_GRADE_ID');
                        }
                        break;
                    case 'SES/SL/ST':
                        if (self.gradeList[i].text === '00') {
                            CDCCommon.addData('POS_GRADE_IDS', '1300', '#grList', self.gradeList);
                            CDCCommon.hideField('POS_GRADE_ID', true);
                            CDCCommon.showField('POS_GRADE_ID');
                        }
                        break;
                }
            }
            if (add) {
                grDropDown.append('<option value="' + self.gradeList[i].value + '">' + self.gradeList[i].text + '</option>');
            }
        }
        FormState.doAction(StateAction.changeSelect('POS_GRADE_ID', ''), false);
        if ($('#grList').find('li').length < 1) {
                CDCCommon.noMultivalSelectedReminder('grList');             
        }
    },

    //**Function to reset Grades upon change in Hiring Method */
    resetGrades: function(hiringMethod, refresh) {
        var self = this;
        if (refresh) {
            FormState.doAction(StateAction.changeText('POS_GRADE_IDS', ''), false);
            CDCCommon.renderDisplay('POS_GRADE_IDS', '#grList', self.gradeList);
            self.setGradesDropDown(hiringMethod);
           if (hiringMethod === "Title 5") {
               CDCCommon.hideField('POS_GRADE_ID', true);
               CDCCommon.showField('POS_GRADE_ID', true);
           }
        }
    },

    //**Function to reset PD Number or SOD Number label upon change in Hiring Method */
    resetPDSODNumberLabel: function(hiringMethod, refresh) {
        if (refresh) {
            if (hiringMethod === "Title 42") {
                $('#POS_PD_NUM_00_label').text('SOD Number');
                var pos_pd_num = $('#POS_PD_NUM_00_label');                
                pos_pd_num.append('<span class="mandatory" id="POS_PD_NUM_00_marker" style="" title="Mandatory field"> * </span>');
            } else {
                $('#POS_PD_NUM_00_label').text('PD Number');
                var pos_pd_num = $('#POS_PD_NUM_00_label');                
                pos_pd_num.append('<span class="mandatory" id="POS_SOD_NUM_00_marker" style="" title="Mandatory field"> * </span>');
            }
        }
    },

    //**Function to reset Promotion Potential upon change in Hiring Method */
    resetPromtionPotential: function(hiringMethod, refresh) {
        var self = this;
        var show = true;
        switch (hiringMethod) {
            case 'Title 5':
                break;
            case 'Title 42':
                show = false;
                break;
            case 'SES/SL/ST':
                show = false;
                break;
        }
        if (refresh) {
            CDCCommon.showHideField(show, 'POS_IS_PROMOTIONAL', false, '');
        } else {
            CDCCommon.showHideField(show, 'POS_IS_PROMOTIONAL', false);
        }
    },

    //**Function to reset Backfill/Vice Name and Reason upon change in Hiring Method as well as Backfill/Vice */
    resetBFViceNameReason: function(fieldState, refresh) {
        CDCCommon.hideField('POS_BF_VICE_NAME', true);
        CDCCommon.hideField('POS_NO_BF_VICE_RSN', true);
        if (!fieldState) {
            fieldState = FormState.getState('POS_IS_BF_OR_VICE');
        }
        if (fieldState) {
            if (fieldState.value === 'No') {
                if (refresh) {
                    FormState.doAction(StateAction.changeText('POS_BF_VICE_NAME', ''), false);
                }
                CDCCommon.showField('POS_NO_BF_VICE_RSN');
            } else if (fieldState.value === 'Yes') {
                if (refresh) {
                    FormState.doAction(StateAction.changeText('POS_NO_BF_VICE_RSN', ''), false);
                }
                CDCCommon.showField('POS_BF_VICE_NAME', true);
            }
        }
    },

    //**Function for initial setup when the form is loaded */
    initSetup: function() {
        var self = this;

        var hiringMethod = self.getHiringMethod();
        var grFieldState = FormState.getState('POS_GRADE_IDS');
        CDCCommon.renderDisplay('POS_GRADE_IDS', '#grList', self.gradeList);
        if (grFieldState && grFieldState.value) {
            CDCCommon.hideField('POS_GRADE_ID', true, '');
            CDCCommon.showField('POS_GRADE_ID');
        } else {
            CDCCommon.noMultivalSelectedReminder('grList');
        }
        //FormState.doAction(StateAction.changeSelect('POS_GRADE_ID', self.gradeList[0].value), false);
        self.setGradesDropDown(hiringMethod);

        var tsFieldState = FormState.getState('POS_TITLES_SERIESES');
        if (tsFieldState && tsFieldState.value) {
            CDCCommon.renderDisplay('POS_TITLES_SERIESES', '#ptSrList');
            CDCCommon.hideField('POS_TITLE', true, '');
            CDCCommon.showField('POS_TITLE');
            CDCCommon.hideField('POS_SERIES', true, '');
            CDCCommon.showField('POS_SERIES');
        } else {
            CDCCommon.noMultivalSelectedReminder('ptSrList');
        }
    },

    //**Function that performs action when a particular field is changed (called from renderer function) */
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        var hiringMethod = self.getHiringMethod();
        if (fieldState && (fieldState.dirty === true || !self.initSetupDone)) {
            switch (field) {
                case 'REQUEST_TYPE':
                    if (fieldState.value === 'Classification Only' || fieldState.text === 'Classification Only') {
                        CDCCommon.hideField('POS_CAN', true, '');
                    } else {
                        CDCCommon.hideField('POS_CAN');
                        CDCCommon.showField('POS_CAN', true);
                    }						
                break;
                case 'HM_ID':
                    //**Show/hide/reset appropriate Pay Plan, Grades, Promotional Potential */
                    $('#position_main_lg').removeClass('hidden');
                    $('#position_error_lg').addClass('hidden');
                    hiringMethod = fieldState.value; //defeat a bug causing displaying "Please select Hiring Method on General Tab. On this (Position) Tab, there are lot of items dependent on Hiring Method to properly display them." error always.
                    if (hiringMethod === '') {
                        $('#position_main_lg').addClass('hidden');
                        $('#position_error_lg').removeClass('hidden');
                    } else {
                        //TBD: Pay Plan
                        self.resetGrades(hiringMethod, self.initSetupDone);
                        self.resetPromtionPotential(hiringMethod, self.initSetupDone);
                        self.resetBFViceNameReason(null, self.initSetupDone); //**Null for POS_IS_BF_OR_VICE fieldState when called from HM_ID change */
                        self.resetPDSODNumberLabel(hiringMethod, true);                        
                    }
                    break;
                case "POS_IS_BF_OR_VICE":
                    self.resetBFViceNameReason(fieldState, self.initSetupDone);
                    break;
                case "POS_IS_PROMOTIONAL":
                    if (fieldState.value === 'Yes') {
                        if (hiringMethod === 'Title 5' && self.initSetupDone) {
                            self.resetFPL();
                            CDCCommon.showField('POS_FULL_PERF_LEVEL', true);
                        }
                    } else {
                        FormState.doAction(StateAction.changeSelect('POS_FULL_PERF_LEVEL', ''), false);
                        CDCCommon.hideField('POS_FULL_PERF_LEVEL', true);
                    }
                    break;
                case "POS_REMARKS":
                    /*var length = fieldState.value.length;
                    var maxLength = $('#POS_REMARKS').attr("_maxlength");
                    if (!isNaN(maxLength)) {
                        if (parseInt(length) > parseInt(maxLength)) {
                            FormState.doAction(StateAction.changeText('POS_REMARKS', fieldState.value.substring(0, parseInt(maxLength)), false));
                            length = maxLength;
                        }
                        $('#remarksSizeDisplay').text("Now: " + length + " / Max: " + maxLength);
                    } else {
                        $('#remarksSizeDisplay').text("");
                    }
                    break;*/
            }
        }
    },

    //**Renderer function that is called from REDUX setup */
    renderer: function() {
        console.log("claPosition renderer Start");
        var self = this;
        CDCCommon.setupFirstLoad(self.checkField, self.fields);


        if (!self.initSetupDone) {
            self.resetFPL();
            self.initSetup();
            if (BFActivityOption.getActivityName() !== 'Submit PD/SOD for Classification') {
                self.gradeRelatedForm();
            }
        }
		      self.actionOnChange("REQUEST_TYPE");
        self.actionOnChange("HM_ID");
        self.actionOnChange("POS_IS_BF_OR_VICE");
        self.actionOnChange("POS_IS_PROMOTIONAL");
        self.actionOnChange('POS_REMARKS');

        self.initSetupDone = true;
        console.log("claPosition renderer End");
    },

    //**Mappers for Autocomplete */
    mappers: {
        POS_DUTY_STATIONS: function() {
            return {
                DS_VALUE: $('DS_VALUE', this).text()
            }
        },
        POS_EMPL_OFFICE: function() {
            return {
                DS_VALUE: $('DS_VALUE', this).text()
            }
        },
        POS_PAY_PLAN_CODE: function() {
            return {
                PAYPLAN_CODE: $('PAYPLAN_CODE', this).text(),
                PAYPLAN_DISPLAY: $('PAYPLAN_DISPLAY', this).text()
            }
        },
        POS_SERIES: function() {
            return {
                SERIES_CODE: $('SERIES_CODE', this).text(),
                SERIES_DISPLAY: $('SERIES_DISPLAY', this).text()
            }
        }
    },

    //**OnBlur handler for Autocomplete */
    reduxBindFix: function() {
        var control = $(this);
        if (control.data('js-autocomplete')) {
            FormState.doAction(StateAction.changeText(control.attr('id'), control.val()), false);
            if ((!control.val() || control.val === "") && control.attr("_required") === "false") {
                alert("Nothing selected from suggestions, value cleared");
            }
        }
    },
    gradeRelatedForm: function(editGradeRelated, hiringMethod) {
        var self = this;
        var PD_SOD_Num_lbl;
        if (hiringMethod === "Title 42") {
            PD_SOD_Num_lbl ="SOD Number";
        } else {
            PD_SOD_Num_lbl ="PD Number";
        }
        var gradeIds = FormState.getState('POS_GRADE_IDS');
        var gradeRelatedData = FormState.getState('POS_GRADE_RELATED');
        var inputBoxObj = '<div class="layoutContainerContent"><div class="controlContainer labelAbove"><div class="controlRow"><span class="labelBackground labelControl " id="::FLD::_label_container"><label class="label" for="::FLD::" id="::FLD::_label">::FLD_TITLE::<span class="mandatory" id="::FLD::_marker"  title="Mandatory field"> * </span></label></span></div><div class="controlRow"><span class="defaultBackground textboxControl  " id="::FLD::_container"><span class="controlBody isMandatory"><input class="textbox " data-wm-error-msg="::FLD_MSG::" id="::FLD::" name="::FLD::" title="::FLD_MSG::" type="text" value="::FLD_VAL::" data-grade="::FLD_DATA::" ></span></span></div></div></div><div class="layoutContainerSep"></div>';
        var flsaSelectObj = '<div class="layoutContainerContent"><div class="controlContainer labelAbove"><div class="controlRow"><span class="labelBackground labelControl " id="::FLD::_label_container"><label class="label" for="::FLD::" id="::FLD::_label">::FLD_TITLE::<span class="mandatory" id="::FLD::_marker" style="" title="Mandatory field"> * </span></label></span></div><div class="controlRow"><span class="defaultBackground selectControl  " id="::FLD::_container"><span class="controlBody isMandatory"><select class="select " data-wm-error-msg="FLSA is required for each grade" id="::FLD::" name="::FLD::" title="You must select a FLSA value for each grade added." _required="true" _type="string"><option value="">Select One</option><option value="Exempt">Exempt</option><option value="Non-Exempt">Non-Exempt</option></select><input name="::FLD::_xpath" type="hidden" value="/mvc:eForm/mvc:Data/mvc:formData/mvc:::FLD::"></span></span></div></div></div><div class="layoutContainerSep"></div>';
        var btnObj = '<div class="layoutContainerContent"><div class="controlContainer labelAbove"><div class="controlRow"><span class="defaultBackground buttonControl  " id="::FLD::_container"><span class="controlBody"><input class="button js-grade-related " data-grade="::FLD_DATA::" id="::FLD::" name="::FLD::" style="margin-top:25px" title="::FLD_MSG::" type="button" value="::FLD_TITLE::" _required="false" _type="string" _validate="false"></span></span></div></div></div>';
        var grades = [];
        var grRelatedArray = [];
        var grRelatedListData = '';
        var inputFlds = [{
                FLD: 'POS_JOB_CODE',
                FLD_TITLE: 'Job Code',
                FLD_MSG: 'A unique Job Code is required for each Grade',
                FLD_VAL: ''
            },
            {
                FLD: 'POS_PD_NUM',
                FLD_TITLE: PD_SOD_Num_lbl,
                FLD_MSG: 'A unique ' + PD_SOD_Num_lbl + ' is required for each Grade',
                FLD_VAL: ''
            },
            {
                FLD: 'POS_COMP_LEVEL',
                FLD_TITLE: 'Competitive Level Code',
                FLD_MSG: 'A Competitive Level Code is required for each Grade',
                FLD_VAL: ''
            }
        ];
        var flsaSel = {
            FLD: 'POS_FLSA',
            FLD_TITLE: 'FLSA',
            FLD_MSG: 'You must select a FLSA value for each Grade',
            FLD_VAL: ''
        };
        var btnSave = {
            FLD: 'SAVE_GRADE_RELATED',
            FLD_TITLE: 'Save Grade Related',
            FLD_MSG: 'Clicking the Save Grade Related button will save information related to the grade.'
        };

        if (!editGradeRelated) {
            if (gradeRelatedData) {
                var str = (gradeRelatedData.value).toString();
                var temp = str.split('::');
                CDCCommon.renderDisplay('POS_GRADE_RELATED', '#grRelatedList', null, true)
                for (var grr = 0; grr < temp.length; grr++) {
                    grRelatedArray[grr] = temp[grr].split('%%')[0];
                }

            }

            if (gradeIds && gradeIds.value) {
                var temp = self.getGradeValues(gradeIds.value);
                for (var i = 0; i < temp.length; i++) {
                    if (CDCCommon.searchArray(grRelatedArray, temp[i]).data !== temp[i]) {
                        grades.push(temp[i]);
                    }
                }
            }
        } else {
            var editGradeRelatedArray = editGradeRelated.split('%%');
            grades[0] = editGradeRelatedArray[0];
            flsaSel.FLD_VAL = editGradeRelatedArray[1];
            inputFlds[0].FLD_VAL = editGradeRelatedArray[2];
            inputFlds[1].FLD_VAL = editGradeRelatedArray[3];
            inputFlds[2].FLD_VAL = editGradeRelatedArray[4];
        }


        for (var g = 0; g < grades.length; g++) {

            var gradeForm = '<tr><td class="layoutContainerWrapper  fitHeight " id="" style="width:100%;"><div class="layoutContainer alignHorizontal alignLeft alignBottom ">';

            gradeForm += self.tokenReplacement(inputBoxObj, { FLD: 'GRADE', FLD_TITLE: 'Grade', FLD_MSG: '' }, grades[g], grades[g]).replace('class="textbox "', ' class="textbox multiValueSrc valueFreeze" readonly="readonly" ');

            gradeForm += self.tokenReplacement(flsaSelectObj, flsaSel, grades[g], flsaSel.FLD_VAL).replace('option value="' + flsaSel.FLD_VAL + '"', 'option value="' + flsaSel.FLD_VAL + '" selected=selected');

            for (var f = 0; f < inputFlds.length; f++) {
                gradeForm += self.tokenReplacement(inputBoxObj, inputFlds[f], grades[g], inputFlds[f].FLD_VAL);
            }
            gradeForm += self.tokenReplacement(btnObj, btnSave, grades[g]);
            gradeForm += "</div></td></tr>";

            $('#GRADE_RELATED_GRD').append(gradeForm);
        }

    },
    getGradeValues: function(gradeIdList) {
        var returnValue = [];
        var gradeId = gradeIdList.split('::');
        for (var i = 0; i < gradeId.length; i++) {
            returnValue.push(CDCCommon.searchArray(claPosition.gradeList, gradeId[i], "value").data.text);
        }
        return returnValue;
    },

    tokenReplacement: function(str, replaceObj, grade, value) {
        var tokenVal = (value) ? value : '';
        var returnStr = str.replace(/::FLD::/gi, replaceObj.FLD + "_" + grade).replace(/::FLD_TITLE::/gi, replaceObj.FLD_TITLE).replace(/::FLD_MSG::/gi, replaceObj.FLD_MSG).replace(/::FLD_DATA::/, grade).replace(/::FLD_VAL::/, tokenVal);
        return returnStr;
    },
    //Verify the Grade related data is unique//
    uniqueGradeRelatedData: function(checkValue, pd_or_sod) {
        var valArray = checkValue.split('%%');
        var gradeRelated = FormState.getState('POS_GRADE_RELATED');
        var gradeRelatedArray = new Array();

        if (gradeRelated && gradeRelated.value) {
            var tempArray = gradeRelated.value.split('::');

            for (var g = 0; g < tempArray.length; g++) {
                gradeRelatedArray[g] = tempArray[g].split('%%');
            }
        }
        for (var i = 0; i < valArray.length; i++) {
            if (!valArray[i]) {
                alert("You must provide values for FLSA, Job Code, " + pd_or_sod + " and Competitive Level Code. The " + pd_or_sod + " must be unique.");
                return false;
            } else {
                if (i === 3 && gradeRelated && gradeRelated.value) {
                    for (var gr = 0; gr < gradeRelatedArray.length; gr++) {

                        if (gradeRelatedArray[gr][i] == valArray[i]) {
                            alert("You must enter a unique " + pd_or_sod + " for each Grade.");
                            return false;
                        }
                    }
                }
            }
        }
        return checkValue;
    },
    resetPosGradeRelated: function() {
        FormState.doAction(StateAction.changeText('POS_GRADE_RELATED', ''), false);
    },
    //**Init function (called from onLoad page event) */
    init: function() {
        console.log("claPosition Init Start");
        var self = this;
        var currentStep = BFActivityOption.getActivityName();
        //**Set numeric only entry */

        $('.js-numericOnly').bind('keypress', function(e) {
            if (e.keyCode === '9' || e.keyCode === '16') {
                return;
            }
            var code;
            if (e.keyCode) code = e.keyCode;
            else if (e.which) code = e.which;
            if (e.which === 46)
                return false;
            if (code === 8 || code === 46 || code === 45)
                return true;
            if (code < 48 || code > 57)
                return false;
        });
        //**Load Grade list from Drop-down */
        $("#POS_GRADE_ID > option").each(function() {
            self.gradeList.push({
                value: $(this).val(),
                text: $(this).text()
            });
        });

        if (BFActivityOption.getActivityName() === 'Submit PD/SOD for Classification') {
            $('#GRADE_RELATED_ROW').addClass('hidden');
            //** Set Click Event Handler for Add and Delete (X) Grade buttons*/
            $("#ADD_GR").on('click', function() {
                var hiringMethod = self.getHiringMethod();
                var fieldState = FormState.getState('POS_GRADE_ID');
                if (fieldState && fieldState.value) {
                    CDCCommon.addData('POS_GRADE_IDS', fieldState.value, '#grList', self.gradeList);
                    self.setGradesDropDown(hiringMethod);
                    //FormState.doAction(StateAction.changeSelect('POS_GRADE_ID', self.gradeList[0].value), true);
                    CDCCommon.hideField('POS_GRADE_ID', true);
                    CDCCommon.showField('POS_GRADE_ID');
                    CDCCommon.removeRequired('POS_GRADE_ID');                    
                    if (hiringMethod === "Title 5") {
                        self.resetFPL();
                    }
                    $('#POS_GRADE_ID').focus();
                }
            });
            $('#POSITION_MAIN_GRID').on('click', '.js-POS_GRADE_IDS-delete', function(e) {
                e.preventDefault();
                var hiringMethod = self.getHiringMethod();
                CDCCommon.removeData('POS_GRADE_IDS', $(this).data("item"), '#grList', self.gradeList);
                self.setGradesDropDown(hiringMethod);
                var fieldState = FormState.getState('POS_GRADE_IDS');
                if (fieldState && (!fieldState.value || (fieldState.value).length === 0)) {
                    CDCCommon.hideField('POS_GRADE_ID');
                    CDCCommon.showField('POS_GRADE_ID', true);
                    CDCCommon.addRequired('POS_GRADE_ID');                    
                    CDCCommon.noMultivalSelectedReminder('grList');
                }
                if (hiringMethod === "Title 5") {
                    self.resetFPL();
                }
            });

        } else {
            //TODO: Set the group title
            $('#GRADE_ONLY_ROW').addClass('hidden');
            $('#GRADE_RELATED_GRD_label').text('Grade & Related Information');

            $('#position_main_lg').on('click', '.js-grade-related', function(e) {

                var grade = $(this).data('grade');
                var fieldState = $('#GRADE_' + grade).val();
                var flsa = $('#POS_FLSA_' + grade).val();
                var jobCode = $('#POS_JOB_CODE_' + grade).val();
                var pdNum = $('#POS_PD_NUM_' + grade).val();
                var compLevel = $('#POS_COMP_LEVEL_' + grade).val();
                //var currentRow = this.closest('tr').rowIndex;
                
               var hiringMethod = self.getHiringMethod();
               if (hiringMethod === "Title 42") {
                   PD_SOD_Num_lbl ="SOD Number";
               } else {
                   PD_SOD_Num_lbl ="PD Number";
               }
                
                var currentRow = $(this).closest('tr').index(); // defect User Story ID 214631 User is not able to add grade related info into Selected Grades and Related Information section

                var gradeRelatedData = self.uniqueGradeRelatedData(fieldState + '%%' + flsa + '%%' + jobCode + '%%' + pdNum + '%%' + compLevel, PD_SOD_Num_lbl);
                if (gradeRelatedData) {
                    CDCCommon.addData('POS_GRADE_RELATED', gradeRelatedData, '#grRelatedList', null, true);
                    document.getElementById("GRADE_RELATED_GRD").deleteRow(currentRow);

                }

            });
            $('#POSITION_MAIN_GRID').on('click', '.js-POS_GRADE_RELATED-delete,.js-POS_GRADE_RELATED-edit', function(e) {
                e.preventDefault();
                var hiringMethod = self.getHiringMethod();

                CDCCommon.removeData('POS_GRADE_RELATED', $(this).data("item"), '#grRelatedList', null, true);
                if ($(this).hasClass('js-POS_GRADE_RELATED-edit')) {
                    self.gradeRelatedForm($(this).data("item"), hiringMethod);
                } else {/*
                    var grade = $(this).data("item").split('%%')[0];
                    var gradeId = CDCCommon.searchArray(self.gradeList, grade, 'text');
                    CDCCommon.removeData('POS_GRADE_IDS', gradeId.data.value, '#grList', self.gradeList);*/  // defect ID 29973 
                }
                if (hiringMethod === "Title 5") {
                    self.resetFPL();
                }
            });
        }

        //** Set Click Event Handler for Add and Delete (X) Position/Series buttons*/
        $("#ADD_POS_SR").on('click', function() {
            var title = $('#POS_TITLE').val();
            var series = $('#POS_SERIES').val();
            if (title && title !== '' && series && series !== '') {
                CDCCommon.addData('POS_TITLES_SERIESES', title + '%%' + series, '#ptSrList');
                FormState.doAction(StateAction.changeSelect('POS_SERIES', ''), true);
                FormState.doAction(StateAction.changeSelect('POS_TITLE', ''), true);
                CDCCommon.hideField('POS_TITLE', true);
                CDCCommon.showField('POS_TITLE');
                CDCCommon.hideField('POS_SERIES', true);
                CDCCommon.showField('POS_SERIES');
                $('#POS_TITLE').focus();
            }
        });
        $('#position_main_lg').on('click', '.js-POS_TITLES_SERIESES-delete', function(e) {
            e.preventDefault();
            CDCCommon.removeData('POS_TITLES_SERIESES', $(this).data("item"), '#ptSrList');
            var fieldState = FormState.getState('POS_TITLES_SERIESES');
            if (fieldState && (!fieldState.value || (fieldState.value).length === 0)) {
                CDCCommon.hideField('POS_TITLE');
                CDCCommon.showField('POS_TITLE', true);
                CDCCommon.hideField('POS_SERIES');
                CDCCommon.showField('POS_SERIES', true);
                CDCCommon.noMultivalSelectedReminder('ptSrList');
            }
        });

        $('#GRADE_RELATED_GRD').on('click', '.textbox.multiValueSrc.valueFreeze', function(e) {
            e.preventDefault();
            var noteToUser = 'Note : To add, remove, or modify a grade, the workflow will need to be Returned for Modification.';
            if ($('#GRADE_RELATED_GRD').find('#li_noteToUser').length < 1){
                $('#grRelatedList').append('<li id="li_noteToUser">' + noteToUser + '</li>');
            }
        });
        
        $('#GRADE_RELATED_GRD').on('focusout', '.textbox.multiValueSrc.valueFreeze', function(e) { // blur
            e.preventDefault();
            if ($('#GRADE_RELATED_GRD').find('#li_noteToUser').length > 0){
                $('#li_noteToUser').remove();
            }
        });

        $(document).on("click change keyup keypress keydown",".textbox.autoExpandTextarea",function() {
            CDCCommon.addCurrTextlengthStatus($(document.activeElement));
        });
                          
        $(document).on("focusout",".textbox.autoExpandTextarea",function() {
            CDCCommon.removeCurrTextlengthStatus();
        });
        
        CDCCommon.setAutoComplete('position_main_lg', self.mappers, self.reduxBindFix);

        console.log("claPosition Init End");
    }
}