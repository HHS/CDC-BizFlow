var p2wResources = {

    //**Renderer action method, which expects changed field id/name as a parameter */
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        switch (field) {
            /**When Hiring Method changes; This form-control is on General Tab*/
            case "HM_ID":
                //**Show/hide appropriate resource links and descriptions */
                $("#resources_title5").addClass("hidden");
                $("#resources_title42").addClass("hidden");
                $("#resources_sessl").addClass("hidden");
                $("#resources_all").addClass("hidden");
                if (fieldState && fieldState.text) {
                    if (fieldState.text.indexOf('Title 5') === 0) {
                        $("#resources_title5").removeClass("hidden");
                    } else if (fieldState.text.indexOf('Title 42') === 0) {
                        $("#resources_title42").removeClass("hidden");
                    } else if (fieldState.text.indexOf('SES/SL') === 0) {
                        //Currently title 42 and SES/SL/St show the same resources 
                        $("#resources_title42").removeClass("hidden");
                    } else {
                        $("#resources_all").removeClass("hidden");
                    }
                } else {
                    $("#resources_all").removeClass("hidden");
                }
                break;
        }
    },

    /** Renderer Function */
    renderer: function() {
        console.log("p2wResources renderer Start");
        var self = this;
        self.actionOnChange("HM_ID"); //**This form-control is on General Tab */
        console.log("p2wResources renderer End");
    },

    /**Init Function */
    init: function() {
        console.log("p2wResources Init Start");
        var self = this;
        $("textarea[id$='LINK_DESCRIPTION']").attr('readonly', 'readonly');
        console.log("p2wResources Init End");
    }

}