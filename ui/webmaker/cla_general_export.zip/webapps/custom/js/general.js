/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var claGen = {
    initSetupDone: false,
    checkField: {
        name: 'genInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
        { name: 'REQUEST_TYPE', firstValue: true },
        { name: 'ADMIN_CD', value: "" },
        { name: 'HM_ID', firstValue: true },
        { name: 'EMPL_TYPE', firstValue: true },
        { name: 'ORG_NAME', value: "" },
        { name: 'ORG_NAME_LVL1', value: "" },
        { name: 'ORG_NAME_LVL2', value: "" },
        { name: 'ORG_NAME_LVL3', value: "" },
        { name: 'ORG_NAME_LVL4', value: "" },
        { name: 'ORG_NAME_LVL5', value: "" },
        { name: 'PROPOSED_ACTION', firstValue: true },
        { name: 'PA_OTHER_DESC', value: "" },
        { name: 'PROPOSE_REALIGNMENT', value: "" },
        { name: 'POS_STATUS', firstValue: true },
        { name: 'PD_NUMBER', value: "" },
        { name: 'SOD_NUMBER', value: "" },        
        { name: 'POS_JOB_REQ_NUM', value: "" },
        { name: 'PBMS_ID', value: "" },
        { name: 'SO_AutoComplete', value: "" },
        { name: 'SO_EMAIL', value: "" },
        { name: 'CIO_AutoComplete', value: "" },
        { name: 'CIO_EMAIL', value: "" },
        { name: 'HROS_AutoComplete', value: "" },
        { name: 'CIO_EMAIL', value: "" },
        { name: 'HROS_AutoComplete', value: "" },
        { name: 'HROS_EMAIL', value: "" },
        { name: 'HROS_ID', value: "" },
        { name: 'CLASS_SPEC_AutoComplete', value: "" },
        { name: 'CLASS_SPEC_EMAIL', value: "" },
        { name: 'CLASS_SPEC_ID', value: "" },
        { name: 'CAPHR_REMARKS', value: "" }
    ],
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        if (!self.initSetupDone) {
            CDCCommon.hideField('PA_OTHER_DESC', true, '');
            CDCCommon.hideField('PROPOSE_REALIGNMENT', true, '');
        }
        if (fieldState && fieldState.dirty) {
            switch (field) {
                case "ADMIN_CD":
                    var ajax_url = '/bizflowwebmaker/cdc_api/Organization.do?parentOrg=';

                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL1', ''), false);
                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL2', ''), false);
                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL3', ''), false);
                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL4', ''), false);
                    FormState.doAction(StateAction.changeText('ORG_NAME_LVL5', ''), false);

                    if (fieldState.value.length > 0) {
                        CDCCommon.ajaxCallXML(ajax_url + fieldState.value + '!')
                            .done(function(data) {
                                var dataFromApi = $('record', data).map(function() {
                                    return {
                                        fldid: $("FLDID", this).text(),
                                        org_desc: $('ORG_DESC', this).text(),
                                        ac_admin_cd: $('AC_ADMIN_CD', this).text()
                                    };
                                }).get();

                                $.map(dataFromApi, function(item) {
                                    FormState.doAction(StateAction.changeText(item['fldid'], item['org_desc']), true);
                                    return null;
                                });
                            });
                    }

                    break;
                case "PROPOSED_ACTION":
                    switch (fieldState.value) {
                        case "Other":
                            CDCCommon.showField('PA_OTHER_DESC', true);
                            $('#POS_JOB_REQ_NUM').attr('_required', 'false');
                            $('#POS_JOB_REQ_NUM_marker').addClass('hidden');
                            CDCCommon.hideField('PROPOSE_REALIGNMENT', true, '');
                            break;
                        case "New":
                            $('#POS_JOB_REQ_NUM').attr('_required', 'false');
                            $('#POS_JOB_REQ_NUM_marker').addClass('hidden');
                            CDCCommon.hideField('PA_OTHER_DESC', true, '');
                            CDCCommon.hideField('PROPOSE_REALIGNMENT', true, '');
                            break;
                        case "Realignment":
                            CDCCommon.showField('PROPOSE_REALIGNMENT', true);
                            CDCCommon.hideField('PA_OTHER_DESC', true, '');
                            if (FormState.getState('REQUEST_TYPE') && FormState.getState('REQUEST_TYPE').value !== 'Classification Only') {
                                $('#POS_JOB_REQ_NUM').attr('_required', 'true');
                                $('#POS_JOB_REQ_NUM_marker').removeClass('hidden');
                            }
                            break;
                        default:
                            CDCCommon.hideField('PROPOSE_REALIGNMENT', true, '');
                            CDCCommon.hideField('PA_OTHER_DESC', true, '');
                            if (FormState.getState('REQUEST_TYPE') && FormState.getState('REQUEST_TYPE').value !== 'Classification Only') {
                                $('#POS_JOB_REQ_NUM').attr('_required', 'true');
                                $('#POS_JOB_REQ_NUM_marker').removeClass('hidden');
                            }
                            break;
                    }
                    break;
                case "PROPOSE_REALIGNMENT":
                    FormState.doAction(StateAction.changeText('PROPOSE_REALIGNMENT_STR', fieldState.value), false);
                    break;
                case "EMPL_TYPE":
                    if(fieldState.value === 'Non-FTE'){
                        CDCCommon.showField('PBMS_ID', false);
                        CDCCommon.removeRequired('PBMS_ID');
                    } else {
                        CDCCommon.showField('PBMS_ID',true);
                        CDCCommon.addRequired('PBMS_ID');                        
                    }
                    break;                    
                case "HM_ID":
                    var proposedFieldState = FormState.getState('PROPOSED_ACTION');
                    $('#pv_hiringMethod').val(fieldState.value);
                    if (fieldState.value === 'Title 42') {
                        CDCCommon.showField('EMPL_TYPE', true);
                        FormState.doAction(StateAction.changeSelect('PROPOSED_ACTION', 'New', 'New'), false);
                        self.actionOnChange('PROPOSED_ACTION');
                        $('#PROPOSED_ACTION').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');
                        $('#HM_ID').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');
                        CDCCommon.hideField('PD_NUMBER', true, '');
                        CDCCommon.showField('SOD_NUMBER',false);
                    } else {
                        CDCCommon.hideField('EMPL_TYPE', true, '');
                        $('#PROPOSED_ACTION').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');
                        CDCCommon.hideField('SOD_NUMBER', true, '');
                        CDCCommon.showField('PD_NUMBER',false);                        
                    }
                    if (fieldState.value === 'SES/SL/ST') {
                        $('#LIMITED_ROW').removeClass('hidden');
                        CDCCommon.showField('LIMITED_TERM', false);
                        $('#HM_ID').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');                        
                    }
                    break;
                case "REQUEST_TYPE":
                    var pa = FormState.getState('PROPOSED_ACTION');
                    CDCCommon.addRequired('HROS_AutoComplete');
                    CDCCommon.addRequired('HROS_EMAIL');
                    $('#pv_requestType').val(fieldState.value);
                    if (fieldState.value === 'Classification Only') {
                        CDCCommon.removeRequired('HROS_AutoComplete');
                        CDCCommon.removeRequired('HROS_EMAIL');
                        CDCCommon.hideField('POS_JOB_REQ_NUM');
                    } else {
                        CDCCommon.showField('POS_JOB_REQ_NUM', pa && pa.value !== 'New' && pa.value !== 'Other');
                    }
                    break;
            }
        }
    },
    renderer: function() {

        console.log('claGen renderer Start');
        var self = this;
        CDCCommon.setupFirstLoad(self.checkField, self.fields);

        self.actionOnChange('REQUEST_TYPE');
        self.actionOnChange('ADMIN_CD');
        self.actionOnChange('PROPOSED_ACTION');
        self.actionOnChange('PROPOSE_REALIGNMENT');
        self.actionOnChange('EMPL_TYPE');
        self.actionOnChange('HM_ID');

        if (!self.initSetupDone) self.initSetupDone = true;

        console.log('claGen renderer End');

    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        CDCCommon.setAutoComplete('group_general', this.mappers, this.reduxBindFix);
        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });
    },
    mappers: {

        ADMIN_CD: function() {
            return {
                AC_ADMIN_CD: $("AC_ADMIN_CD", this).text(),
                AC_ADMIN_CD_DESCR: $('AC_ADMIN_CD_DESCR', this).text()
            }
        },
        SO_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        },
        CIO_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        },
        HROS_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        },
        CLASS_SPEC_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        }
    },
    reduxBindFix: function() {
        if (!$(this).data('autocomplete')) {
            FormState.doAction(StateAction.changeText($(this).attr('id'), $(this).val()), false);
        }
    }

}