/* global $ TabManager BFUtility BFActivityOption BFLog FormState StateAction bootbox hyf LookupManager _ */

var claMain = {

    //TAEHO 05/31/2018 to store initial form data, it will be used to compare form data when user exits the form.
    initialXML: "",

    CONST_ALL_FORM_READONLY_FALSE: false,
    CONST_ALL_FORM_READONLY_TRUE: true,

    activityList: [{
        name: 'Submit PD/SOD for Classification',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab8', 'tab9'],
        readonly: [],
        mandatoryCommentButtons: [] //Taeho 03/21/2018 - #159329 setting comments required to complete workitem, adding button ids.
    }, {
        name: 'Classify PD/SOD',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab8', 'tab9'],
        readonly: [],
        mandatoryCommentButtons: ['button_Return_CIO_Admin']
    }, {
        name: 'Provide Concurrence on Classification',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab8', 'tab9'],
        readonly: ['tab1', 'tab2', 'tab3', 'tab9'], //TAEHO 04/02/2018 #164838 - make tabs read only at the finize classificaiton step
        mandatoryCommentButtons: ['button_Return']
    }, {
        name: 'Provide Additional Concurrence on Classification',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab8', 'tab9'],
        readonly: ['tab1', 'tab2', 'tab3', 'tab9'], //TAEHO 04/02/2018 #164838 - make tabs read only at the finize classificaiton step
        mandatoryCommentButtons: ['button_Return']
    }, {
        name: 'Finalize Classification',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab8', 'tab9'],
        readonly: ['tab1', 'tab2', 'tab3'], //TAEHO #16963 - make tabs read only at the finize classificaiton step
        mandatoryCommentButtons: []
    }],

    tabList: [{
        id: 'tab1',
        targetUrl: '/cla_general/general.do',
        targetGroup: 'partial_tab1',
        name: 'General',
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function() {
            if (claGen.postEnableTab !== undefined) {
                claGen.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (claGen.postDisableTab !== undefined) {
                claGen.postDisableTab(claMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        postClearTabContents: function() {
            // $('#RI_OA_APRV_ITEM').val('NA');
        },
        renderer: function() {
            claGen.renderer();
        },
        mainContainer: function() {
                return claMain;
            }
            // onInit: function() {
            // }
    }, {
        id: 'tab2',
        targetUrl: '/cla_position/position.do',
        targetGroup: 'partial_tab2',
        name: 'Position',
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function() {
            return true;
        },
        postEnableTab: function() {
            if (claPosition.postEnableTab !== undefined) {
                claPosition.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (claPosition.postDisableTab !== undefined) {
                claPosition.postDisableTab(claMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function() {
            claPosition.renderer();
        },
        mainContainer: function() {
            return claMain;
        }
    }, {
        id: 'tab3',
        targetUrl: '/cla_classification/classification.do',
        targetGroup: 'partial_tab3',
        name: 'Classification',
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function() {
            return true;
        },
        postEnableTab: function() {
            if (claClassification.postEnableTab !== undefined) {
                claClassification.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (claClassification.postDisableTab !== undefined) {
                claClassification.postDisableTab(claMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function() {
            claClassification.renderer();
        },
        mainContainer: function() {
            return claMain;
        }
    }, {
        id: 'tab4',
        targetUrl: '/cla_concurrence/concurrence.do',
        targetGroup: 'partial_tab4',
        name: 'Concurrence',
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function() {
            return true;
        },
        postEnableTab: function() {
            if (claCon.postEnableTab !== undefined) {
                claCon.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (claCon.postDisableTab !== undefined) {
                claCon.postDisableTab(claMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function() {
            claCon.renderer();
        },
        mainContainer: function() {
            return claMain;
        }
    }, {
        id: 'tab8',
        targetUrl: '/cla_resources/resources.do',
        targetGroup: 'partial_tab8',
        name: 'Resources',
        loaded: false,
        completed: false,
        disabledHeader: false,
        renderer: function() {
            claResources.renderer();
        },
        mainContainer: function() {
            return claMain;
        }
    }, {
        id: 'tab9',
        targetUrl: '/p2w_common/showAttachment.do',
        targetGroup: 'partial_tab9',
        name: 'Documents',
        loaded: false,
        completed: false,
        disabledHeader: false
    }],

    initBasedOnActivity: function() {
        if (BFUtility.isReadOnly() === true) {
            $('#bottomSection').hide();
            $('#layout_TabPreviousNext').hide();
            if (claGen.postDisableTab !== undefined) {
                claGen.postDisableTab(claMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (claPosition.postDisableTab !== undefined) {
                claPosition.postDisableTab(claMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (claClassification.postDisableTab !== undefined) {
                claClassification.postDisableTab(claMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (claCon.postDisableTab !== undefined) {
                claCon.postDisableTab(claMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            return;
        }

        BFLog.log('DEBUG', 'claMain - initBasedOnActivity - START');

        var activityName = BFActivityOption.getActivityName();
        if (activityName === 'Submit PD/SOD for Classification') {
            $('#actionButton_Activity1').removeClass('hide');
            $('#h_hardStopRequired').val('true');
            //#20461 Taeho April 27th - fixing hard stop defect, 3rd parameter DocValidationRequired must be true.
            claMain.addButtonHandler('button_SubmitToHR', true, true, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }, {
                id: 'pv_returnToCIOAdmin',
                value: 'No'
            }]);
        } else if (activityName === 'Classify PD/SOD') {
            $('#actionButton_Activity2').removeClass('hide');
            $('#h_hardStopRequired').val('true');
            //#20461 Taeho April 27th - fixing hard stop defect, 3rd parameter DocValidationRequired must be true.
            claMain.addButtonHandler('button_SubmitToHiringManager', true, true, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }, {
                id: 'pv_returnToCIOAdmin',
                value: 'No'
            }]);
            claMain.addButtonHandler('button_Return_CIO_Admin', false, false, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }, {
                id: 'pv_returnToCIOAdmin',
                value: 'Yes'
            }]);            
        } else if (activityName === 'Provide Concurrence on Classification') {
            $('#actionButton_Activity3').removeClass('hide');
            $('#h_hardStopRequired').val('true');
            claMain.addButtonHandler('button_Submit', true, true, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }, {
                id: 'pv_returnToHr',
                value: 'No'
            }]);
            claMain.addButtonHandler('button_Return', false, false, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }, {
                id: 'pv_returnToHr',
                value: 'Yes'
            }]);
        } else if (activityName === 'Provide Additional Concurrence on Classification') {
            $('#actionButton_Activity3').removeClass('hide');
            $('#h_hardStopRequired').val('true');
            //#20461 Taeho April 27th - fixing hard stop defect, 3rd parameter DocValidationRequired must be true.
            claMain.addButtonHandler('button_Submit', true, true, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }, {
                id: 'pv_returnToHr',
                value: 'No'
            }]);
            claMain.addButtonHandler('button_Return', false, false, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }, {
                id: 'pv_returnToHr',
                value: 'Yes'
            }]);
        } else if (activityName === 'Finalize Classification') {
            $('#actionButton_Activity5').removeClass('hide');
            $('#h_hardStopRequired').val('true');
            claMain.addButtonHandler('button_EndClassification', true, true, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }]);
            //TAEHO 06/06/2018 - #182273 Start Recruitment Functionality
            claMain.addButtonHandler('button_StartRecruitment', true, true, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }]);
            //TAEHO 06/06/2018 - #182273 Start Appointment Functionality
            claMain.addButtonHandler('button_StartAppointment', true, true, [{
                id: 'WIH_complete_requested',
                value: 'true'
            }]);

            //TAEHO 06/06/2018 - #181043, #182273 Start Recruitment/Appointment/Classification Only Functionality
            $('#actionButton_Activity5').removeClass('hide');
            var pv_requestType = $("#pv_RequestType").text();   
            if ("Class/Appoint" === pv_requestType
                    || "Appointment with Classification" === pv_requestType) {
                $("#button_EndClassification").hide();
                $("#button_StartRecruitment").hide();
            } else if ("Class/Recruit" === pv_requestType
                    || "Recruitment with Classification" === pv_requestType) {
                $("#button_EndClassification").hide();
                $("#button_StartAppointment").hide();
            } else {
                $("#button_StartRecruitment").hide();
                $("#button_StartAppointment").hide();
            }    

        } else {
            BFLog.log('DEBUG', 'claMAIN - initBasedOnActivity() - No activity name matched [' + activityName + ']');          
        }

        //     if (BFUtility.isCurrentUserMemberOf('Selecting Officials') === true) {
        //         $('#button_cr_send_2').hide();
        //         claMain.addButtonHandler('button_cr_notify_2', true, [{
        //             id: 'WIH_complete_requested', value: 'true'
        //         }, {
        //             id: 'pv_requestStatus', value: 'Request Created'
        //         }, {
        //             id: 'pv_requestStatusDate', value: ''
        //         }, {
        //             id: 'pv_selectOfficialReviewReq', value: 'No'
        //         }]);
        //     } else {
        //         $('#button_cr_notify_2').hide();
        //         claMain.addButtonHandler('button_cr_send_2', true, [{
        //             id: 'WIH_complete_requested', value: 'true'
        //         }, {
        //             id: 'pv_requestStatus', value: 'Request Created'
        //         }, {
        //             id: 'pv_requestStatusDate', value: ''
        //         }, {
        //             id: 'pv_selectOfficialReviewReq', value: 'Yes'
        //         }]);
        //     }
        //     $('#actionButton_CreateRequest_2').removeClass('hide');
        // } else if (activityName === 'Activity 2') {
        //     claMain.addButtonHandler('button_rr_notify_2', true, [{
        //         id: 'WIH_complete_requested', value: 'true'
        //     }, {
        //         id: 'pv_requestStatusDate', value: ''
        //     }]);
        //     $('#actionButton_ReviewRequest_2').removeClass('hide');
        // } else {
        //     BFLog.log('DEBUG', 'STRATCONMAIN - initBasedOnActivity() - No activity name matched [' + activityName + ']');
        // }

        BFLog.log('DEBUG', 'claMain - initBasedOnActivity - END');
    },
    //addButtonHandler: function (buttonID, validationRequired, buttonOptions, confirmMessage) {
    addButtonHandler: function(buttonID, validationRequired, mandatoryDocValidationRequired, buttonOptions, confirmMessage) {
        if (buttonID != null && buttonOptions != null) {
            $('#' + buttonID).off('click').click(function() {
                if (validationRequired === true) {
                    var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
                    for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                        var validated = TabManager.validateTab(activeTabs[tabIndex]);
                        if (validated === false) {
                            return;
                        }
                    }

                    if (mandatoryDocValidationRequired === true) {
                        var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
                        if (mandatoryDocumentsValid !== 'true') {
                            TabManager.enableTabHeader('tab9');
                            TabManager.enableTab('tab9');
                            $('#' + TabManager.getAnchorID('tab9')).click();
                            bootbox.alert('Please upload the missing required document(s).');
                            return;
                        }
                    }

                }

                //Taeho 03/21/2018 - #159329 setting comments required to complete workitem, adding button ids.
                var isCommentsRequired = false;
                var isCommentsEntered = false;
                var witemContext = basicWIHActionClient.getWorkitemContext();
                for (var i = 0; i < claMain.activityList.length; i++) {
                    var activityInfo = claMain.activityList[i];
                    if (activityInfo.name === witemContext.Activity.Name) {
                        console.log("found current activity info in claMain.activityList - " + activityInfo.name);

                        if (typeof activityInfo.mandatoryCommentButtons != 'undefined') {
                            if (activityInfo.mandatoryCommentButtons.length > 0) {

                                //Checking action button(s) required to enter comments
                                for (var i = 0; i < activityInfo.mandatoryCommentButtons.length; i++) {
                                    buttonInfo = activityInfo.mandatoryCommentButtons[i];
                                    if (buttonID === buttonInfo) {
                                        console.log("found button requrired to enter a comment - " + buttonID);
                                        isCommentsRequired = true;
                                        var comments = basicWIHActionClient.getComments();
                                        for (var i = 0; i < comments.length; i++) {
                                            var comment = comments[i];
                                            //Current user has entered a comment in current workitem
                                            if (comment.activitySeq == witemContext.Activity.Sequence &&
                                                comment.workitemSeq == witemContext.Workitem.Sequence &&
                                                comment.creatorID == witemContext.User.MemberID) {

                                                isCommentsEntered = true;
                                                break;
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        break; //found the same activity from configuration.
                    };
                };

                //Taeho 03/21/2018 - #159329 setting comments required to complete workitem, adding button ids.                                
                console.log("isCommentsRequired=" + isCommentsRequired + ", isCommentsEntered=" + isCommentsEntered);
                if (isCommentsRequired && (isCommentsEntered == false)) {
                    //bootbox.alert("Please enter comments before submitting the form.");
                    //basicWIHActionClient.comment();
                    basicWIHActionClient.setCommentRequired(true);
                };

                //Taeho 04/19/2018 - #20640 Classification Concurrence tab - supervisory certification checkbox should be cleared if ever routed back to classifier
                if (buttonID === 'button_Return') {
                    if (claCon !== 'undefined') {
                        if (typeof claCon.reworkClear === 'function') {
                            console.log('clearing concurrence fields for return for modification');
                            claCon.reworkClear();
                        }
                    }
                }
                
                if (buttonID === 'button_Return_CIO_Admin') {
                    if (claPosition !== 'undefined') {
                        if (typeof claPosition.resetPosGradeRelated === 'function') {
                            console.log('resetting Position Grade Related data before returning for modification');
                            claPosition.resetPosGradeRelated();
                        }
                    }
                }

                if (confirmMessage != null && confirmMessage.length > 0) {
                    bootbox.dialog({
                        message: '<p class="bootbox-body">' + confirmMessage + '</p>',
                        onEscape: true,
                        buttons: [{
                            label: 'Yes',
                            className: 'btn-success',
                            callback: function() {
                                buttonOptions.forEach(function(option) {
                                    //if (option.id === 'pv_requestStatusDate') {
                                    if (option.id === 'pv_requestStatusDate' || option.id === 'pv_packageSubmissionDate') {
                                        option.value = BFUtility.getNowUTCString();
                                    }
                                    $('#' + option.id).val(option.value);
                                })
                                BFUtility.greyOutScreen(true);
                                var xml = FormState.getFinalStateXML();
                                $('#h_formData').val(xml);
                                BFUtility.submitFormPage(buttonID, 'saveNewForm');
                            }
                        }, {
                            label: 'No',
                            className: 'btn-danger'
                        }]
                    });
                } else {
                    buttonOptions.forEach(function(option) {
                        //if (option.id === 'pv_requestStatusDate') {
                        if (option.id === 'pv_requestStatusDate' || option.id === 'pv_packageSubmissionDate') {
                            option.value = BFUtility.getNowUTCString();
                        }
                        $('#' + option.id).val(option.value);
                    })
                    BFUtility.greyOutScreen(true);
                    var xml = FormState.getFinalStateXML();
                    $('#h_formData').val(xml);
                    BFUtility.submitFormPage(buttonID, 'saveNewForm');
                }
            });
        } else {
            BFLog.log('DEBUG', 'claMain - addButtonHandler() - buttonID or buttonOption is null.');
        }
    },

    // Request Type in General Tab
    resetRequestType: function() {
        var requestTypeLabel = $('#RT_ID option:selected').text();
        var requestTypeValue = $('#RT_ID option:selected').val();

        if (requestTypeValue !== '') {
            $('#requestType').text(requestTypeLabel);
        } else {
            $('#requestType').text('');
        }
        TabManager.resetTabs();
    },
    // This function will be called after getRequestNumber.do is completed.
    resetRequestNumber: function() {
        var requestNumber = $('#h_response_requestNumber').val();
        FormState.doAction(StateAction.changeVariable('requestNumber', requestNumber));
        $('#pv_requestStatus').val('Request Created');
        var requestedStatusDate = $('#h_now').val();
        $('#pv_requestStatusDate').val(requestedStatusDate);
    },

    loadForm: function() {
        var xml = $('#h_formData').val();
        FormState.initWithXML(claMain.renderer, xml);
        _.forEach(claMain.tabList, function(tab) {
            if (typeof tab.renderer === 'function') {
                FormState.addRenderer(tab.renderer);
            }
        });

        FormState.doRender();
    },

    onAllTabLoaded: function() {
        BFLog.log('DEBUG', 'Received HHS_ALL_TAB_LOADED!');

        //
        // Code to remove certain tab based on certain condition.
        //
        // TabManager.clearTabContent(tabID);
        // TabManager.hideTabHeader(tabID);
        // BFActivityOption.removeTabFromCurrentActivity(activityName, tabID);

        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);
        BFUtility.initMaxSize(tabs);
        BFUtility.setDateIconTabOrder(tabs);

        claMain.showHidePreNextButtons();
        $(document).on('ON_TAB_CHANGE', claMain.onTabChange);
        //$(document).on('ON_ERROR_TAB_CHANGE', claMain.onErrorTabChange);

        //TAEHO 05/31/2018 #161528 -store form data when form is loaded, it will be use to check if form is changed when user exits the form.
        setTimeout(claMain.storeInitialXML, 1000);
    },

    //TAEHO 05/31/2018 #161528 -store form data when form is loaded, it will be use to check if form is changed when user exits the form.
    storeInitialXML: function() {
        initialXML = FormState.getFinalStateXML();
    },

    onErrorTabChange: function() {
        var tabId = TabManager.getSelectedTabID();
        claGen.errorMsg(tabId);
    },

    onTabChange: function() {
        if (BFUtility.isReadOnly() === false) {
            // var requestNumber = FormState.getState('requestNumber');
            // if (typeof requestNumber === 'undefined' || requestNumber.value == null  requestNumber.value.length === 0) {
            //     $('#h_now').val(BFUtility.getNowUTCString());
            //     BFUtility.callPartialPage(null, 'getRequestNumber.do', 'system', 'layoutForResponse');
            // };

            //var activityName = BFActivityOption.getActivityName();
            //var memberID = $('#h_currentUserMemberID').val();
            //var memberName = $('#h_currentUserName').val();
            //var xml = FormState.getFinalStateXML(activityName, memberID, memberName);
            var xml = FormState.getFinalStateXML();
            $('#h_formData').val(xml);

            BFUtility.callPartialPage(null, 'saveTabContent.do', null, 'layoutForResponse2');
        }

        claMain.showHidePreNextButtons();
    },

    renderer: function() {
        // var requestNumber = FormState.getState('requestNumber');
        // if (requestNumber && requestNumber.value && requestNumber.dirty === true) {
        //     $('#requestNumber').text(requestNumber.value);
        // }
    },

    showHidePreNextButtons: function() {
        var selectedTabID = TabManager.getSelectedTabID();
        var activeTabs = BFActivityOption.getTabList();

        var currentTabIndex = 0;
        for (var index = 0; index < activeTabs.length; index++) {
            if (activeTabs[index] === selectedTabID) {
                currentTabIndex = index;
                break;
            }
        }

        if (currentTabIndex === 0) {
            hyf.util.disableComponent('button_Previous');
            hyf.util.enableComponent('button_Next');
        } else if (currentTabIndex === activeTabs.length - 1) {
            hyf.util.enableComponent('button_Previous');
            hyf.util.disableComponent('button_Next');
        } else {
            BFUtility.enableComponents(['button_Previous', 'button_Next'])
        }
    },
    saveForm: function(e) {
        $('#h_currentTabID').val(TabManager.getSelectedTabID()); // store current tabid to reset after page reload

        // for updating the history. commented out for optimzation
        //var activityName = BFActivityOption.getActivityName();
        //var memberID = $('#h_currentUserMemberID').val();
        //var memberName = $('#h_currentUserName').val();
        //var xml = FormState.getFinalStateXML(activityName, memberID, memberName);
        var xml = FormState.getFinalStateXML();
        $('#h_formData').val(xml);
        BFUtility.saveForm(e);
    },
    exitForm: function(btnId) {
        //TAEHO 05/31/2018 customize WIH exit message
        var xml = FormState.getFinalStateXML();
        var isFormChangedAfterLoaded = false;
        if (initialXML === xml || initialXML === "") {
            basicWIHActionClient.exit({confirmMsg: null,
                            eventFn: function(){return true}});
        } else {
            basicWIHActionClient.exit({confirmMsg: "Are you sure you want to quit without saving?",
                            eventFn: function(){return true}});
        }
        //BFUtility.exitWitemHandler(btnId);
    },
    cancelForm: function(btnId) {
        var reasons = LookupManager.findByLTYPE('CancellationReason');
        var options = '<option value>Select one</option>';
        reasons.forEach(function(reason) {
            options = options + '<option value=' + reason.LABEL + '>' + reason.LABEL + '</option>';
        });

        var dialog = bootbox.dialog({
            title: 'Reason for Cancellation',
            message: '<span>Cancellation Reason</span><span class="mandatory" style="" title="Mandatory field"> * </span><span>:&nbsp;</span><select name="CancellationReason">' + options + '</select>',
            onEscape: true,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success',
                    callback: function() {
                        var message = $('div.bootbox select option:selected').text();
                        if (message == null || message.length == 0) {
                            return false;
                        }

                        setTimeout(function() {
                            BFUtility.greyOutScreen(true);
                            $('#WIH_complete_requested').val('true');
                            $('#pv_requestStatus').val('Request Cancelled');
                            $('#pv_CancelReason').val(message);
                            BFUtility.submitFormPage(btnId, 'saveNewForm');
                        }, 0);
                    }
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-danger'
                }
            }
        });

        $('div.bootbox button.btn-success').prop('disabled', true);

        $('div.bootbox select').on('change keyup', function() {
            var message = $('div.bootbox select option:selected').val();
            if (message == '') {
                $('div.bootbox button.btn-success').prop('disabled', true);
            } else {
                $('div.bootbox button.btn-success').prop('disabled', false);
            }
        });
    },
    restoreBizFlowParameter: function() {
        var sessionInfo = $('#sessioninfo').attr('value');
        if (sessionInfo != null && sessionInfo.length > 0) { // Backup
            $('#sessioninfo2').attr('value', $('#sessioninfo').attr('value'));
            $('#procid2').attr('value', $('#procid').attr('value'));
            $('#actseq2').attr('value', $('#actseq').attr('value'));
            $('#workseq2').attr('value', $('#workseq').attr('value'));
            $('#appseq2').attr('value', $('#appseq').attr('value'));
            $('#isarchive2').attr('value', $('#isarchive').attr('value'));
            $('#readOnly2').attr('value', $('#readOnly').attr('value'));
        } else { // Restore
            $('#sessioninfo').attr('value', $('#sessioninfo2').attr('value'));
            $('#procid').attr('value', $('#procid2').attr('value'));
            $('#actseq').attr('value', $('#actseq2').attr('value'));
            $('#workseq').attr('value', $('#workseq2').attr('value'));
            $('#appseq').attr('value', $('#appseq2').attr('value'));
            $('#isarchive').attr('value', $('#isarchive2').attr('value'));
            $('#readOnly').attr('value', $('#readOnly2').attr('value'));
        }
    },
    errorMsg: function(tab) {
        var cnt = 0;
        var $errList = $('#errlist-' + tab);
        var $errCnt = $('#errcnt-' + tab);
        if ($errList.length > 0) {
            $errList.empty();
            $errCnt.text();
            $('span.hasError').each(function(key, value) {
                if (typeof $(":first-child", this).data('wm-error-msg') != 'undefined') { //Taeho 03/08/2018 - skip 'undefined' items.
                    cnt++;
                    $errList.append("<li>" + $(":first-child", this).data('wm-error-msg') + "</li>");
                }
            });
            if (cnt > 0) {
                $errCnt.text('There are ' + cnt + ' errors on the form.');
                $('#reqmsg-' + tab).focus()
            }
        }
    },

    //
    // Main ENTRY POINT
    //
    init: function() {

        BFLog.setLogLevel('DEBUG');
        BFLog.log('DEBUG', 'claMain - init START');

        BFActivityOption.init(claMain.activityList);

        if (BFUtility.isReadOnly() === true) {
            var activityName = BFActivityOption.getActivityName();
            var readonlyTabs = ['tab1', 'tab2', 'tab3'];
            BFActivityOption.setReadOnlyTabList(activityName, readonlyTabs);
        }

        LookupManager.init();
        // In order to send the BizFlow parameters to tab projects so that they can use the workitem context
        claMain.restoreBizFlowParameter();

        TabManager.initTab(claMain.tabList, claMain.loadForm);
        $(document).on('HHS_ALL_TAB_LOADED', claMain.onAllTabLoaded);

        //--------------------------------
        // static button event handler
        //----------------------------------------
        // save
        $('#button_SaveWorkitem').on('click', claMain.saveForm);

        // Exit
        $('#button_ExitWIH').on('click', (function() {
            claMain.exitForm('button_ExitWIH');
        }).bind(this));

        // Cancel
        $('#button_CancelWorkitem').on('click', (function() {
            claMain.cancelForm('button_CancelWorkitem');
        }).bind(this));

        // Previous
        $('#button_Previous').off('click').click(function(e) {
            TabManager.loadPreviousTab();
        });

        // Next
        $('#button_Next').off('click').click(function(e) {
            TabManager.loadNextTab();
        });

        // Request Date
        var requestedDateString = $('#h_creationdate').val();
        if (requestedDateString != null && requestedDateString.length > 0) {
            var requestedDate = new Date(requestedDateString); // requestedDateString is GMT
            var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
            var requestedDateLabel = BFUtility.getDateString({ isUTC: false, dateFormat: 'mm/dd/yyyy' }, newDate);
            $('#initiatedDate').text(requestedDateLabel);
        }

        // // Request Number
        // var requestNumber = $('#h_requestNumber').val();
        // $('#requestNumber').text(requestNumber);

        // // Request Status
        // var requestStatus = $('#pv_requestStatus').val();
        // $('#output_requestStatus').text(requestStatus);

        hyf.util.disableComponent('button_Previous');
        hyf.util.enableComponent('button_Next');

        claMain.initBasedOnActivity();

        // set focus on the current tab
        $('a.selectedTab').focus();

        // For section 508 compliant date picker icon
        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });

        //TAEHO #164173 - Remove Attachment section in left-hand pane
        var ui = basicWIHActionClient.getUI();
        ui.getPane(ui.PANE_ATTACHMENT).hide();

        //WIH_save_requested
        //WIH_complete_requested

        if ($("#WIH_complete_requested").val() === "true") {
            try {
                claMain.generateFiles();
            } catch (e) {
                alert("OF-8 generation error " + e);
            }
        }
        
        BFLog.log('DEBUG', 'claMain - init END');
    },

    generateFiles: function() {
        
        console.log("generateFiles...");

        var item = basicWIHActionClient.getWorkitemContext();            
        var xml = $('#h_formData').val();
        FormState.initWithXML(claMain.renderer, xml); //initialize formstate to access field values below

        //#29108 NO OF8 if Hiring Method is Title 42
        var hiringMethod = "";
        if (FormState.getState("HM_ID") !== undefined) {
            hiringMethod = FormState.getState("HM_ID").value;
        } else {
            fdata.admincode = "";
        }

        if (hiringMethod === "Title 42") {
            console.log("Skipping OF-8 generation because Hiring Method is Title 42.");
        } else {
            var fdata = {
                            processid: item.Process.ID,
                            activityid: item.Activity.Sequence,
                            workitemseq: item.Workitem.Sequence,
            }

            var activityName = BFActivityOption.getActivityName();
            if (activityName == 'Submit PD/SOD for Classification') {
                fdata.generationmode = "initial";
            } else {
                fdata.generationmode = "auto";
            }

            if (FormState.getState("ADMIN_CD") !== undefined) {
                fdata.admincode = FormState.getState("ADMIN_CD").value;
            } else {
                fdata.admincode = "";
            }

            if (FormState.getState("POS_TITLES_SERIESES") !== undefined) {
                fdata.positiontitleseries = FormState.getState("POS_TITLES_SERIESES").value;    
            } else {
                fdata.positiontitleseries = "";
            }
            
            if (FormState.getState("POS_PAY_PLAN_CODE") !== undefined) {
                fdata.payplan = FormState.getState("POS_PAY_PLAN_CODE").value;
            } else {
                fdata.payplan = "";
            }
            //Get Grade Texts form Grade IDs
            var selectedGrades = "";
            var gradeTexts = "";
            if (FormState.getState("POS_GRADE_IDS") !== undefined) {
                selectedGrades = FormState.getState("POS_GRADE_IDS").value;
                var gradeId = null;
                var gradeIds = selectedGrades.split("::");
                try {
                    for (var i=0; i < gradeIds.length; i++) {
                        gradeId = gradeIds[i];
                        if (gradeTexts != null && gradeTexts !== "") {
                            gradeTexts += "::";
                        }                
                        gradeTexts += LookupManager.findByID(gradeId).LABEL;
                        console.log("[GRADE-ID] gradeId=" + gradeId + ", gradeTexts=" + gradeTexts);
                    }
                } catch (e) {
                    console.log(e);
                }            
            }
            
            fdata.gradetexts = gradeTexts;
            fdata.grades = selectedGrades;

            if (FormState.getState("PD_NUMBER") !== undefined) {
                fdata.pdnumber = FormState.getState("PD_NUMBER").value;
            } else {
                fdata.pdnumber = "";
            }

            console.log("generateFiles... generating OF-8 file(s) when to complete the workitem");
            $.ajax({
                        type: 'POST',
                        url: '/bizflow/solutions/hhs/cdc/generate_of8.jsp',
                        data: fdata,
                        dataType: 'json',
                        cache: false,
                        success: function (response) {
                        }
                    });
        }

    }
}