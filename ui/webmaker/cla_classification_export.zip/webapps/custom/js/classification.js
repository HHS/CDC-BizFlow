var claClassification = {

    //**Flag for indicating whether InitSetup is done or not  */
    initSetupDone: false,

    //**Array of object to hold financialStaementList, used for multi-value field */
    financialStatementList: [],

    //**Check Field for First Load check */
    checkField: {
        name: 'claInitComplete',
        value: 'true'
    },

    //**Default values for First Load Fields */
    fields: [
        { name: 'PHYSICIANS_COMPARABILITY_ALLOWANCE', firstValue: true },
        { name: 'DRUG_TEST_REQUIRED', firstValue: true },
        { name: 'PRE_EMPLOYMENT_PHYSICAL_REQUIRED', firstValue: true },
        { name: 'SELECT_AGENT_ACCESS_REQUIRED', firstValue: true },
        { name: 'SUBJECT_TO_ADDITIONAL_IDENTICAL', firstValue: true },
        { name: 'INCUMBENT_ONLY', firstValue: true },
        { name: 'COMMISSIONED_CORPS_ELIGIBLE', firstValue: true },
        { name: 'FINANCIAL_DISCLOSURE_REQUIRED', firstValue: true },
        { name: 'FINANCIAL_STATEMENT', firstValue: true },
        { name: 'FINANCIAL_STATEMENTS', value: '' },
        { name: 'CYBER_SECURITY_CODE', firstValue: true },
        { name: 'BARGAINING_UNIT_STATUS_CODE', firstValue: true },
        { name: 'ACQUISITION_CODE', firstValue: true },
        { name: 'CLASSIFICATION', value: '' },
        { name: 'CLASSIFICATIONS', value: '' },
        { name: 'OPM_CERTIFICATION_NO', value: '' },
        { name: 'OFFICIAL_REASON_SUB', value: '' },
        { name: 'CLA_EXP', value: '' },
        { name: 'LIMITED_TERM', firstValue: true },
        { name: 'CLA_NTE', value: '' }
    ],

    //**Function to get Hiring Method: Potential Output's Title 5, Title 42, SES/SL */
    getHiringMethod: function(fieldState) {
        var self = this;
        var hiringMethod = '';
        if (!fieldState) {
            fieldState = FormState.getState('HM_ID');
        }
        if (fieldState && fieldState.value) {
            if (fieldState.value.indexOf('Title 5') === 0) {
                hiringMethod = 'Title 5';
            } else if (fieldState.value.indexOf('Title 42') === 0) {
                hiringMethod = 'Title 42';
            } else if (fieldState.value.indexOf('SES/SL/ST') === 0) {
                hiringMethod = 'SES/SL/ST';
            }
        }
        return hiringMethod;
    },

    //**Function for initial setup when the form is loaded */
    initSetup: function() {
        var self = this;

        var fsFieldState = FormState.getState('FINANCIAL_STATEMENTS');
        //CDCCommon.renderDisplay('FINANCIAL_STATEMENTS', '#fsList', self.financialStatementList);  //**Done in Renderer as there is a dependency for display 
        if (fsFieldState && fsFieldState.value) {
            CDCCommon.hideField('FINANCIAL_STATEMENT', true);
            CDCCommon.showField('FINANCIAL_STATEMENT');
        } else{
            //CDCCommon.noMultivalSelectedReminder('fsList');
        }
        FormState.doAction(StateAction.changeSelect('FINANCIAL_STATEMENT', self.financialStatementList[0].value), false);

        var clFieldState = FormState.getState('CLASSIFICATIONS');
        CDCCommon.renderDisplay('CLASSIFICATIONS', '#clList');
        if (clFieldState && clFieldState.value) {
            CDCCommon.hideField('CLASSIFICATION', true);
            CDCCommon.showField('CLASSIFICATION');
        } else{
            CDCCommon.noMultivalSelectedReminder('clList');
        }

        FormState.doAction(StateAction.changeSelect('CLASSIFICATION', ''), false);
        var hiringMethod = self.getHiringMethod();
        console.log('******************************************************', hiringMethod, '*******************************************');
        if (hiringMethod !== 'SES/SL/ST') {
            $('#LIMITED_ROW').addClass('hidden');
            CDCCommon.hideField('LIMITED_TERM', false, '');
            CDCCommon.hideField('CLA_NTE', true, '');
            if (hiringMethod === 'Title 42') {
                self.hideFieldsForTitle42();
            } else {
                self.showFieldsForNonTitle42();
            }
        } else {
            $('#LIMITED_ROW').removeClass('hidden');
            CDCCommon.showField('LIMITED_TERM', false);
        }
        
        var activityName = BFActivityOption.getActivityName();
        if (activityName === 'Submit PD/SOD for Classification') {
            self.turnOffRequiredFields();
        } else {
            self.turnBackOnRequiredFields();
        }
        
    },

    //**Mappers for Autocomplete */
    mappers: {
        CLASSIFICATION: function() {
            return {
                STANDARD_DISPLAY: $('STANDARD_DISPLAY', this).text()
            };
        }
    },

    //**OnBlur handler for Autocomplete */
    reduxBindFix: function() {
        var control = $(this);
        if (control.hasClass('js-autocomplete')) {
            FormState.doAction(StateAction.changeText(control.attr('id'), control.val()), false);
        }
    },

    //**  Init function/method called from On PageLoad; performs various activities to setup the page UI, hide/show fields */
    init: function() {
        var self = this;

        $('#FINANCIAL_STATEMENT > option').each(function() {
            self.financialStatementList.push({
                value: $(this).val(),
                text: $(this).text()
            });
        });
        $("#ADD_FS").on('click', function(e) {
            var fieldState = FormState.getState('FINANCIAL_STATEMENT');
            if (fieldState.value) {
                CDCCommon.addData('FINANCIAL_STATEMENTS', fieldState.text, '#fsList', self.financialStatementList);
                FormState.doAction(StateAction.changeSelect('FINANCIAL_STATEMENT', self.financialStatementList[0].value), true);
                CDCCommon.hideField('FINANCIAL_STATEMENT', true);
                CDCCommon.showField('FINANCIAL_STATEMENT');
                $('#FINANCIAL_STATEMENT').focus();
            }
        });
        $("#ADD_CL").on('click', function(e) {
            CDCCommon.addData('CLASSIFICATIONS', $('#CLASSIFICATION').val(), '#clList');
            FormState.doAction(StateAction.changeSelect('CLASSIFICATION', ''), true);
            CDCCommon.hideField('CLASSIFICATION', true);
            CDCCommon.showField('CLASSIFICATION');
            $('#CLASSIFICATION').focus();
        });
        $('#cla_main_lg').on('click', '.js-FINANCIAL_STATEMENTS-delete', function(e) {
            e.preventDefault();
            CDCCommon.removeData('FINANCIAL_STATEMENTS', $(this).data("item"), '#fsList', self.financialStatementList);
            var fieldState = FormState.getState('FINANCIAL_STATEMENTS');
            if (fieldState && (!fieldState.value || (fieldState.value).length === 0)) {
                CDCCommon.hideField('FINANCIAL_STATEMENT');
                CDCCommon.showField('FINANCIAL_STATEMENT', true);
                CDCCommon.noMultivalSelectedReminder('fsList');
            }
            CDCCommon.showHideMultiValLabelParent('#fsList','Yes');
        });
        $('#cla_main_lg').on('click', '.js-CLASSIFICATIONS-delete', function(e) {
            e.preventDefault();
            CDCCommon.removeData('CLASSIFICATIONS', $(this).data("item"), '#clList');
            var fieldState = FormState.getState('CLASSIFICATIONS');
            if (fieldState && (!fieldState.value || (fieldState.value).length === 0)) {
                CDCCommon.hideField('CLASSIFICATION');
                CDCCommon.showField('CLASSIFICATION', true);
                CDCCommon.noMultivalSelectedReminder('clList');
            }
            CDCCommon.showHideMultiValLabelParent('#clList','Yes');
        });

        $(document).on("click change keyup keypress keydown",".textbox.autoExpandTextarea",function() {
            CDCCommon.addCurrTextlengthStatus($(document.activeElement));
        });
                          
        $(document).on("focusout",".textbox.autoExpandTextarea",function() {
            CDCCommon.removeCurrTextlengthStatus();
        });
        
        CDCCommon.setAutoComplete('cla_main_lg', self.mappers, self.reduxBindFix);
    },

    turnOffRequiredFields: function() {
        CDCCommon.removeRequired('PHYSICIANS_COMPARABILITY_ALLOWANCE');
        CDCCommon.removeRequired('DRUG_TEST_REQUIRED');
        CDCCommon.removeRequired('PRE_EMPLOYMENT_PHYSICAL_REQUIRED');
        CDCCommon.removeRequired('SELECT_AGENT_ACCESS_REQUIRED');
        CDCCommon.removeRequired('FINANCIAL_DISCLOSURE_REQUIRED');
        CDCCommon.removeRequired('BARGAINING_UNIT_STATUS_CODE');
        
        CDCCommon.removeRequired("SUBJECT_TO_ADDITIONAL_IDENTICAL");
		CDCCommon.removeRequired("INCUMBENT_ONLY");
		CDCCommon.removeRequired("COMMISSIONED_CORPS_ELIGIBLE");
        CDCCommon.removeRequired("CYBER_SECURITY_CODE");
		CDCCommon.removeRequired("ACQUISITION_CODE");
        //CDCCommon.removeRequired("OPM_CERTIFICATION_NO"); //non-required field on original form to begin with
		CDCCommon.removeRequired("OFFICIAL_REASON_SUB");
		//CDCCommon.removeRequired("CLA_EXP"); ; //non-required field on original form to begin with
        CDCCommon.removeRequired('CLASSIFICATION');
    },

    turnBackOnRequiredFields: function() {
        CDCCommon.addRequired('PHYSICIANS_COMPARABILITY_ALLOWANCE');
        CDCCommon.addRequired('DRUG_TEST_REQUIRED');
        CDCCommon.addRequired('PRE_EMPLOYMENT_PHYSICAL_REQUIRED');
        CDCCommon.addRequired('SELECT_AGENT_ACCESS_REQUIRED');
        CDCCommon.addRequired('FINANCIAL_DISCLOSURE_REQUIRED');
        CDCCommon.addRequired('BARGAINING_UNIT_STATUS_CODE');
        
        CDCCommon.addRequired("SUBJECT_TO_ADDITIONAL_IDENTICAL");
		CDCCommon.addRequired("INCUMBENT_ONLY");
		CDCCommon.addRequired("COMMISSIONED_CORPS_ELIGIBLE");
        CDCCommon.addRequired("CYBER_SECURITY_CODE");
		CDCCommon.addRequired("ACQUISITION_CODE");
        //CDCCommon.addRequired("OPM_CERTIFICATION_NO"); //non-required field on original form to begin with
		CDCCommon.addRequired("OFFICIAL_REASON_SUB");
		//CDCCommon.addRequired("CLA_EXP"); ; //non-required field on original form to begin with
        CDCCommon.addRequired('CLASSIFICATION');
    },

    hideFieldsForTitle42: function() {
        CDCCommon.hideField("SUBJECT_TO_ADDITIONAL_IDENTICAL", true, '');
		CDCCommon.hideField("INCUMBENT_ONLY", true, '');
		CDCCommon.hideField("COMMISSIONED_CORPS_ELIGIBLE", true, '');
        CDCCommon.hideField("CYBER_SECURITY_CODE", true, '');
		CDCCommon.hideField("ACQUISITION_CODE", true, '');
        CDCCommon.hideField("OPM_CERTIFICATION_NO", true, '');
		CDCCommon.hideField("OFFICIAL_REASON_SUB", true, '');
		CDCCommon.hideField("CLA_EXP", true, '');
		CDCCommon.hideField("CLASSIFICATION", true, '');        
        CDCCommon.showHideMultiValLabelParent('#clList','No');
        $('#clList').children().remove();        
    },

    showFieldsForNonTitle42: function() {
        CDCCommon.showField("SUBJECT_TO_ADDITIONAL_IDENTICAL");
		CDCCommon.showField("INCUMBENT_ONLY");
		CDCCommon.showField("COMMISSIONED_CORPS_ELIGIBLE");
        CDCCommon.showField("CYBER_SECURITY_CODE");
		CDCCommon.showField("ACQUISITION_CODE");
        CDCCommon.showField("OPM_CERTIFICATION_NO");
		CDCCommon.showField("OFFICIAL_REASON_SUB");
		CDCCommon.showField("CLA_EXP");
		CDCCommon.showField("CLASSIFICATION");
        var fsFieldState = FormState.getState('CLASSIFICATIONS')
        if (fsFieldState && (!fsFieldState.value || (fsFieldState.value).length === 0)) {
            CDCCommon.noMultivalSelectedReminder('clList');
        }
        if(!$('#CLASSIFICATION').hasClass('hidden')){
            CDCCommon.showHideMultiValLabelParent('#clList','Yes');
        }
    },	
	
    //**Rendered method that is called everytime there is a field change by Redux Form */
    renderer: function() {
        var self = this;
        console.log("claClassification Renderer Start");
        CDCCommon.setupFirstLoad(self.checkField, self.fields);
        if (!self.initSetupDone) {
            self.initSetup();
        }
        self.actionOnChange('HM_ID');
        self.actionOnChange('FINANCIAL_DISCLOSURE_REQUIRED');
        self.actionOnChange('LIMITED_TERM');
        self.initSetupDone = true;
        console.log("claClassification Renderer Start");
    },

    //**Called from rendered when specific field(s) are changed */
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        var hiringMethod = self.getHiringMethod();
        if (fieldState && (fieldState.dirty || !self.initSetupDone)) {
            switch (field) {
                case 'HM_ID':
                    //**Show/Hide/Reset Classification Standard */
                    if (hiringMethod === 'Title 42') {
                        CDCCommon.hideField("CLASSIFICATION", true, '');
                        FormState.doAction(StateAction.changeText('CLASSIFICATIONS', ''), false);
                        $('#ADD_CL').addClass('hidden');
                        //CDCCommon.renderDisplay('CLASSIFICATIONS', '#clList', self.financialStatementList); //??
						                  self.hideFieldsForTitle42();
                    } else {
                        if (self.initSetupDone) {
                            var curActivity = $('#curActivity').val();
                            CDCCommon.showField("CLASSIFICATION", (curActivity !== 'Submit PD/SOD for Classification'), '');
                            FormState.doAction(StateAction.changeText('CLASSIFICATIONS', ''), false);
                            $('#ADD_CL').removeClass('hidden');
                            CDCCommon.renderDisplay('CLASSIFICATIONS', '#clList', self.financialStatementList);
                            if(!$('#CLASSFICATION').hasClass('hidden')){
                                CDCCommon.showHideMultiValLabelParent('#clList','Yes');
                            }
                        }
							                 self.showFieldsForNonTitle42();                        
                    }
                    break;
                case 'FINANCIAL_DISCLOSURE_REQUIRED':
                    CDCCommon.renderDisplay('FINANCIAL_STATEMENTS', '#fsList', self.financialStatementList);                
                    if (fieldState.value === 'Yes') {
                        var fsFieldState = FormState.getState('FINANCIAL_STATEMENTS');
                        CDCCommon.showField('FINANCIAL_STATEMENT', !(fsFieldState && fsFieldState.value));
                        if (fsFieldState && (!fsFieldState.value || (fsFieldState.value).length === 0)) {
                            CDCCommon.hideField('FINANCIAL_STATEMENT');
                            CDCCommon.showField('FINANCIAL_STATEMENT', true);
                            CDCCommon.noMultivalSelectedReminder('fsList');
                        }
                        if(fsFieldState == undefined){
                            CDCCommon.noMultivalSelectedReminder('fsList');
                        }
                        $('#ADD_FS').removeClass('hidden');
                        CDCCommon.showHideMultiValLabelParent('#fsList','Yes');
                    } else {
                        CDCCommon.hideField('FINANCIAL_STATEMENT', true);
                        $('#ADD_FS').addClass('hidden');
                        $('#FINANCIAL_STATEMENT_DISPLAY').addClass('hidden');
                        $('#fsList').children().remove();
                        CDCCommon.showHideMultiValLabelParent('#fsList','No');                       
                        if (self.initSetupDone) {
                            FormState.doAction(StateAction.changeText('FINANCIAL_STATEMENTS', ''), false);
                        }
                    }
                    break;
                case 'LIMITED_TERM':

                    if (fieldState.value !== '') {
                        var maxMonths = (fieldState.value === 'Limited Term') ? 36 : 18;
                        CDCCommon.showField('CLA_NTE', true);
                        $('#cla_main_lg').on('change', '#CLA_NTE', function(e) {
                            if ($(this).val().length < 10) {
                                return;
                            } else {
                                var maxDate = new Date();
                                var nteDate = new Date($('#CLA_NTE').val());
                                var alertDate;
                                maxDate.setMonth(maxDate.getMonth() + maxMonths);
                                alertDate = (maxDate.getMonth() + 1) + '/' + maxDate.getDate() + '/' + maxDate.getFullYear();
                                if (maxDate <= nteDate) {
                                    alert('The NTE Date cannot be gretaer than ' + alertDate + ' (' + maxMonths + ' months).');
                                    $('#CLA_NTE').val('');
                                }

                            }
                        });


                    } else {
                        CDCCommon.hideField('CLA_NTE', true, '');
                    }

                    break;
            }
        }
    }
}