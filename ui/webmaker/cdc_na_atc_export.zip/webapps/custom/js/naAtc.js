var naAtc = {

    //**For storing Grade List */
    gradeList: [],
    //**Flag indicating whether initialization is done or not; needed for renderer function, otherwise it calls init section all the time */
    initSetupDone: false,
    //**Check Field for First Load check */
    checkField: {
        name: 'atcInitComplete',
        value: 'true'
    },
    disableNOACFields: false,
    //**Default values for First Load Fields */
    fields: [{
            name: 'POS_GRADE_IDS',
            value: ''
        },
        {
            name: 'POS_TITLE_SERIESES',
            value: ''
        },
        {
            name: 'POS_PAY_PLAN_CODE',
            value: ''
        },
        {
            name: 'POS_DUTY_STATIONS',
            value: ''
        },
        {
            name: 'POS_CAN',
            value: ''
        },
        {
            name: 'ATC_TITLE',
            value: ''
        },
        {
            name: 'ATC_PAY_PLAN_CODE',
            value: ''
        },
        {
            name: 'ATC_SERIES',
            value: ''
        },
        {
            name: 'ATC_GRADE_ID',
            firstValue: true
        },
        {
            name: 'ATC_DUTY_STATION',
            value: ''
        },
        {
            name: 'ATC_CITIZEN_OF',
            value: ''
        },
        {
            name: 'ATC_VISA_ASSISTANCE_REQ',
            value: 'No'
        },
        {
            name: 'ATC_NOACS',
            value: ''
        },
        {
            name: 'ATC_EFFECTIVE_DATE',
            value: ''
        },
        {
            name: 'ATC_NTE',
            value: ''
        },
        {
            name: 'ATC_VETS_PREF_CODE',
            firstValue: true
        },
        {
            name: 'ATC_INTER_WORKED',
            value: ''
        },
        {
            name: 'ATC_INTER_WORKED_DAYSHOURS',
            firstValue: true
        },
        {
            name: 'ATC_INTER_PROJECTED',
            value: ''
        },
        {
            name: 'ATC_INTER_PROJECTED_DAYSHOURS',
            firstValue: true
        },
        {
            name: 'ATC_LAST_APPT_DT_FROM',
            value: ''
        },
        {
            name: 'ATC_LAST_APPT_DT_TO',
            value: ''
        },
        {
            name: 'ATC_FISCALYEAR',
            value: ''
        },
        {
            name: 'ATC_PRIOR_FEDERAL_SERVICE',
            firstValue: true
        },
        {
            name: 'ATC_HP_PAY_PLAN_CODE',
            value: ''
        },
        {
            name: 'ATC_HP_GRADE_ID',
            firstValue: true
        },
        {
            name: 'ATC_HP_STEP',
            firstValue: true
        },
        {
            name: 'ATC_HP_SALARY',
            value: ''
        },
        {
            name: 'ATC_PRIOR_LOCATION',
            value: ''
        },
        {
            name: 'ATC_PRIOR_YEAR',
            value: ''
        },
        {
            name: 'ATC_PRIOR_REMARKS',
            value: ''
        },
        {
            name: 'ATC_TERMINATE_RET_ALLOWANCE',
            firstValue: true
        },
        {
            name: 'ATC_PAY_SET_AS_PAY_PLAN_CODE',
            value: ''
        },
        {
            name: 'ATC_PAY_SET_AS_GRADE_ID',
            firstValue: true
        },
        {
            name: 'ATC_PAY_SET_AS_STEP',
            firstValue: true
        },
        {
            name: 'ATC_PAY_SET_AS',
            value: ''
        },
        {
            name: 'ATC_INCENTIVES',
            value: ''
        },
        {
            name: 'ATC_MARKET_PAY',
            value: ''
        },
        {
            name: 'ATC_POST_DIFF_PERCENT',
            value: ''
        },
        {
            name: 'ATC_POST_DIFF_STATUS',
            firstValue: true
        },
        {
            name: 'ATC_COLA_PERCENT',
            value: ''
        },
        {
            name: 'ATC_COLA_STATUS',
            firstValue: ''
        },
        {
            name: 'ATC_DANGER_PAY_STATUS',
            firstValue: true
        },
        {
            name: 'ATC_PAY_CORDINATED',
            firstValue: true
        },

        {
            name: 'ATC_VISA_TYPE',
            value: ''
        },
        {
            name: 'ATC_ENTITLED_TO_BENEFITS',
            firstValue: true
        },
        {
            name: 'ATC_BENEFITS',
            value: ''
        },
        {
            name: 'ATC_ENTITLED_BENEFITS',
            value: ''
        },
    ],
    setJobCode: function() {
        var self = this;
        var hiringMethod = self.getHiringMethod();
        var requestType = self.getRequestType();
        if (requestType !== 'Recruitment') {
            var fieldState = FormState.getState('POS_GRADE_RELATED');
            var gradeRelated = (fieldState && fieldState.value) ? (fieldState.value).split('::') : [];
            var grade = $('#ATC_GRADE_ID option:selected').text();
            var selectedGradeRelated = '';

            for (var i = 0; i < gradeRelated.length; i++) {
                selectedGradeRelated = (gradeRelated[i].indexOf(grade) === 0) ? gradeRelated[i].split('%%') : selectedGradeRelated;
            }

            if (selectedGradeRelated.length > 0 && hiringMethod === 'Title5') {
                FormState.doAction(StateAction.changeText('JOB_CODE_APPROVAL', selectedGradeRelated[2]), false);

            } else if (selectedGradeRelated.length > 0) {
                FormState.doAction(StateAction.changeText('JOB_CODE', selectedGradeRelated[2]), false);
            }
        }

    },
    //**Function to get Hiring Method: Potential Output's Title5, Title42, SES/SL */
    getHiringMethod: function(fieldState) {
        var self = this;
        var hiringMethod = '';
        if (!fieldState) {
            fieldState = FormState.getState('HM_ID');
        }
        if (fieldState && (fieldState.text || fieldState.value)) {
            if (fieldState.text && fieldState.text.indexOf('Title 5') === 0 || fieldState.value && fieldState.value.indexOf('Title 5') === 0) {
                hiringMethod = 'Title5';
            } else if (fieldState.text && fieldState.text.indexOf('Title 42') === 0 || fieldState.value && fieldState.value.indexOf('Title 42') === 0) {
                hiringMethod = 'Title42';
            } else if (fieldState.text && fieldState.text.indexOf('SES/SL') === 0 || fieldState.value && fieldState.value.indexOf('SES/SL') === 0) {
                hiringMethod = 'SES/SL';
            }
        }
        return hiringMethod;
    },

    //**Function to get Request Type */
    getRequestType: function(fieldState) {
        var self = this;
        var requestType = '';
        if (!fieldState) {
            fieldState = FormState.getState('REQUEST_TYPE');
        }
        if (fieldState && (fieldState.text || fieldState.value)) {
            if (fieldState.text && fieldState.text.indexOf('Appointment') >= 0 || fieldState.value && fieldState.value.indexOf('Appointment') >= 0) {
                requestType = 'Appointment';
            } else if (fieldState.text && fieldState.text.indexOf('Recruitment Only') >= 0 || fieldState.value && fieldState.value.indexOf('Recruitment Only') >= 0) {
                requestType = 'Recruitment';
            } else if (fieldState.text && fieldState.text.indexOf('Classification') >= 0 || fieldState.value && fieldState.value.indexOf('Classification') >= 0) {
                requestType = 'Classification';
            }
        }
        return requestType;
    },

    setGradesDropDown: function(hiringMethod) {
        var self = this;
        var gr1DropDown = $("#ATC_GRADE_ID");
        gr1DropDown.find('option').remove();
        var gr3DropDown = $("#ATC_PAY_SET_AS_GRADE_ID");
        gr3DropDown.find('option').remove();
        for (var i = 0; i < self.gradeList.length; i++) {
            var add1 = false;
            if (self.gradeList[i].value === '') {
                add1 = true;
            } else {
                switch (hiringMethod) {
                    case 'Title5':
                        if (self.gradeList[i].text !== '00') {
                            add1 = true;
                        }
                        break;
                    case 'Title42':
                    case 'SES/SL':
                        if (self.gradeList[i].text === '00') {
                            add1 = true;
                        }
                        break;
                }
            }
            if (add1) {
                gr1DropDown.append('<option value="' + self.gradeList[i].value + '">' + self.gradeList[i].text + '</option>');
            }
            if (self.gradeList[i].text !== '00') {
                gr3DropDown.append('<option value="' + self.gradeList[i].value + '">' + self.gradeList[i].text + '</option>');
            }
        }
        // FormState.doAction(StateAction.changeSelect('ATC_GRADE_ID', ''), false);
    },

    setFiscalYear: function() {
        var self = this;
        var today = new Date();
        var startYear = today.getFullYear();
        if (today.getMonth() >= 10) {
            startYear++;
        }
        var fyDropDown = $("#ATC_FISCALYEAR");
        fyDropDown.find('option').remove();
        for (var i = startYear; i < startYear + 3; i++) {
            fyDropDown.append('<option value="' + i + '">' + i + '</option>');
        }
		
        var thisYear = today.getFullYear();
        var locationYearDropDown = $("#ATC_PRIOR_YEAR");
        locationYearDropDown.find('option').remove();
        locationYearDropDown.append('<option value="">Select One</option>');
        for (var i = thisYear; i >= thisYear - 60; i--) {
            locationYearDropDown.append('<option value="' + i + '">' + i + '</option>');
        }
    },

    //**Function for initial setup when the form is loaded */
    initSetup: function() {
        var self = this;
        var hiringMethod = self.getHiringMethod();
        self.setGradesDropDown(hiringMethod);
        self.setFiscalYear();
        var tsFieldState = FormState.getState('ATC_NOACS');
        if (tsFieldState && tsFieldState.value) {
            self.noacRenderDisplay();
            CDCCommon.hideField('ATC_NOAC', true, '');
            CDCCommon.hideField('ATC_AUTHORITY', true, '');
            CDCCommon.hideField('ATC_SECOND_AUTHORITY', false, '');
            CDCCommon.hideField('ATC_ZLM_REMARKS', false, '');
        }
        self.showHideNOACFields();
        tsFieldState = FormState.getState('ATC_ENTITLED_BENEFITS');
        if (tsFieldState && tsFieldState.value) {
            CDCCommon.renderDisplay('ATC_ENTITLED_BENEFITS', '#benefitsList');
            CDCCommon.hideField('ATC_BENEFITS', true, '');
            CDCCommon.showField('ATC_BENEFITS');
        } else {
            CDCCommon.noMultivalSelectedReminder('benefitsList');
        }
        if (hiringMethod === 'SES/SL') {
            var checkCitizenship = FormState.getState('ATC_CITIZEN_OF');
            if (!checkCitizenship || checkCitizenship.value === '') {
                FormState.doAction(StateAction.changeSelect('ATC_CITIZEN_OF', 'United States of America (USA)'), false);
            }
        }
		if (hiringMethod !== 'Title5') {
			$('#ATC_TITLE').addClass('disabled').attr('readonly',true);
			$('#ATC_PAY_PLAN_CODE').addClass('disabled').attr('readonly',true);
			$('#ATC_SERIES').addClass('disabled').attr('readonly',true);
		}
		FormState.doAction(StateAction.changeSelect('ATC_FISCALYEAR', $("#ATC_FISCALYEAR :selected").val()), false);
        self.setInitGradeDropdown();
        self.setInitTitleSeries();
        self.setInitPayPlanCode();
        self.setInitDutyStation();
    },

    setInitGradeDropdown: function() {
        var self = this;
        var clsFS = FormState.getState('POS_GRADE_IDS');
        var clsFSArray = [];
		var hiringMenthod = self.getHiringMethod();
        if (clsFS && clsFS.value) {
            clsFSArray = clsFS.value.split('::');
        }
        var thisFS = FormState.getState('ATC_GRADE_ID');
        var selectedValue = thisFS && thisFS.value ? thisFS.value : '';
        var gr1DropDown = $("#ATC_GRADE_ID");
		
        gr1DropDown.find('option').remove();
		if(hiringMenthod === 'Title5'){
        for (var i = 0; i < self.gradeList.length; i++) {
			
            var add1 = true;
			if (self.gradeList[i].text === '00') {
                add1 = false;
			}
            if (add1) {
                gr1DropDown.append('<option value="' + self.gradeList[i].value + '"' + (selectedValue ? ' selected' : '') + '>' + self.gradeList[i].text + '</option>');
            }
        }
		}else{
			selectedValue = self.gradeList[1].value;
			gr1DropDown.append('<option value="' + self.gradeList[1].value + '" selected>' + self.gradeList[1].text + '</option>');
		}
        FormState.doAction(StateAction.changeSelect('ATC_GRADE_ID', selectedValue), false);
    },

    setInitTitleSeries: function() {
        var self = this;
        var clsFS = FormState.getState('POS_TITLES_SERIESES');
        var thisFS1 = FormState.getState('ATC_TITLE');
        var thisFS2 = FormState.getState('ATC_SERIES');
        if (!thisFS1 || !thisFS1.value || !thisFS2 || !thisFS2.value) {
            var valueToSet1 = '';
            var valueToSet2 = '';
            if (clsFS && clsFS.value) {
                var titleSeries = clsFS.value.split('::');
                var title = [];
                var series = [];
                for (var i = 0; i < titleSeries.length; i++) {
                    title.push(titleSeries[i].split('%%')[0]);
                    series.push(titleSeries[i].split('%%')[1]);
                }
                valueToSet1 = title.join(' / ');
                valueToSet2 = series.join(' / ');
            }
            FormState.doAction(StateAction.changeText('ATC_TITLE', valueToSet1), false);
            $('#ATC_TITLE').val(valueToSet1);
            FormState.doAction(StateAction.changeText('ATC_SERIES', valueToSet2), false);
            $('#ATC_SERIES').val(valueToSet2);
        }
    },

    setInitPayPlanCode: function() {
        var self = this;
        var clsFS = FormState.getState('POS_PAY_PLAN_CODE');
        var thisFS = FormState.getState('ATC_PAY_PLAN_CODE');
        if (!thisFS || !thisFS.value) {
            var valueToSet = clsFS && clsFS.value ? clsFS.value : '';
            FormState.doAction(StateAction.changeText('ATC_PAY_PLAN_CODE', valueToSet), false);
            $('#ATC_PAY_PLAN_CODE').val(valueToSet);
        }
    },

    setInitDutyStation: function() {
        var self = this;
        var clsFS = FormState.getState('POS_DUTY_STATIONS');
        var thisFS = FormState.getState('ATC_DUTY_STATION');
        if (!thisFS || !thisFS.value) {
            var valueToSet = clsFS && clsFS.value ? clsFS.value.split('::')[0] : '';
            FormState.doAction(StateAction.changeText('ATC_DUTY_STATION', valueToSet), false);
            $('#ATC_DUTY_STATION').val(valueToSet);
        }
    },

    //**Function that performs action when a particular field is changed (called from renderer function) */
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        if (fieldState && (fieldState.dirty || !this.initSetupDone)) {
            switch (field) {
                case 'HM_ID':
                    var hiringMethod = self.getHiringMethod(fieldState);
                    $('#benefits_lg_label_container').addClass('hidden');
                    $('#ADD_BENEFIT').addClass('hidden');
                    $('#benefitsCustomControl').addClass('hidden');
                    if (hiringMethod === 'Title5') {
                        CDCCommon.hideField('ATC_PAY_SET_AS_PAY_PLAN_CODE', true);
                        CDCCommon.showField('ATC_PAY_SET_AS_PAY_PLAN_CODE');
                        CDCCommon.hideField('ATC_PAY_SET_AS_GRADE_ID', true);
                        CDCCommon.showField('ATC_PAY_SET_AS_GRADE_ID');
                        CDCCommon.hideField('ATC_PAY_SET_AS_STEP', true);
                        CDCCommon.showField('ATC_PAY_SET_AS_STEP');
                        CDCCommon.hideField('ATC_PAY_SET_AS', true);
                        CDCCommon.showField('ATC_PAY_SET_AS');
                        CDCCommon.hideField('ATC_NTE', true);
                        CDCCommon.showField('ATC_NTE');
                        CDCCommon.hideField('ATC_VISA_TYPE', true, '');
                        CDCCommon.hideField('ATC_ENTITLED_TO_BENEFITS', true, '');
                        CDCCommon.hideField('ATC_BENEFITS', true, '');
                        CDCCommon.hideField('ATC_VETS_PREF_CODE', true);
                        CDCCommon.showField('ATC_VETS_PREF_CODE');
                        FormState.doAction(StateAction.changeText('ATC_ENTITLED_BENEFITS', ''), false);
                    } else if (hiringMethod === 'SES/SL') {
                        CDCCommon.hideField('ATC_PAY_SET_AS_PAY_PLAN_CODE', true);
                        CDCCommon.showField('ATC_PAY_SET_AS_PAY_PLAN_CODE');
                        CDCCommon.hideField('ATC_PAY_SET_AS_GRADE_ID', true);
                        CDCCommon.showField('ATC_PAY_SET_AS_GRADE_ID');
                        CDCCommon.hideField('ATC_PAY_SET_AS_STEP', true);
                        CDCCommon.showField('ATC_PAY_SET_AS_STEP');
                        CDCCommon.hideField('ATC_PAY_SET_AS', true);
                        CDCCommon.showField('ATC_PAY_SET_AS');
                        CDCCommon.hideField('ATC_VISA_TYPE', true, '');
                        CDCCommon.hideField('ATC_ENTITLED_TO_BENEFITS', true, '');
                        CDCCommon.hideField('ATC_BENEFITS', true, '');
                        FormState.doAction(StateAction.changeText('ATC_ENTITLED_BENEFITS', ''), false);
                    } else if (hiringMethod === 'Title42') {
                        CDCCommon.hideField('ATC_PAY_SET_AS_PAY_PLAN_CODE', true);
                        CDCCommon.showField('ATC_PAY_SET_AS_PAY_PLAN_CODE', true);
                        CDCCommon.hideField('ATC_PAY_SET_AS_GRADE_ID', true);
                        CDCCommon.showField('ATC_PAY_SET_AS_GRADE_ID', true);
                        CDCCommon.hideField('ATC_PAY_SET_AS_STEP', true);
                        CDCCommon.showField('ATC_PAY_SET_AS_STEP', true);
                        CDCCommon.hideField('ATC_PAY_SET_AS', true);
                        CDCCommon.showField('ATC_PAY_SET_AS', true);
                        CDCCommon.showField('ATC_VISA_TYPE', true);
                        CDCCommon.showField('ATC_ENTITLED_TO_BENEFITS', true);
                        CDCCommon.showField('ATC_BENEFITS');
                        $('#ADD_BENEFIT').removeClass('hidden');
                        $('#benefitsCustomControl').removeClass('hidden');
                        $('#benefits_lg_label_container').removeClass('hidden');
                    }
                    break;
                case 'ATC_PRIOR_FEDERAL_SERVICE':
                    if (fieldState.value === 'Yes') {
                        CDCCommon.showField('ATC_HP_PAY_PLAN_CODE', true);
                        CDCCommon.showField('ATC_HP_GRADE_ID', true);
                        CDCCommon.showField('ATC_HP_STEP', true);
                        CDCCommon.showField('ATC_HP_SALARY', true);
                        CDCCommon.showField('ATC_PRIOR_LOCATION', true);
                        CDCCommon.showField('ATC_PRIOR_YEAR', true);
                        CDCCommon.showField('ATC_PRIOR_REMARKS', false);
                    } else {
                        CDCCommon.hideField('ATC_HP_PAY_PLAN_CODE', true, '');
                        CDCCommon.hideField('ATC_HP_GRADE_ID', true, '');
                        CDCCommon.hideField('ATC_HP_STEP', true, '');
                        CDCCommon.hideField('ATC_HP_SALARY', true, '');
                        CDCCommon.hideField('ATC_PRIOR_LOCATION', true, '');
                        CDCCommon.hideField('ATC_PRIOR_YEAR', true, '');
                        CDCCommon.hideField('ATC_PRIOR_REMARKS', false, '');
                    }
                    break;
                case 'ATC_CITIZEN_OF':
                    if (fieldState.value === 'Other') {
                        CDCCommon.hideField('ATC_VISA_ASSISTANCE_REQ');
                        CDCCommon.showField('ATC_VISA_ASSISTANCE_REQ', true);
                        $('#pv_clearanceReqImmig').val($('#ATC_VISA_ASSISTANCE_REQ').val());
                    } else {
                        CDCCommon.hideField('ATC_VISA_ASSISTANCE_REQ', true, 'No');
                        $('#pv_clearanceReqImmig').val('No');
                    }
                    break;
                case 'ATC_VISA_ASSISTANCE_REQ':
                    if (fieldState.value) {
                        $('#pv_clearanceReqImmig').val(fieldState.value);
                    }

                    break;
                case 'ATC_EFFECTIVE_DATE':
                    if (fieldState.value) {
                        var dateParts = fieldState.value.split('/');
                        var dateString = dateParts[2] + '/' + dateParts[0] + '/' + dateParts[1] + ' 12:00:00';
                        $('#pv_effectiveDate').val(dateString);
                    }
                    break;
                case 'ATC_INTER_WORKED':
                    if (!fieldState.value || fieldState.value === '') {
                        CDCCommon.hideField('ATC_INTER_WORKED_DAYSHOURS', true, '');
                    } else {
                        CDCCommon.showField('ATC_INTER_WORKED_DAYSHOURS', true);
                    }
                    break;
                case 'ATC_INTER_PROJECTED':
                    if (!fieldState.value || fieldState.value === '') {
                        CDCCommon.hideField('ATC_INTER_PROJECTED_DAYSHOURS', true, '');
                    } else {
                        CDCCommon.showField('ATC_INTER_PROJECTED_DAYSHOURS', true);
                    }
                    break;
                case 'ATC_GRADE_ID':
                    self.setJobCode();
                    break;
                case 'ATC_ENTITLED_TO_BENEFITS':
                    if (self.getHiringMethod() !== 'Title5') {
                        $('#ADD_BENEFIT').addClass('hidden');
                        $('#benefitsCustomControl').addClass('hidden');
                        if (fieldState.value === 'Yes') {
                            CDCCommon.showField('ATC_BENEFITS', true);
                            $('#ADD_BENEFIT').removeClass('hidden');
                            $('#benefitsCustomControl').removeClass('hidden');
                        } else {
                            CDCCommon.hideField('ATC_BENEFITS', true, '');
                            FormState.doAction(StateAction.changeText('ATC_ENTITLED_BENEFITS', ''), false);
                            CDCCommon.renderDisplay('ATC_ENTITLED_BENEFITS', '#benefitsList');
                        }
                    }
                    break;
            }
        }
    },

    //**Renderer function that is called from REDUX setup */
    renderer: function() {
        var self = this;

        CDCCommon.setupFirstLoad(self.checkField, self.fields);
        if (!self.initSetupDone) {
            self.initSetup();
        }
        self.actionOnChange('HM_ID');
        self.actionOnChange('ATC_PRIOR_FEDERAL_SERVICE');
        self.actionOnChange('ATC_CITIZEN_OF');
        self.actionOnChange('ATC_VISA_ASSISTANCE_REQ');
        self.actionOnChange('ATC_EFFECTIVE_DATE');
        self.actionOnChange('ATC_INTER_WORKED');
        self.actionOnChange('ATC_INTER_PROJECTED');
        self.actionOnChange('ATC_GRADE_ID');
        self.actionOnChange('ATC_ENTITLED_TO_BENEFITS');


        self.initSetupDone = true;
    },

    //**Mappers for Autocomplete */
    mappers: {
        ATC_PAY_SET_AS_PAY_PLAN_CODE: function() {
            return {
                PAYPLAN_CODE: $('PAYPLAN_CODE', this).text(),
                PAYPLAN_DISPLAY: $('PAYPLAN_DISPLAY', this).text()
            };
        },
        ATC_SERIES: function() {
            return {
                SERIES_CODE: $('SERIES_CODE', this).text(),
                SERIES_DISPLAY: $('SERIES_DISPLAY', this).text()
            };
        },
        ATC_DUTY_STATION: function() {
            return {
                DS_VALUE: $('DS_VALUE', this).text()
            };
        },
        ATC_PAY_PLAN_CODE: function() {
            return {
                PAYPLAN_CODE: $('PAYPLAN_CODE', this).text(),
                PAYPLAN_DISPLAY: $('PAYPLAN_DISPLAY', this).text()
            };
        },
		ATC_PAY_SET_AS_PAY_PLAN_CODE: function() {
            return {
                PAYPLAN_CODE: $('PAYPLAN_CODE', this).text(),
                PAYPLAN_DISPLAY: $('PAYPLAN_DISPLAY', this).text()
            };
        },
        ATC_NOAC: function() {
            return {
                NOA_CODE: $('NOA_CODE', this).text() + '-' + $('NOA_SUFFIX_CD', this).text(),
                NOA_DESC: $('NOA_DESC', this).text()
            };
        },
        ATC_AUTHORITY: function() {
            return {
                AUTH_CODE: $('AUTH_CODE', this).text(),
                AUTH_DESC: $('AUTH_DESC', this).text()
            };
        }
    },

    //**OnBlur handler for Autocomplete */
    reduxBindFix: function() {
        var control = $(this);
        if (control.hasClass('js-autocomplete')) {
            FormState.doAction(StateAction.changeText(control.attr('id'), control.val()), false);
        }
    },

    showHideNOACFields: function(resetField, noacData) {
        var self = this;
        if (resetField) {
            if (!noacData) {
                noacData = '%%%%%%';
            }
            var noacDataArray = noacData.split('%%');
            FormState.doAction(StateAction.changeText('ATC_NOAC', noacDataArray[0]), false);
            $('#ATC_NOAC').val(noacDataArray[0]);
            FormState.doAction(StateAction.changeText('ATC_AUTHORITY', noacDataArray[1]), false);
            $('#ATC_AUTHORITY').val(noacDataArray[1]);
            FormState.doAction(StateAction.changeText('ATC_SECOND_AUTHORITY', noacDataArray[2]), false);
            $('#ATC_SECOND_AUTHORITY').val(noacDataArray[2]);
            FormState.doAction(StateAction.changeText('ATC_ZLM_REMARKS', noacDataArray[3]), false);
            $('#ATC_ZLM_REMARKS').val(noacDataArray[3]);
        }
        CDCCommon.hideField('ATC_NOAC', true);
        CDCCommon.hideField('ATC_AUTHORITY', true);
        CDCCommon.hideField('ATC_SECOND_AUTHORITY');
        CDCCommon.hideField('ATC_ZLM_REMARKS');
        $('#ADD_NOAC').addClass('hidden');
        var fieldState = FormState.getState('ATC_NOACS');
        var noItems = true;
        var showFields = true;
        if (fieldState && fieldState.value) {
            noItems = false;
            if (fieldState.value.split('::').length === 3 || self.disableNOACFields) {
                showFields = false;
            }
        }
        if (showFields) {
            CDCCommon.showField('ATC_NOAC', noItems);
            CDCCommon.showField('ATC_AUTHORITY', noItems);
            CDCCommon.showField('ATC_SECOND_AUTHORITY');
            CDCCommon.showField('ATC_ZLM_REMARKS');
            $('#ADD_NOAC').removeClass('hidden');
            $('#ATC_NOAC').focus();
        }
        if (noItems) {
            CDCCommon.noMultivalSelectedReminder('noacList');
        }
    },

    noacAddData: function(item) {
        var self = this;
        var formState = FormState.getState('ATC_NOACS');
        var workingData = (formState && formState.value) ? formState.value.split("::") : [];
        var dupCheck = workingData.filter(function(data) {
            return data === item;
        });
        if (dupCheck.length === 0 && item.length > 2) {
            workingData.push(item);
        }
        FormState.doAction(StateAction.changeText('ATC_NOACS', workingData.join('::')), false);
        self.noacRenderDisplay();

    },
    noacRemoveData: function(item) {
        var self = this;
        var formState = FormState.getState('ATC_NOACS');
        var workingData = (formState && formState.value) ? formState.value.split("::") : [];
        workingData = workingData.filter(function(data) { return data !== item.toString(); });
        FormState.doAction(StateAction.changeText('ATC_NOACS', workingData.join('::')), false);
        self.noacRenderDisplay();
    },
    noacRenderDisplay: function() {
        var self = this;
        var target = '#noacList';
        var formState = FormState.getState('ATC_NOACS');
        var workingData = (formState && formState.value) ? formState.value.replace(/"/g, "&quot;").split("::") : [];
        var newList = "";
        var labelId = target.split("#")[1];
        var $label = $('label[for="' + labelId + '"]');

        $label.parent().removeClass('hidden'); // defect 180967

        if (workingData.length > 0 && workingData[0].length > 0) {
            $label.parent().removeClass('hidden');
            newList = workingData.map(function(data) {
                var returnItem = "<li>";
                if (!self.disableNOACFields) {
                    returnItem += '<a class="js-ATC_NOACS-delete" href="#" title="Delete - ' + data + '" data-item="' + data + '"><img alt="Delete" src="images/controls/exit.png" /></a>&nbsp;' +
                        '<a class="js-ATC_NOACS-edit" href="#" title="Edit - ' + data + '" data-item="' + data + '"><img alt="Edit" src="images/controls/edit.png" /></a>&nbsp;';
                }
                var noacData = data.split('%%');
                if (noacData.length >= 1) {
                    returnItem += noacData[0];
                }
                if (noacData.length >= 2) {
                    returnItem += "<br /> &nbsp;&nbsp;&nbsp;&nbsp;<strong>First Authority:</strong> " + noacData[1];
                }
                if (noacData.length >= 3) {
                    returnItem += "<br /> &nbsp;&nbsp;&nbsp;&nbsp;<strong>Second Authority:</strong> " + noacData[2];
                }
                if (noacData.length >= 4) {
                    returnItem += "<br /> &nbsp;&nbsp;&nbsp;&nbsp;<strong>Remarks:</strong>";
                    returnItem += "<br /> &nbsp;&nbsp;&nbsp;&nbsp;<textarea  rows='4' cols='100' disabled>" + noacData[3] + "</textarea>";
                }
                returnItem += '</li>';
                return returnItem;
            });
        }

        $(target).empty().append(newList);

    },

    //**Init function (called from onLoad page event) */
    init: function() {
        
        var self = this;
        var currActivity = BFActivityOption.getActivityName();
        if (currActivity !== 'Prepare Draft ATC' && currActivity !== 'Track Clearances and Finalize Package/ATC') {
            self.disableNOACFields = true;
        }

        //**Set numeric only entry */
        $('.js-numericOnlyWithDecimal').on("keypress keyup blur", function(event) {
            $(this).val($(this).val().replace(/[^0-9\.]/g, ''));
            if ((event.which !== 46 || $(this).val().indexOf('.') !== -1) && (event.which < 48 || event.which > 57)) {
                event.preventDefault();
            }
        });
        $('.js-numericOnly').bind('keypress', function(e) {
            if (e.keyCode === '9' || e.keyCode === '16') {
                return;
            }
            var code;
            if (e.keyCode) code = e.keyCode;
            else if (e.which) code = e.which;
            if (e.which === 46)
                return false;
            if (code === 8 || code === 46 || code === 45)
                return true;
            if (code < 48 || code > 57)
                return false;
        });

        //**Load Grade list from Drop-down */
        $("#ATC_GRADE_ID > option").each(function() {
            self.gradeList.push({
                value: $(this).val(),
                text: $(this).text()
            });
        });

        //** Set Click Event Handler for Add and Delete (X) Stop NOAC Buttons*/
        $("#ADD_NOAC").on('click', function() {
            var noac = $('#ATC_NOAC').val();
            var authority = $('#ATC_AUTHORITY').val();
            var secondAuthority = $('#ATC_SECOND_AUTHORITY').val();
            var zlmRemarks = $('#ATC_ZLM_REMARKS').val();
            if (noac && noac !== '' && authority && authority !== '') {
                var noacData = noac + '%%' + authority + '%%' + secondAuthority + '%%' + zlmRemarks;
                self.noacAddData(noacData);
                self.showHideNOACFields(true);
            }
        });
        $('#atc_main_lg').on('click', '.js-ATC_NOACS-delete, .js-ATC_NOACS-edit', function(e) {
            e.preventDefault();
            var noacData = $(this).data("item");
            //var targetID = this.parentElement.parentElement.parentElement.childNodes[1].id;
            self.noacRemoveData(noacData);
            if ($(this).hasClass('js-ATC_NOACS-delete')) {
                self.showHideNOACFields();
            } else {
                self.showHideNOACFields(true, noacData);
            }
        });

        //** Set Click Event Handler for Add and Delete (X) Stop NOAC Buttons*/
        $("#ADD_BENEFIT").on('click', function() {
            var benefits = $('#ATC_BENEFITS').val();
            if (benefits && benefits !== '') {
                CDCCommon.addData('ATC_ENTITLED_BENEFITS', benefits, '#benefitsList');
                FormState.doAction(StateAction.changeSelect('ATC_BENEFITS', ''), true);
                CDCCommon.hideField('ATC_BENEFITS', true);
                CDCCommon.showField('ATC_BENEFITS');
                $('#ATC_BENEFITS').focus();
            }
        });

        $('#atc_main_lg').on('click', '.js-ATC_ENTITLED_BENEFITS-delete', function(e) {
            e.preventDefault();
            //var targetID = this.parentElement.parentElement.parentElement.childNodes[1].id;
            CDCCommon.removeData('ATC_ENTITLED_BENEFITS', $(this).data("item"), '#benefitsList');
            var fieldState = FormState.getState('ATC_ENTITLED_BENEFITS');
            if (fieldState && (!fieldState.value || (fieldState.value).length === 0)) {
                CDCCommon.hideField('ATC_BENEFITS');
                CDCCommon.showField('ATC_BENEFITS', true);
                CDCCommon.noMultivalSelectedReminder('benefitsList');
            }
        });

        CDCCommon.setAutoComplete('atc_main_lg', self.mappers, self.reduxBindFix);

        
    }
};