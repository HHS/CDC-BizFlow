
(function() {
    'use strict';

    angular.module('bizflow.angular.component')
        .filter('printCreatorName', function() {
            return function(input) {
                if (input && input.creatorName) {
                    if (input.type == 'C' ||
                        angular.lowercase(input.creatorName).indexOf('agent') > -1 ||
                        input.creatorName == 'ERA User') {
                        return 'System';
                    } else {
                        return input.creatorName;
                    }
                } else {
                    return '';
                }
            };
        });

    angular.module('bizflow.angular.component')
        .component('comments', {
            templateUrl: function($element, $attrs, bizflowContext) {
                return '../p2w_common/js/angularjs/common/components/comment/comments.html';
            },
            bindings: {
            },
            controller: CtrlComments
        });

    function CtrlComments(bizflowWih, bizflowContext, inform, $window, $uibModal, blockUI, $scope, $log, $timeout) {
        var vm = this;
        vm.comments = [];
        vm.currentActivityName = bizflowContext.custom.ACTIVITYNAME;
        vm.mainFormReadOnly = false;

        if (vm.readOnly == true){
            vm.mainFormReadOnly = true;
        }

        vm.$onInit = function() {
            if (bizflowWih.basicWih) {
                vm.comments = bizflowWih.basicWih.getComments();
            }

            try {
                $timeout(function() {
                    $scope.$apply(function() {
                        vm.currentActivityName = bizflowContext.custom.ACTIVITYNAME;
                        vm.mainFormReadOnly = false;
                        if (vm.readOnly == true){
                            vm.mainFormReadOnly = true;
                        }
                    });
                });
            } catch(e) {
            }
        };

        vm.$onDestroy = function() {
        };

        //TAEHO
        vm.refreshComments = function() {
            setTimeout(()=>{
                this.reloadComments();
            }, 500);

        }

        //TAEHO
        vm.reloadComments = function() {
            vm.comments = bizflowWih.basicWih.getComments();
            $scope.$apply();
            console.log(vm.comments);
        }

        //--------------------------------
        // CDC Extension
        //--------------------------------
    }

    angular.module('bizflow.angular.component')
        .component('commentList', {
            templateUrl: function($element, $attrs, bizflowContext) {
                return '../p2w_common/js/angularjs/common/components/comment/comment-list.html';
            },
            bindings: {
                readOnly: '<?',
                comments: '=',
            },
            require: {
                main: '^comments'
            },
            controller: CtrlCommentList
        });

    //function CtrlAddAttachment($scope, $timeout, bizflowContext, FileUploader, bizflowWih, blockUI) {
    function CtrlCommentList($log, bizflowContext, bizflowWih, blockUI) {
        var vm = this;

		vm.getAssociatedWorkflow = function(actName) {
			return WorkflowInfoObject.getWorkflowName(actName) + " - " + actName;
		}

        vm.$onInit = function() {
        };

        vm.$onDestroy = function() {
        };
    }


})();
