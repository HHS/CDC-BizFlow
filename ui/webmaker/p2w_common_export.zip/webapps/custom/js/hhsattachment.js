/* global BFLog BFUtility angular $ bizflowWih_attachmentCallback angularExt */
/* eslint camelcase: 0, no-global-assign: 0, no-unused-expressions:0, no-unused-vars:0 */

// -----------------------------------------------------------
// BizFlow AngularJS Wrapper
// -----------------------------------------------------------
function initAttachmentTab () {
    // -----------------------------------------------------------
    // BizFlow.app Controller
    // -----------------------------------------------------------
    (function (angular) {
        'use strict';

    angular.module('bizflow.app', [
        'ngSanitize',
        'blockUI',
        'ngAnimate',
        'ngCookies',
        'inform',
        'inform-exception',
        'ui.bootstrap',
        'ui.select',
        'ui.grid',
        'ui.grid.selection',
        'ui.grid.pagination',
        'ui.grid.autoResize',
        'ui.grid.resizeColumns',
        'ngMessages',
        'bizflow.angular.context',
        'bizflow.angular.wih',
        'bizflow.angular.component',
        'bizflow.app.common'])
        .factory('timeoutHttpIntercept', function (inform) {
            return {
                'request': function (config) {
                    config.timeout = 600000; // increase timeout for Excel download operation
                    return config;
                },
                'responseError': function (responseError) {
                    if (responseError.status === -1 || responseError.status === 499 || responseError.status === 598 || responseError.status === 599) {
                        inform.add('Error: Time out', {type: 'danger'})
                    }
                    return responseError;
                }
            };
        })
        .config(['$httpProvider', 'blockUIConfig', 'bizflowContextProvider', 'informProvider', '$compileProvider', '$logProvider',
            function ($httpProvider, blockUIConfig, bizflowContextProvider, informProvider, $compileProvider, $logProvider) {
                // Turn on or off debugging message
                $logProvider.debugEnabled(true);
                bizflowContextProvider.custom.debugEnabled = $logProvider.debugEnabled();
                bizflowContextProvider.custom.formStyle = 'tab';

                $httpProvider.interceptors.push('timeoutHttpIntercept');

                blockUIConfig.autoBlock = true;
                blockUIConfig.delay = 0;
                blockUIConfig.message = 'Please Wait...';
                // Disable auto body block(This is important! if it's value is true then browser will be flickering on ie 9 and ie 10)
                blockUIConfig.autoInjectBodyBlock = false;
                // ... don't block it.
                blockUIConfig.requestFilter = function (config) {
                };

                // Need to change bizflowsrs context patch if it is not default value bizflowsrs
                bizflowContextProvider.setServiceContextPath('/bizflowsrs/services');
                bizflowContextProvider.setDataServiceContextPath('/bizflowsrs/services');
                bizflowContextProvider.setAppContextPath('/bizflowwebmaker/p2w_common');

                informProvider.defaults({ttl: 0, type: 'danger'});

                // need to set as false for PRODUCTION SERVER to speed up
                // https://docs.angularjs.org/guide/production
                $compileProvider.debugInfoEnabled(false);
            }
        ])
        .controller('CtrlAppMain', function ($scope, $location, bizflowContext, $document, $window, $rootScope, $log, bizflowWih, $timeout) {
            BFLog.log('DEBUG', 'p2wcommon - bizflow.app - controller START');

            var vm = this;
            vm.bizflowContext = bizflowContext;
            $scope.$ctrl = vm;
            $scope.isContextLoaded = true;

            // trigger destroy events for all children when window is switched or closed
            $window.onbeforeunload = function () {
                $rootScope.$destroy();
            };
            $scope.$on('$destroy', function () {
            });

            // Prevent backspace from navigating back in AngularJS in IE
            $document.on('keydown', function (event) {
                if (event.keyCode === 8) {
                    var doPrevent = true;
                    var types = ['text', 'password', 'file', 'search', 'email', 'number', 'date', 'color', 'datetime', 'datetime-local', 'month', 'range', 'search', 'tel', 'time', 'url', 'week'];
                    var d = $(event.srcElement || event.target);
                    var disabled = d.prop('readonly') || d.prop('disabled');
                    if (!disabled) {
                        if (d[0].isContentEditable) {
                            doPrevent = false;
                        } else if (d.is('input')) {
                            var type = d.attr('type');
                            if (type) {
                                type = type.toLowerCase();
                            }
                            if (types.indexOf(type) > -1) {
                                doPrevent = false;
                            } else if (d[0].outerHTML.indexOf('textbox') > -1) {
                                doPrevent = false;
                            } else if (d[0].outerHTML.indexOf('text-box') > -1) {
                                doPrevent = false;
                            }
                        } else if (d.is('textarea')) {
                            doPrevent = false;
                        }
                    }
                    if (doPrevent) {
                        event.preventDefault();
                    }
                }
            });

            vm.getDocumentTypeList = function () {
                // var documentTypes = LookupManager.findByLTYPE('DocumentType');
                //var documentTypes = [];
                console.log("[BIZFLOWRULE] getDocumentList starts");
                var documentTypes = [{
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '99',
                                        LABEL: 'Others',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Others',
                                        PARENTID: '0'
                                    }];
                try{
                    if (FormState){
                        //TAEHO #165145 04/02/2018 Document rules from BizFlow Rule service
                        //var hiringMethod = FormState.getState('HM_ID');
                        //var submissionReason = FormState.getState('REASON_SUB');
                        var hiringMethodValue = vm.getFormFieldValue("HM_ID");
                        var submissionReasonValue = vm.getFormFieldValue("PROPOSED_ACTION"); //TAEHO #179253 05/17/2018 field name change from REASON_SUB to PROPOSED_ACTION                        
                        var requestTypeValue = vm.getFormFieldValue("REQUEST_TYPE");
                        var employeeTypeValue = vm.getFormFieldValue("EMPL_TYPE");
                        
                        var pARActionType = vm.getFormFieldValue("PAR_ACTION_TYPE");
                        var pARAction = vm.getFormFieldValue("PAR_ACTION");
                        
                        if (bizflowWih.basicWih) {
                            var workitemContext = bizflowWih.getWorkitemContext();
                            var procName = workitemContext.Process.Name;
                            var formName;
                            // These lines are optional, but help us not to change RULEs for process name change
                            // as long as the processes have the keyword.
                            if (procName.indexOf('Recruitment') >= 0) {
                                procName = formName = 'Recruitment';
                            } else if (procName.indexOf('Classification') >= 0) {
                                procName = formName = 'Classification';
                            } else {
                                formName = procName;
                            }

                            var actName = workitemContext.Activity.Name;
                            var userName = workitemContext.User.Name;
                            vm.markers = {
                                          "ruleName": "cdc-document-rules",
                                          "tenantID": "CDC",
                                          "procName": procName,
                                          "actName": actName,
                                          "userName": userName,
                                          "formName": formName,
                                          "fields": [
                                            {
                                              "fieldId": "HiringMethod",
                                              "fieldValue": hiringMethodValue
                                            },
                                            {
                                              "fieldId": "SubmissionReason",
                                              "fieldValue": submissionReasonValue
                                            },
                                            {
                                              "fieldId": "RequestType",
                                              "fieldValue": requestTypeValue
                                            },
                                            {
                                              "fieldId": "EmployeeType",
                                              "fieldValue": employeeTypeValue
                                            },
                                            {
                                              "fieldId": "PARActionType",
                                              "fieldValue": pARActionType
                                            },
                                            {
                                              "fieldId": "PARAction",
                                              "fieldValue": pARAction
                                            }
                                          ]
                            
                                        }

                            console.log("[BIZFLOWRULE] getDocumentList search conditions=" + JSON.stringify(vm.markers));

                            // check if the same search marker ever used in the current page
                            var markerStr = JSON.stringify(vm.markers);
                            var chacedDocumentType = null;
                            if (typeof vm.markersMap !== 'undefined') {
                                if (typeof vm.markersMap[markerStr] !== 'undefined') {
                                    var cachedDocumentTypesStr = vm.markersMap[markerStr];
                                    if (typeof cachedDocumentTypesStr !== 'undefined') {
                                        chacedDocumentType = JSON.parse(cachedDocumentTypesStr);
                                        console.log("[BIZFLOWRULE] document list found in cache. = " + cachedDocumentTypesStr);  
                                        documentTypes = chacedDocumentType;
                                        vm.documentTypes = chacedDocumentType;                                
                                    }
                                }
                            }

                            if (chacedDocumentType == null) {
                                console.log("[BIZFLOWRULE] prepating getDocumentList.json call to BizFlow Rule service");
                                $.ajax({
                                    type: "POST",
                                    url: "/bizflowrule/rest/rule/document/getDocumentList.json",
                                    // The key needs to match your method's input parameter (case-sensitive).
                                    data: markerStr,
                                    contentType: "application/json; charset=utf-8",
                                    dataType: "json",
                                    success: function(data){ 
                                        try {
                                            console.log("[BIZFLOWRULE] getDocumentList - succeed to receive document list. " + JSON.stringify(data));
                                        } catch (e) {}
                                        documentTypes = data;
                                        vm.documentTypes = data;
                                        // save the restult to cache not to call the RESTFul API again 
                                        // until new search conditions used.
                                        if (typeof vm.markersMap !== 'undefined') {
                                            vm.markersMap[JSON.stringify(vm.markers)] = JSON.stringify(vm.documentTypes);
                                        }
                                    },
                                    failure: function(errMsg) {
                                        console.error("[BIZFLOWRULE] getDocumentList - failed to receive document list. " + errMsg);
                                        documentTypes = [{
                                                ACTIVE: '1',
                                                DISPORDER: '1',
                                                ID: '99',
                                                LABEL: 'Others',
                                                LTYPE: 'DocumentType',
                                                NAME: 'Others',
                                                PARENTID: '0'
                                            }];
                                        vm.documentTypes = documentTypes;    
                                    },
                                    async:false
                                });                                
                            }

                        }

                        //TAEHO #165145 04/02/2018 Commented out to use Document rules from BizFlow Rule service
                        /*
                        if (hiringMethod){
                            if (submissionReason){  // Classification Process
                                if(hiringMethod.text === 'Title 5'){                                    
                                    if(submissionReason.text === 'New') {
                                        documentTypes = [{
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '101',
                                            LABEL: 'Position Description',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Description',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '2',
                                            ID: '108',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '99',
                                            LABEL: 'Others',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Others',
                                            PARENTID: '0'
                                        }];          
                                    }
                                    else if(submissionReason.text === 'Realignment') {
                                        documentTypes = [{
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '110',
                                            LABEL: 'Realignment Spreadsheet',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Realignment Spreadsheet',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '2',
                                            ID: '111',
                                            LABEL: 'Justification',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Justification',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '3',
                                            ID: '112',
                                            LABEL: 'Staffing List',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Staffing List',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '4',
                                            ID: '108',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '99',
                                            LABEL: 'Others',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Others',
                                            PARENTID: '0'
                                        }];    
                                    }
                                    else if(submissionReason.text === 'BUS Code Change') {
                                        documentTypes = [{
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '101',
                                            LABEL: 'Position Description',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Description',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '2',
                                            ID: '103',
                                            LABEL: 'OF-8',
                                            LTYPE: 'DocumentType',
                                            NAME: 'OF-8',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '3',
                                            ID: '111',
                                            LABEL: 'Justification',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Justification',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '4',
                                            ID: '108',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '99',
                                            LABEL: 'Others',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Others',
                                            PARENTID: '0'
                                        }]; 
                                    }
                                    else {
                                        documentTypes = [{
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '101',
                                            LABEL: 'Position Description',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Description',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '2',
                                            ID: '103',
                                            LABEL: 'OF-8',
                                            LTYPE: 'DocumentType',
                                            NAME: 'OF-8',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '3',
                                            ID: '108',
                                            LABEL: 'Position Sensitivity Form',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Sensitivity Form',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '4',
                                            ID: '108',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '99',
                                            LABEL: 'Others',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Others',
                                            PARENTID: '0'
                                        }]; 
                                    }                                 
                                }
                                else if (hiringMethod.text.startsWith('Title 42')){
                                    documentTypes = [{
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '113',
                                        LABEL: 'Statement of Duties',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Statement of Duties',
                                        PARENTID: '0'
                                    }, {
                                        ACTIVE: '1',
                                        DISPORDER: '4',
                                        ID: '108',
                                        LABEL: 'Org Chart',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Org Chart',
                                        PARENTID: '0'
                                    }, {
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '99',
                                        LABEL: 'Others',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Others',
                                        PARENTID: '0'
                                    }];
                                }
                                else{
                                    documentTypes = [{
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '101',
                                        LABEL: 'Position Description',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Position Description',
                                        PARENTID: '0'
                                    }, {
                                        ACTIVE: '1',
                                        DISPORDER: '4',
                                        ID: '108',
                                        LABEL: 'Org Chart',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Org Chart',
                                        PARENTID: '0'
                                    }, {
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '99',
                                        LABEL: 'Others',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Others',
                                        PARENTID: '0'
                                    }];
                                }                                        
                            }
                            else{   // Recruitment Process                            
                                if(hiringMethod.text === 'Title 5'){
                                    documentTypes = [{
                                            ACTIVE: '1',
                                            DISPORDER: '2',
                                            ID: '101',
                                            LABEL: 'Position Description',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Description',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '3',
                                            ID: '102',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '4',
                                            ID: '103',
                                            LABEL: 'OF-8',
                                            LTYPE: 'DocumentType',
                                            NAME: 'OF-8',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '99',
                                            LABEL: 'Others',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Others',
                                            PARENTID: '0'
                                        }];
                                    }
                                else if (hiringMethod.text.startsWith('Title 42')){
                                    documentTypes = [
                                        {
                                            ACTIVE: '1',
                                            DISPORDER: '4',
                                            ID: '108',
                                            LABEL: 'Position Sensitivity Form',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Sensitivity Form',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '5',
                                            ID: '109',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '99',
                                            LABEL: 'Others',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Others',
                                            PARENTID: '0'
                                        }];                         
                                }
                                else {
                                    documentTypes = [{
                                        ACTIVE: '1',
                                        DISPORDER: '2',
                                        ID: '101',
                                        LABEL: 'Position Description',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Position Description',
                                        PARENTID: '0'
                                    }, {
                                        ACTIVE: '1',
                                        DISPORDER: '4',
                                        ID: '103',
                                        LABEL: 'OF-8',
                                        LTYPE: 'DocumentType',
                                        NAME: 'OF-8',
                                        PARENTID: '0'
                                    }, {
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '99',
                                        LABEL: 'Others',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Others',
                                        PARENTID: '0'
                                    }];
                                }
                            }     
                        }                    
                        
                        else {
                            
                        }
                        */                        
                    }
                 
                }catch(e){
                     // Intentionally Empty
                 	 // The exception will be generated only when the form is initally loaded. No need to have the document type list is set at that moment. 
                }

                documentTypes.sort(function (item1, item2) {
                    if (item1.NAME === item2.NAME) {
                        return 0;
                    } else {
                        return (item1.NAME > item2.NAME ? 1 : -1);
                    }
                });

                documentTypes.forEach(function (item) {
                    item.Label = item.LABEL;
                    item.Name = item.LABEL;
                });
                documentTypes.dataMap = angularExt.objectToMap(documentTypes, 'Label');
                return documentTypes;
            };
            vm.getMissingDocumentList = function () {
                console.log("[BIZFLOWRULE] getMissingDocumentList starts");
                var attachments = bizflowWih.getAttachments();                
                var mandatoryDocumentListOrg = [];
                // var mandatoryDocumentListOrg = LookupManager.findByLTYPE('MandatoryDocument[' + vm.processType + ']/MDClassificationType[' + classType + ']/MDDocumentType');
                try{
                    if (FormState){

                        //TAEHO #165145 04/02/2018 Document rules from BizFlow Rule service
                        //We do not need to call two API, since documentTypes has REQUIRED property to check it it's a mandatory document.
                        if (typeof vm.documentTypes !== 'undefined') {
                            for (var i=0; i<vm.documentTypes.length; i++) {
                                var doc = vm.documentTypes[i];
                                if (true === doc.REQUIRED) {
                                    mandatoryDocumentListOrg.push(doc);                                    
                                }
                            };
                        };

                        if (typeof mandatoryDocumentListOrg !== 'undefined') {
                            console.log("[BIZFLOWRULE] Mandatory document list =" + JSON.stringify(mandatoryDocumentListOrg));
                        }
                        //TAEHO #165145 04/02/2018 Commented out to use Document rules from BizFlow Rule service
                        /*
                            [
                               {
                                  "isRequired":false,
                                  "ACTIVE":1,
                                  "ID":1,
                                  "LABEL":"Position Description",
                                  "LTYPE":"DocumentType",
                                  "NAME":"Position Description",
                                  "PARENTID":0,
                                  "DISPORDER":1,
                                  "METADATALIST":[

                                  ],
                                  "REQUIRED":false
                               },
                               {
                                  "isRequired":false,
                                  "ACTIVE":1,
                                  "ID":2,
                                  "LABEL":"Position Sensitivity Form",
                                  "LTYPE":"DocumentType",
                                  "NAME":"Position Sensitivity Form",
                                  "PARENTID":0,
                                  "DISPORDER":2,
                                  "METADATALIST":[

                                  ],
                                  "REQUIRED":false
                               },
                               {
                                  "isRequired":false,
                                  "ACTIVE":1,
                                  "ID":3,
                                  "LABEL":"Organizational Chart",
                                  "LTYPE":"DocumentType",
                                  "NAME":"Organizational Chart",
                                  "PARENTID":0,
                                  "DISPORDER":3,
                                  "METADATALIST":[

                                  ],
                                  "REQUIRED":false
                               },
                               {
                                  "isRequired":false,
                                  "ACTIVE":1,
                                  "ID":4,
                                  "LABEL":"Other",
                                  "LTYPE":"DocumentType",
                                  "NAME":"Other",
                                  "PARENTID":0,
                                  "DISPORDER":4,
                                  "METADATALIST":[

                                  ],
                                  "REQUIRED":false
                               }
                            ]
                        */

                        /*                
                        //var requestType = FormState.getState('RT_ID');
                        //if (requestType && requestType.text === 'Recruitment'){
                        var hiringMethod = FormState.getState('HM_ID');
                        var submissionReason = FormState.getState('REASON_SUB');
                        if (hiringMethod){
                            if(submissionReason)    // Classification Process
                            {
                                if(hiringMethod.text === 'Title 5')
                                {                                    
                                    if(submissionReason.text === 'New'){
                                        mandatoryDocumentListOrg = [{
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '101',
                                            LABEL: 'Position Description',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Description',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '2',
                                            ID: '108',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }];
                                    }
                                    else if(submissionReason.text === 'Realignment') {
                                        mandatoryDocumentListOrg = [{
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '110',
                                            LABEL: 'Realignment Spreadsheet',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Realignment Spreadsheet',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '2',
                                            ID: '111',
                                            LABEL: 'Justification',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Justification',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '3',
                                            ID: '112',
                                            LABEL: 'Staffing List',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Staffing List',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '4',
                                            ID: '108',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }];    
                                    }
                                    else if(submissionReason.text === 'BUS Code Change') {
                                        mandatoryDocumentListOrg = [{
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '101',
                                            LABEL: 'Position Description',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Description',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '3',
                                            ID: '113',
                                            LABEL: 'Justification',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Justification',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '4',
                                            ID: '108',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }]; 
                                    }
                                    else {
                                        mandatoryDocumentListOrg = [{
                                            ACTIVE: '1',
                                            DISPORDER: '1',
                                            ID: '101',
                                            LABEL: 'Position Description',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Description',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '3',
                                            ID: '113',
                                            LABEL: 'Position Sensitivity Form',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Sensitivity Form',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '4',
                                            ID: '108',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }]; 
                                    }
                                }
                                else if(hiringMethod.text.startsWith('Title 42')){
                                    mandatoryDocumentListOrg = [{
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '113',
                                        LABEL: 'Statement of Duties',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Statement of Duties',
                                        PARENTID: '0'
                                    }, {
                                        ACTIVE: '1',
                                        DISPORDER: '4',
                                        ID: '108',
                                        LABEL: 'Org Chart',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Org Chart',
                                        PARENTID: '0'
                                    }]; 
                                }
                                else{
                                    mandatoryDocumentListOrg = [{
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '101',
                                        LABEL: 'Position Description',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Position Description',
                                        PARENTID: '0'
                                    }, {
                                        ACTIVE: '1',
                                        DISPORDER: '4',
                                        ID: '108',
                                        LABEL: 'Org Chart',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Org Chart',
                                        PARENTID: '0'
                                    }];
                                }
                            }
                            else{   // Recruitment Process
                                if(hiringMethod.text === 'Title 5'){
                                    mandatoryDocumentListOrg = [{
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '101',
                                        LABEL: 'Position Description',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Position Description',
                                        PARENTID: '0'
                                    },{
                                        ACTIVE: '1',
                                        DISPORDER: '1',
                                        ID: '103',
                                        LABEL: 'OF-8',
                                        LTYPE: 'DocumentType',
                                        NAME: 'OF-8',
                                        PARENTID: '0'
                                    }, {
                                        ACTIVE: '1',
                                        DISPORDER: '3',
                                        ID: '102',
                                        LABEL: 'Org Chart',
                                        LTYPE: 'DocumentType',
                                        NAME: 'Org Chart',
                                        PARENTID: '0'
                                    }];                    
                                }
                                else if (hiringMethod.text.startsWith('Title 42')){
                                    mandatoryDocumentListOrg = [
                                        {
                                            ACTIVE: '1',
                                            DISPORDER: '4',
                                            ID: '107',
                                            LABEL: 'Position Sensitivity Form',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Position Sensitivity Form',
                                            PARENTID: '0'
                                        }, {
                                            ACTIVE: '1',
                                            DISPORDER: '5',
                                            ID: '108',
                                            LABEL: 'Org Chart',
                                            LTYPE: 'DocumentType',
                                            NAME: 'Org Chart',
                                            PARENTID: '0'
                                        }];                         
                                }
                                else{
    
                                }        
                            }
                            
                        }                                              
                        else {
                            //mandatoryDocumentListOrg = [];
                        }
                        */
                    }
                }catch(e){
                 	    // Intentionally Empty
                 	    // The exception will be generated only when the form is initally loaded. No need to have the mandatory document list is set at that moment. 
                }
                // For the activities requiring no hard stopping
                var hardStopRequired = $('#h_hardStopRequired').val();
                if (hardStopRequired === "false") {
                    return [];  // No mandatory document list
                }
                var mandatoryDocumentList = mandatoryDocumentListOrg.slice();
                var attachmentsCopy = attachments.slice();

                //if (attachments != null && attachments.length > 0) {
                if (attachmentsCopy != null && attachmentsCopy.length > 0) {
                    if (mandatoryDocumentList != null && mandatoryDocumentList.length > 0) {
                        for (var index = mandatoryDocumentList.length - 1; index >= 0; index--) {
                            //for (var attachmentIndex = 0; attachmentIndex < attachment.length; attachmentIndex++) {
                            for (var attachmentIndex = attachmentsCopy.length - 1; attachmentIndex >= 0; attachmentIndex--) {
                                //if (attachments[attachmentIndex].CATEGORY === mandatoryDocumentList[index].LABEL) {
                                if (attachmentsCopy[attachmentIndex].CATEGORY === mandatoryDocumentList[index].LABEL) {
                                    mandatoryDocumentList.splice(index, 1);
                                    attachmentsCopy.splice(attachmentIndex, 1);
                                    break;
                                }
                            }
                        }
                    } else {
                        return []; // No mandatory document list is specified.
                    }
                }

                mandatoryDocumentList.sort(function (item1, item2) {
                    if (item1.LABEL === item2.LABEL) {
                        return 0;
                    } else {
                        return (item1.LABEL > item2.LABEL ? 1 : -1);
                    }
                });
                return mandatoryDocumentList;
            };

            //TAEHO #165145 04/02/2018 Document rules from BizFlow Rule service
            vm.getFormFieldValue = function(fieldId) {
                var fieldValue = '';
                try {
                    if (typeof FormState !== 'undefined') {
                        var field = FormState.getState(fieldId);  
                        if (typeof field !== 'undefined') {
                            if (typeof field.value !== 'undefined') {
                                fieldValue = field.value;
                            }
                        }
                    }
                } catch (e) {
                    fieldValue = '';
                }
                return fieldValue;
            };

            vm.init = function () {
                // Prevent backspace from navigating back in AngularJS in IE
                $document.on('keydown', function (event) {
                    if (event.keyCode === 8) {
                        var doPrevent = true;
                        var types = ['text', 'password', 'file', 'search', 'email', 'number', 'date', 'color', 'datetime', 'datetime-local', 'month', 'range', 'search', 'tel', 'time', 'url', 'week'];
                        var d = $(event.srcElement || event.target);
                        var disabled = d.prop('readonly') || d.prop('disabled');
                        if (!disabled) {
                            if (d[0].isContentEditable) {
                                doPrevent = false;
                            } else if (d.is('input')) {
                                var type = d.attr('type');
                                if (type) {
                                    type = type.toLowerCase();
                                }
                                if (types.indexOf(type) > -1) {
                                    doPrevent = false;
                                } else if (d[0].outerHTML.indexOf('textbox') > -1) {
                                    doPrevent = false;
                                } else if (d[0].outerHTML.indexOf('text-box') > -1) {
                                    doPrevent = false;
                                }
                            } else if (d.is('textarea')) {
                                doPrevent = false;
                            }
                        }
                        if (doPrevent) {
                            event.preventDefault();
                        }
                    }
                });

                if (angular.isUndefined(bizflowContext.custom)) bizflowContext.custom = {};

                var absUrl = $location.absUrl();
                bizflowContext.custom.bfIntegrationMode = 'workitem'; // login, bizcove, workitem
                if (bizflowWih.basicWih) {
                    var workitemContext = bizflowWih.getWorkitemContext();
                    bizflowContext.custom.SESSIONINFO = workitemContext.SessionInfoXML;
                    bizflowContext.custom.MEMBERID = workitemContext.User.MemberID;
                    bizflowContext.custom.MEMBERNAME = workitemContext.User.Name;

                    bizflowContext.custom.PROCESSID = workitemContext.Process.ID;
                    bizflowContext.custom.ACTIVITYSEQ = workitemContext.Activity.Sequence;
                    bizflowContext.custom.ACTIVITYNAME = workitemContext.Activity.Name;
                    bizflowContext.custom.WITEMSEQ = workitemContext.Workitem.Sequence;
                    bizflowContext.custom.bfIntegrationMode = 'workitem'; // login, bizcove, workitem
                }
            };

            //TAEHO #165145 04/02/2018 Document rules from BizFlow Rule service - caching the results from BizFlow Rule service for better performance
            vm.markersMap = {};
            vm.markers = {};

            vm.init();

            //TAEHO #165145 04/02/2018 Document rules from BizFlow Rule service
            //Change order of API. getDocumentTypeList() first, and getMissingDocumentList() second.
            //because getDocumentTypeList will get all information we needed. getMissingDocumentList will reuse the result from getDocumentTypeList
            vm.documentTypes = vm.getDocumentTypeList();
            vm.missingDocumentList = vm.getMissingDocumentList();
            //TAEHO #173430 04/30/2018 - OF-8 PDF generation. vm.processType is being used in the Document tab. but this controller did not pass it.
            vm.processType = bizflowWih.getWorkitemContext().Process.Name;
            vm.isBulkProcess = false;
            vm.showHideOriginals = false;
            vm.processID = bizflowContext.custom.PROCESSID;
            vm.isReadOnly = BFUtility.isReadOnly();
            vm.initialRefreshForEligibility = false;

            vm.onChange = function () {
                if (bizflowWih_attachmentCallback != null) {
                    bizflowWih_attachmentCallback = null;
                }

                //TAEHO #164838, #164839 - Making Document Tab readonly - tab9 is Documents tab
                //var tabId = TabManager.getSelectedTabID();
                if (!vm.isReadOnly) {
                    var readOnlyTab = BFActivityOption.getReadOnlyTabList();
                    if (typeof readOnlyTab !== 'undefined') {
                        if (readOnlyTab.indexOf('tab9') >= 0) {
                            console.log("Set the Documents tab readonly.");
                            vm.isReadOnly = true;
                        }
                    }
                }

                //TAEHO #165145 04/02/2018 Document rules from BizFlow Rule service
                //Change order of API. getDocumentTypeList() first, and getMissingDocumentList() second.
                //because getDocumentTypeList will get all information we needed. getMissingDocumentList will reuse the result from getDocumentTypeList
                vm.documentTypes = vm.getDocumentTypeList();
                vm.missingDocumentList = vm.getMissingDocumentList();

                if (vm.missingDocumentList.length > 0) {
                    $('#h_mandatoryDocumentsValid').val('false');
                } else {
                    $('#h_mandatoryDocumentsValid').val('true');
                }

                try {
                    $timeout(function () {
                        $scope.$digest();
                    });
                } catch (e) {
                }
            }

            $(document).on('ON_TAB_CHANGE', function () {
                vm.onChange();
            });
            $(document).on('ON_DOCUMENT_CHANGE', function () {
                vm.onChange();
            })

            BFLog.log('DEBUG', 'p2wcommon - bizflow.app - controller END');
        });
    })(window.angular);

    // console.log("Angular bootstrap START.");
    angular.bootstrap(document.getElementById('attachmentSectionID'), ['bizflow.app']);
    // console.log("Angular bootstrap END.");
}

// -----------------------------------------------------------
// BizFlow AngualrJS extension for CMS
// -----------------------------------------------------------

function refreshAttachment () {
    var attachmentController = null;

    try {
        attachmentController = angular.element(document.getElementById('hhsattachment')).controller('attachments');
        if (attachmentController != null) {
            attachmentController.reloadAttachments2();
        } else {
            console.log('Failed to retrieve attachments controller.')
        }
    } catch (e) {
        console.log('Exception happend while retrieving attachments controller.');
    }
}

/*
    Pop up Attachment Dialog box with given document type.
    @param {string} documentTypeString - Document Type String.
*/
function addCMSDocument (documentTypeString) {
    var attachmentController = null;
    if (documentTypeString == null || documentTypeString.length === 0) {
        documentTypeString = 'Supporting Documents';
    }

    try {
        attachmentController = angular.element(document.getElementById('hhsattachment')).controller('attachments');
    } catch (e) {
        console.log('Failed to retrieve attachments controller.');
    }

    if (attachmentController != null) {
        if (attachmentController.documentTypes != null && attachmentController.documentTypes.length > 0) {
            var foundDocumentType = false;
            for (var index = 0; index < attachmentController.documentTypes.length; index++) {
                if (documentTypeString === attachmentController.documentTypes[index].Name) {
                    foundDocumentType = true;
                    break;
                }
            }

            if (foundDocumentType === false) {
                documentTypeString = 'Supporting Documents';
            }
            attachmentController.addAttachment(documentTypeString);
        }
    }
}

/*
    Pop up Attachment Dialog box to add Existing PD Document.
*/
function addCMSExistingPDDocument () {
    addCMSDocument('Existing Position Description (PD)');
}
