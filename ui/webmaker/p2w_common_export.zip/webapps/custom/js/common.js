var CDCCommon = {
    base_api_url: '/bizflowwebmaker/cdc_api/',

    ajaxCallXML: function(ajaxUrl) {
        if (!ajaxUrl) {
            return;
        }
        return $.ajax({ dataType: 'xml', method: 'GET', url: ajaxUrl, cache: 'false' });
    },

    setAutoComplete: function(containerId, mappers, onBlurHandler) {
        var self = this;
        if (!containerId || !mappers || !onBlurHandler) {
            return;
        }
        $('#' + containerId + ' input.js-autocomplete').each(function() {
            var control = $(this);
            var controlId = control.attr('id');
            var searchUrl = self.base_api_url;
            if (control.data('autocompleteurl')) {
                searchUrl += control.data('autocompleteurl');
            }
            if (!searchUrl || searchUrl.trim() === '' || !mappers[controlId]) {
                return;
            }
            var mapper = mappers[controlId];

            var labelKeys;
            if (control.data('autocompletelabels')) {
                labelKeys = control.data('autocompletelabels');
            } else {
                labelKeys = control.data('autocompletelabel');
            }
            if (!labelKeys || labelKeys.trim() === '') {
                labelKeys = 'label';
            }
            var labelKeysArray = labelKeys.split(',');
            var valueKey = control.data('autocompletevaluename');
            if (!valueKey || valueKey.trim() === '') {
                valueKey = 'value';
            }
            var otherKeys = control.data('autocompleteothers');
            var otherKeysArray = [];
            if (otherKeys && otherKeys.trim() !== '') {
                otherKeysArray = otherKeys.split(',');
            }
            var minLengthData = control.data('autocompleteminlength');
            var minLength = 2;
            if (minLengthData && !isNaN(parseInt(minLengthData)) && parseInt(minLengthData) > 0) {
                minLength = parseInt(minLengthData);
            }
            control.autocomplete({
                source: function(request, response) {
                    self.ajaxCallXML(searchUrl + request.term)
                        .done(function(data) {
                            var dataFromApi = $('record', data).map(mapper).get();
                            response($.map(dataFromApi, function(item) {
                                if (otherKeys) {
                                    for (var i = 0; i < otherKeysArray.length; i++) {
                                        var otherControlId = otherKeysArray[i].split(':')[0].trim();
                                        if ($('#' + otherControlId)[0]) {
                                            FormState.doAction(StateAction.changeText(otherControlId, ''), false);
                                        }
                                    }
                                }
                                var labelData = '';
                                for (var i = 0; i < labelKeysArray.length; i++) {
                                    labelData += item[labelKeysArray[i].trim()] && item[labelKeysArray[i].trim()].trim() !== '' ? (item[labelKeysArray[i].trim()].trim() + ' | ') : '';
                                }
                                labelData = labelData.substr(0, (labelData.length - 3));
                                var valueData = item[valueKey.trim()];
                                var returnData = {
                                    label: labelData,
                                    value: valueData,
                                };
                                for (var i = 0; i < otherKeysArray.length; i++) {
                                    var otherControlKey = otherKeysArray[i].split(':')[0].trim();
                                    var otherControlValueKey = otherKeysArray[i].split(':')[otherKeysArray[i].split(':').length - 1].trim();
                                    if (item[otherControlValueKey]) {
                                        returnData[otherControlKey] = item[otherControlValueKey];
                                    }
                                }
                                return returnData;
                            }));
                        })
                },
                minLength: minLength,
                select: function(event, ui) {
                    for (var i = 0; i < otherKeysArray.length; i++) {
                        var otherControlId = otherKeysArray[i].split(':')[0].trim();

                        if ($('#' + otherControlId)[0]) {
                            FormState.doAction(StateAction.changeText(otherControlId, ui.item[otherControlId]), true);
                        }
                    }
                    FormState.doAction(StateAction.changeText(controlId, ui.item['value']), true);
                },
                change: function(event, ui) {
                    if (!ui.item) {
                        for (var i = 0; i < otherKeysArray.length; i++) {
                            var otherControlId = otherKeysArray[i].split(':')[0].trim();

                            if ($('#' + otherControlId)[0]) {
                                FormState.doAction(StateAction.changeText(otherControlId, ''), true);
                            }
                        }
                        FormState.doAction(StateAction.changeText(controlId, ''), true);
                    }
                }

            });
        }).on('blur', onBlurHandler);;
    },

    addRequired: function(field) {
        if (field) {
            $('#' + field).attr('_required', 'true');
            $('#' + field + '_marker').removeClass('hidden');
        }
    },

    removeRequired: function(field) {
        if (field) {
            $('#' + field).attr('_required', 'false');
            $('#' + field + '_marker').addClass('hidden');
        }
    },

    showField: function(field, addRequired, resetValue) {
        var self = this;
        if (!field) {
            return;
        }
        if (addRequired) {
            self.addRequired(field);
        }
        if (resetValue || resetValue === '') {
            FormState.doAction(StateAction.changeText(field, resetValue), false);
        }
        $('#' + field).removeClass('hidden');
        $('#' + field + '_label').removeClass('hidden');
        $('#' + field + '_container').removeClass('hidden');
        $('#' + field + '_label_container').removeClass('hidden');
    },

    hideField: function(field, removeRequired, resetValue) {
        var self = this;
        if (!field) {
            return;
        }
        if (removeRequired) {
            self.removeRequired(field);
        }
        if (resetValue || resetValue === '') {
            FormState.doAction(StateAction.changeText(field, resetValue), false);
        }
        $('#' + field).addClass('hidden');
        $('#' + field + '_label').addClass('hidden');
        $('#' + field + '_container').addClass('hidden');
        $('#' + field + '_label_container').addClass('hidden');
    },

    showHideField: function(show, field, requiredToggle, resetValue) {
        var self = this;
        if (show === null || !field) { /** show can be false and hence show === null comparison */
            return;
        }
        if (show) {
            self.showField(field, requiredToggle, resetValue);
        } else {
            self.hideField(field, requiredToggle, resetValue);
        }
    },

    searchArray: function(arrayToSearch, value, key) {
        var returnValue = {
            index: -1,
            data: null
        }
        if (arrayToSearch && $.isArray(arrayToSearch) && value) {
            for (var i = 0; i < arrayToSearch.length; i++) {
                if ((key && arrayToSearch[i][key] && arrayToSearch[i][key] === value) || (!key && arrayToSearch[i] === value)) {
                    returnValue.index = i;
                    returnValue.data = arrayToSearch[i];
                    break;
                }
            }
        }
        return returnValue;
    },

    setupFirstLoad: function(checkField, fields) {
        if (!checkField || !fields) {
            return;
        }
        var checkFieldState = FormState.getState(checkField.name);
        if (!checkFieldState) {
            for (var i = 0; i < fields.length; i++) {
                var fieldState = FormState.getState(fields[i].name);
                if (!fieldState || (fields[i].force && fields[i].force === true)) {
                    var value = "";
                    var type = fields[i].etype;
                    if (fields[i].value && fields[i].value !== "") {
                        type = type ? type : 'textbox';
                        value = fields[i].value;
                    } else if (fields[i].firstValue) {
                        type = type ? type : 'select';
                        value = $("#" + fields[i].name).find("option:first-child").val();
                    }
                    switch (type) {
                        case "textbox":
                            FormState.doAction(StateAction.changeText(fields[i].name, value), false);
                        case "checkbox":
                            FormState.doAction(StateAction.changeCheckbox(fields[i].name, value), false);
                        case "radio":
                            FormState.doAction(StateAction.changeRadio(fields[i].name, value), false);
                        case "select":
                            FormState.doAction(StateAction.changeSelect(fields[i].name, value), false);
                        case "date":
                            FormState.doAction(StateAction.changeDate(fields[i].name, value), false);
                    }
                }
            }
            FormState.doAction(StateAction.changeText(checkField.name, checkField.value), false);
        }
    },
    addData: function(id, item, target, valueTextList, showEdit) {
        var self = this;
        var formState = FormState.getState(id);
        var workingData = (formState && formState.value) ? formState.value.split("::") : [];
        var dupCheck = workingData.filter(function(data) {
            return data === item
        });
        if (dupCheck.length === 0 && item.length > 2) {
            workingData.push(item);
        }
        FormState.doAction(StateAction.changeText(id, self.convertMultiDataField(workingData)), false);
        self.renderDisplay(id, target, valueTextList, showEdit);

    },
    removeData: function(id, item, target, valueTextList, showEdit) {
        var self = this;
        var formState = FormState.getState(id);
        var workingData = (formState && formState.value) ? formState.value.split("::") : [];
        workingData = workingData.filter(function(data) { return data !== item.toString() });
        FormState.doAction(StateAction.changeText(id, self.convertMultiDataField(workingData)), false);
        self.renderDisplay(id, target, valueTextList, showEdit);
    },
    renderDisplay: function(id, target, valueTextList, showEdit) {
        var self = this;
        var formState = FormState.getState(id);
        var workingData = (formState && formState.value) ? formState.value.replace(/"/g, "&quot;").split("::") : [];
        var newList = "";
        var labelId = target.split("#")[1];
        var $label = $('label[for="' + labelId + '"]');
        // if (valueTextList) {
        //     self.valueTextList = valueTextList;
        // } else {
        //     self.valueTextList = null;
        // }

        if (id === 'POS_GRADE_IDS' || id === 'POS_TITLES_SERIESES') {
            $label.parent().removeClass('hidden'); // defect 180967
        } else {
            $label.parent().addClass('hidden'); // defect 180967
        }

        if (workingData.length > 0 && workingData[0].length > 0) {
            $label.parent().removeClass('hidden');
            newList = workingData.map(function(data) {
                var displayText = data;
                var returnItem = '<li>';
                if (valueTextList) {
                    var dataValue = data.split('%%')[0];
                    var returnValue = self.searchArray(valueTextList, dataValue, "value");
                    if (returnValue.index !== -1) {
                        displayText = displayText.replace(dataValue, returnValue.data.text);
                        displayText = displayText.replace(/%%/gi, ' / ')
                    }
                } else {
                    displayText = displayText.replace(/%%/gi, ' / ');
                }
                if (showEdit) {
                    returnItem += '<a class="js-' + id + '-edit" href="#" title="Edit - ' + displayText + '" data-item="' + data + '"><img alt="Edit" src="images/controls/edit.png" /></a>&nbsp; ';
                }
                if (id === 'POS_GRADE_RELATED'){
                    return returnItem + displayText + '</li>';                 
                }else{
                    return returnItem + '<a class="js-' + id + '-delete" href="#" title="Delete - ' + displayText + '" data-item="' + data + '"><img alt="Delete" src="images/controls/exit.png" /></a> ' + displayText + '</li>';
                }
            });
        }

        $(target).empty().append(newList);

    },
    convertMultiDataField: function(workingData) {
        var self = this;
        var dataDelimited;
        workingData.forEach(function(data, i, arr) {
            var rtn = data;
            if (i < arr.length - 1) {
                rtn += "::";
            }

            (dataDelimited) ? dataDelimited += rtn: dataDelimited = rtn;
        });
        return dataDelimited;
    },
    checkMultiValueSrc: function(tabID) {
        var isValid = true; //added by Taeho
        $('#' + tabID + ' .multiValueSrc').each(function() {
            var self = this;
            var preserveValue = $(self).hasClass('valueFreeze');
            if ($(self).val() !== '') {
                var lbl = $("label[for='" + $(self).attr('id') + "']").text();
                var confirmMessage = "You have left data in the \"" + lbl + "\" field without clicking Add button, this data will not be saved.\n\n" +
                    " Click \"Cancel\" to go back and Add the " + lbl + ".\n";
                if (!preserveValue) {
                    confirmMessage += "Click \"OK\" to continue without saving.";


                    isValid = confirm(confirmMessage);
                    if (isValid === true) {
                        $(self).val('');
                    }
                } else {
                    alert(confirmMessage.replace(/Cancel/, "OK"));
                    isValid = false;
                }
            }
        });
        return isValid;
    },
    noMultivalSelectedReminder: function(targetID) {
        var reminderText = $('#' + targetID);
        var $label = $('label[for="' + targetID + '"]');
        var labelTextArr = $label[0].innerHTML.split(" ");
        var labelText = labelTextArr.slice(1, labelTextArr.length).join(" ");
        if($('#'+targetID).find('li').text().indexOf("None selected. Please click to Add ") === -1 ){
            reminderText.append('<li value="">None selected. Please click to Add ' + labelText + '</li>');            
        }
    },
    addCurrTextlengthStatus: function(activeFieldState) {
        var length = $(activeFieldState).val().length;
        var maxLength = $(activeFieldState).attr("_maxlength");

        if( $(document.activeElement).parent().find('#paraCurrTextlengthStatus').length < 1){
            $(document.activeElement).parent().append('<p id="paraCurrTextlengthStatus">');
            console.log("Active Element ID in focus : " + $(document.activeElement).context.id );
        }
        
        if (!isNaN(maxLength)) {
            if (parseInt(length) > parseInt(maxLength)) {
                FormState.doAction(StateAction.changeText($(activeFieldState).context.id, $(activeFieldState).context.value.substring(0, parseInt(maxLength)), false));
                length = maxLength;
            }
            //same css properties as what is being used for sibling of Organization Name
            $('#paraCurrTextlengthStatus').css({ 'font-size': '0.8em','color': 'grey','font-weight': 'normal !important' });                        
            $('#paraCurrTextlengthStatus').text("(Now: " + length + " / Max: " + maxLength +")");
        }
        else {
            $('#paraCurrTextlengthStatus').text("");
        }
    },
    removeCurrTextlengthStatus: function() {
        $(document).find('p#paraCurrTextlengthStatus').remove();
        console.log("Removed Element IDs paraCurrTextlengthStatus for type <p>");
    }

};