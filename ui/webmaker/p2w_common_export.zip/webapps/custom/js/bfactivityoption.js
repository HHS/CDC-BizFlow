/* global $ BFUtility */

// BFActivityOption
//
// This object will manage tab information associated with specific activity.
// Tab information should be like following.

// [{
//     name: "Create Request",  // Activity Name
//     usergroup: [],   // Ignore this
//     tabs: ["tab1", "tab2", "tab3", "tab9"],  // Tabs which will be displayed on given activity
//     readonly: [] // Tabs which will be readonly on given activity
// },{
//     name: "Review Request",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab9"],
//     readonly: []
// }, {
//     name: "Modify Request",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab9"],
//     readonly: []
// }, {
//     name: "Hold Strategic Consultation Meeting",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9"],
//     readonly: []
// }, {
//     name: "Acknowledge Strat Cons Meeting",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"],
//     readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9"]
// }, {
//     name: "Approve Strat Cons Meeting",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"],
//     readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9"]
// }, {
//     name: "_Archive_",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"],
//     readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"]
// }]

// Following line is required when executing unit test.
// var $ = function () { return {val: function() {return 'Hello';}}};

function BFActivityOptionException (message) {
    this.message = message;
    this.name = 'BFActivityOption Exception';
};
var BFActivityOption = new function () {
    var _unitTest = false;
    var actList = null;
    var _activityName = null;

    var getActivityName = function () {
        if (_activityName == null) {
            if (_unitTest !== true) {
                _activityName = $('#h_activityName').val();
                if (_activityName == null || _activityName.length === 0) {
                    throw new BFActivityOptionException('Activity name is null or empty. Check the value of h_activityName element.');
                } else {
                    $('#h_activityName').val('');
                }
            } else {
                _activityName = 'Approve Strat Cons Meeting';
            }
        }
        return _activityName;
    };

    var getActivityOption = function (activityName) {
        if (typeof activityName === 'undefined' || activityName === null || activityName.length === 0) {
            activityName = getActivityName();
        }
        var currentActList = [];
        currentActList = actList.filter(function (node, index) {
            var memberCount = 0;
            if (node.usergroup.length > 0) {
                node.usergroup.forEach(function (group) {
                    if (BFUtility.isCurrentUserMemberOf(group) === true) {
                        memberCount++;
                    }
                })
            }
            return node.name === activityName && (memberCount === node.usergroup.length || memberCount > 0);
        });
        // If current activity is not in the BFActivityOption, add _Archive_ configuration
        if (currentActList.length === 0) {
            currentActList = actList.filter(function (node, index) {
                if (node.name === '_Archive_') {
                    return true;
                } else {
                    return false;
                }
            });
        }
        return currentActList[0];
    };

    var getTabList = function (activityName) {
        var option = getActivityOption(activityName);
        return option.tabs;
    };
    var getReadOnlyTabList = function (activityName) {
        var option = getActivityOption(activityName);
        return option.readonly.slice();
    }
    var setReadOnlyTabList = function(activityName, readonlyTabList) {
        var option = getActivityOption(activityName);
        option.readonly = readonlyTabList;
    };
    var addTabToCurrentActivity = function (activityName, tabID) {
        var tabs = getTabList(activityName);
        var index = 0;
        for (; index < tabs.length; index++) {
            if (tabs[index] === tabID) {
                return; // Already exists.
            }
        }
        for (index = 0; index < tabs.length; index++) {
            if (tabs[index] > tabID) {
                tabs.splice(index, 0, tabID);
                break;
            }
        }
    };
    var removeTabFromCurrentActivity = function (activityName, tabID) {
        var tabs = getTabList(activityName);
        for (var index = 0; index < tabs.length; index++) {
            if (tabs[index] === tabID) {
                tabs.splice(index, 1);
                break;
            }
        }
    };
    var getNextTabID = function (currentTabID) {
        var tabs = getTabList();
        for (var index = 0; index < tabs.length; index++) {
            if (tabs[index] === currentTabID) {
                if (index < tabs.length - 1) {
                    return tabs[index + 1];
                }
            }
        }
        return null;
    };
    var getPreviousTabID = function (currentTabID) {
        var tabs = getTabList();
        for (var index = 0; index < tabs.length; index++) {
            if (tabs[index] === currentTabID) {
                if (index > 0) {
                    return tabs[index - 1];
                }
            }
        }
        return null;
    };

    var init = function (activityOptions) {
        if (typeof activityOptions === 'undefined' || activityOptions === null || activityOptions.length === 0) {
            throw new BFActivityOptionException('Parameter activityOptions is invalid. It should have activity information');
        }

        actList = activityOptions;
        getActivityName();
        getActivityOption();
    };

    return {
        _unitTest: _unitTest,
        init: init,
        getActivityName: getActivityName,
        getTabList: getTabList,
        getReadOnlyTabList: getReadOnlyTabList,
        setReadOnlyTabList: setReadOnlyTabList,
        addTabToCurrentActivity: addTabToCurrentActivity,
        removeTabFromCurrentActivity: removeTabFromCurrentActivity,
        getNextTabID: getNextTabID,
        getPreviousTabID: getPreviousTabID
    };
}();

//
// Unit test code
//
// var options = [{
//     name: "Create Request",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab9"],
//     readonly: []
// },{
//     name: "Review Request",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab9"],
//     readonly: []
// }, {
//     name: "Modify Request",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab9"],
//     readonly: []
// }, {
//     name: "Hold Strategic Consultation Meeting",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9"],
//     readonly: []
// }, {
//     name: "Acknowledge Strat Cons Meeting",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"],
//     readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9"]
// }, {
//     name: "Approve Strat Cons Meeting",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"],
//     readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9"]
// }, {
//     name: "_Archive_",
//     usergroup: [],
//     tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"],
//     readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"]
// }];

// BFActivityOption._unitTest = true;

// var exceptionHappened = false;
// try {
//     BFActivityOption.init();
// } catch (exception) {
//     exceptionHappened = true;
// }
// if (exceptionHappened == false) {
//     console.log('FAILED - init. It should raise exception when parameter is not given to init function.');
// } else {
//     console.log('SUCCEEDED - init');
// }

// // init: init
// BFActivityOption.init(options);
// var activityName = BFActivityOption.getActivityName();
// if (activityName !== 'Approve Strat Cons Meeting') {
//     console.log('FAILED - getActivityName. It should be "Approve Strat Cons Meeting" but returns ' + activityName);
// } else {
//     console.log('SUCCEEDED - getActivityName');
// };
// // getTabList: getTabList
// var tabs = BFActivityOption.getTabList('Approve Strat Cons Meeting');
// if (tabs === null || tabs.length !== 9) {
//     console.log('FAILED - getTabList. It should return array of 9 items.');
// } else {
//     console.log('SUCCEEDED - getTabList');
// }
// // addTabToCurrentActivity: addTabToCurrentActivity,
// BFActivityOption.addTabToCurrentActivity('Approve Strat Cons Meeting', 'tab10');
// var tabs = BFActivityOption.getTabList('Approve Strat Cons Meeting');
// if (tabs === null || tabs.length !== 10) {
//     console.log('FAILED - addTabToCurrentActivity. It should add new tab to the activity.');
// } else {
//     console.log('SUCCEEDED - addTabToCurrentActivity - Test 1');
// }
// BFActivityOption.addTabToCurrentActivity('Approve Strat Cons Meeting', 'tab10');
// var tabs = BFActivityOption.getTabList('Approve Strat Cons Meeting');
// if (tabs === null || tabs.length !== 10) {
//     console.log('FAILED - addTabToCurrentActivity. It should not add tab, which exists already, to the activity.');
// } else {
//     console.log('SUCCEEDED - addTabToCurrentActivity - Test 2');
// }

// // removeTabFromCurrentActivity: removeTabFromCurrentActivity,
// BFActivityOption.removeTabFromCurrentActivity('Approve Strat Cons Meeting', 'tab10');
// var tabs = BFActivityOption.getTabList('Approve Strat Cons Meeting');
// if (tabs === null || tabs.length !== 9) {
//     console.log('FAILED - removeTabFromCurrentActivity. It should remove given tab from the activity.');
// } else {
//     console.log('SUCCEEDED - removeTabFromCurrentActivity - Test 1');
// }
// BFActivityOption.removeTabFromCurrentActivity('Approve Strat Cons Meeting', 'tab10');
// var tabs = BFActivityOption.getTabList('Approve Strat Cons Meeting');
// if (tabs === null || tabs.length !== 9) {
//     console.log('FAILED - removeTabFromCurrentActivity. It should not remove the tab, which doesn\'t exist, from the activity.');
// } else {
//     console.log('SUCCEEDED - removeTabFromCurrentActivity - Test 2');
// }
// // getSelectedTabID: getSelectedTabID,
// var selectedTabID = BFActivityOption.getSelectedTabID();
// if (selectedTabID === null || selectedTabID != 'tab3') {
//     console.log('FAILED - getSelectedTabID. It sholud return tab3.');
// } else {
//     console.log('SUCCEEDED - getSelectedTabID');
// }
// // getNextTabID: getNextTabID,
// var nextTabID = BFActivityOption.getNextTabID('tab3');
// if (nextTabID === null || nextTabID.length === 0 || nextTabID != 'tab4') {
//     console.log('FAILED = getNextTabID. It should return tab4');
// } else {
//     console.log('SUCCEEDED - getNextTabID');
// }
// // getPreviousTabID: getPreviousTabID
// var prevTabID = BFActivityOption.getPreviousTabID('tab3');
// if (prevTabID === null || prevTabID.length === 0 || prevTabID != 'tab2') {
//     console.log('FAILED = getPreviousTabID. It should return tab2');
// } else {
//     console.log('SUCCEEDED - getPreviousTabID');
// }
