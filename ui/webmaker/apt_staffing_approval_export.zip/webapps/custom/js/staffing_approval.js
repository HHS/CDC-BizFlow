/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var aptStaffApp = {
    initSetupDone: false,
    checkField: {
        name: 'appInitComplete',
        value: 'true'
    },
    showProcessingApp: false,
    showStaffingApp: false,
    showHigherApp: false,
    currentStep: '',
    nextPVApprover: 0,
    pvVariables: [
        ['#pv_atcSignOffReq2', '#pv_atcApprover2'],
        ['#pv_atcSignOffReq3', '#pv_atcApprover3'],
    ],
    //**Default values for First Load Fields */
    fields: [
        { name: 'RETROACTIVE', firstValue: true },
        { name: 'RETRO_MEMO_DATE', value: "" },
        { name: 'CAP_HR_POS_NUM', value: "" },
        { name: 'JOB_CODE', value: "" },
        { name: 'WORK_AUTHORIZATION_STATUS', firstValue: true },
        { name: 'WORK_AUTHORIZATION_DECISION_DATE', value: "" },
        { name: 'ETHICS_CLEARANCE_STATUS', firstValue: true },
        { name: 'ETHICS_DECISION_DATE', value: "" },
        { name: 'SECURITY_CLEARANCE_STATUS', firstValue: true },
        { name: 'SECURITY_DECISION_DATE', value: "" },
        { name: 'HR_PROCESSOR_ACKNOWLEDGE', value: false },
        { name: 'HR_PROCESSOR_APPROVAL', value: "" },
        { name: 'HR_PROCESSOR_DATE', value: "" },
        { name: 'HR_STAFFING_ACKNOWLEDGE', value: false },
        { name: 'HR_STAFFING_APPROVAL', value: "" },
        { name: 'HR_STAFFING_DATE', value: "" },
        { name: 'ATC_SIGN_OFF_REQ_2', firstValue: true },
        { name: 'atcSignOffReq2', value: "" },
        { name: 'ATC_APPROVER_2', value: "" },
        { name: 'ATC_APPROVER_EMAIL_2', value: "" },
        { name: 'HR_SENIOR_STAFFING_ACKNOWLEDGE', value: false },
        { name: 'HR_SENIOR_STAFFING_APPROVAL', value: "" },
        { name: 'HR_SENIOR_STAFFING_DATE', value: "" }

    ],
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        var sysDate = new Date();
        var todaysDate = ('0' + (sysDate.getMonth() + 1)).slice(-2) + '/' + ('0' + sysDate.getDate()).slice(-2) + '/' + sysDate.getFullYear();
        var hroSpec = $('#pv_hroSpecialist').val();
        var curActivity = $('#curActivity').val();
        var hasProcessor = (FormState.getState('HR_PROCESSOR_ACKNOWLEDGE')) ? (FormState.getState('HR_PROCESSOR_ACKNOWLEDGE')).value : false;
        var pendingWor = ((FormState.getState('WORK_AUTHORIZATION_STATUS')) ? (FormState.getState('WORK_AUTHORIZATION_STATUS')).value === 'Pending' : true) && !($('#WORK_AUTHORIZATION_STATUS').hasClass('hidden'));
        var pendingWEth = (FormState.getState('ETHICS_CLEARANCE_STATUS')) ? (FormState.getState('ETHICS_CLEARANCE_STATUS')).value === 'Pending' : true;
        var pendingSec = (FormState.getState('SECURITY_CLEARANCE_STATUS')) ? (FormState.getState('SECURITY_CLEARANCE_STATUS')).value === 'Pending' : true;
        var rejectedWor = ((FormState.getState('WORK_AUTHORIZATION_STATUS')) ? (FormState.getState('WORK_AUTHORIZATION_STATUS')).value === 'Rejected' : false) && !($('#WORK_AUTHORIZATION_STATUS').hasClass('hidden'));
        var rejectedWEth = (FormState.getState('ETHICS_CLEARANCE_STATUS')) ? (FormState.getState('ETHICS_CLEARANCE_STATUS')).value === 'Rejected' : false;
        var rejectedSec = (FormState.getState('SECURITY_CLEARANCE_STATUS')) ? (FormState.getState('SECURITY_CLEARANCE_STATUS')).value === 'Rejected' : false;

        if (fieldState) {
            switch (field) {
                case "HR_PROCESSOR_ACKNOWLEDGE":
                    if (fieldState.dirty) {

                        if (rejectedSec || rejectedWEth || rejectedWor) {
                            alert("You cannot acknowledge the request due to a Rejection in the above status section.  This request should be canceled.");
                            FormState.doAction(StateAction.changeText('HR_PROCESSOR_ACKNOWLEDGE', false), false);
                        } else if (pendingWor || pendingWEth || pendingSec) {
                            alert("You cannot acknowledge the request while any of the above statuses are pending or incomplete.");
                            FormState.doAction(StateAction.changeText('HR_PROCESSOR_ACKNOWLEDGE', false), false);
                        } else if (self.currentStep === 'processor') {
                            if (fieldState.value) {
                                FormState.doAction(StateAction.changeText('HR_PROCESSOR_APPROVAL', $('#current_user_name').val() + "/" + $('#current_user_title').val()), false);
                                FormState.doAction(StateAction.changeText('HR_PROCESSOR_DATE', todaysDate), false);
                                $(self.pvVariables[self.nextPVApprover][0]).val('Yes');
                                $(self.pvVariables[self.nextPVApprover][1]).val(hroSpec);
                            } else {
                                FormState.doAction(StateAction.changeText('HR_PROCESSOR_APPROVAL', ''), false);
                                FormState.doAction(StateAction.changeText('HR_PROCESSOR_DATE', ''), false);
                            }
                        }
                    }
                    break;
                case "HR_STAFFING_ACKNOWLEDGE":
                    if (fieldState.dirty) {

                        if (rejectedSec || rejectedWEth || rejectedWor) {
                            alert("You cannot acknowledge the request due to a Rejection in the above status section.  This request should be canceled.");
                            FormState.doAction(StateAction.changeText('HR_STAFFING_ACKNOWLEDGE', false), false);
                        } else if (pendingWor || pendingWEth || pendingSec) {
                            alert("You cannot acknowledge the request while any of the above statuses are pending or incomplete");
                            FormState.doAction(StateAction.changeText('HR_STAFFING_ACKNOWLEDGE', false), false);
                        } else if (self.currentStep === 'staffing') {
                            if (fieldState.value) {
                                FormState.doAction(StateAction.changeText('HR_STAFFING_APPROVAL', $('#current_user_name').val() + "/" + $('#current_user_title').val()), false);
                                FormState.doAction(StateAction.changeText('HR_STAFFING_DATE', todaysDate), false);
                            } else {
                                FormState.doAction(StateAction.changeText('HR_STAFFING_APPROVAL', ''), false);
                                FormState.doAction(StateAction.changeText('HR_STAFFING_DATE', ''), false);
                            }
                        }
                    }
                    break;
                case "ATC_SIGN_OFF_REQ_2":
                    if (fieldState.dirty) {
                        if (fieldState.value === 'Yes') {
                            CDCCommon.showField('ATC_APPROVER_2', true);
                            CDCCommon.showField('ATC_APPROVER_EMAIL_2', true);
                        } else {
                            CDCCommon.hideField('ATC_APPROVER_2', true, '');
                            CDCCommon.hideField('ATC_APPROVER_EMAIL_2', true, '');
                        }
                        $(self.pvVariables[self.nextPVApprover][0]).val(fieldState.value);
                    }
                    break;
                case 'NEXT_APPROVER':

                    if (fieldState.dirty && fieldState.value) {
                        $(self.pvVariables[self.nextPVApprover][1]).val(fieldState.value);
                    }
                    break;
                case "HR_SENIOR_STAFFING_ACKNOWLEDGE":
                    if (fieldState.dirty) {
                        if (self.currentStep === 'higherapproval') {
                            if (fieldState.value) {
                                FormState.doAction(StateAction.changeText('HR_SENIOR_STAFFING_APPROVAL', $('#current_user_name').val() + "/" + $('#current_user_title').val()), false);
                                FormState.doAction(StateAction.changeText('HR_SENIOR_STAFFING_DATE', todaysDate), false);
                            } else if (self.initSetupDone) {
                                FormState.doAction(StateAction.changeText('HR_SENIOR_STAFFING_APPROVAL', ''), false);
                                FormState.doAction(StateAction.changeText('HR_SENIOR_STAFFING_DATE', ''), false);
                            }
                        }
                    }
                    break;
                case "RETROACTIVE":
                    if (fieldState.value === 'Yes') {
                        CDCCommon.showField('RETRO_MEMO_DATE', true);
                    } else {
                        CDCCommon.hideField('RETRO_MEMO_DATE', true, '');
                    }
                    break;
                case "WORK_AUTHORIZATION_STATUS":
                    if (fieldState.value === 'N/A' || fieldState.value === 'Pending') {
                        CDCCommon.hideField('WORK_AUTHORIZATION_DECISION_DATE', true, '');
                    } else {
                        CDCCommon.showField('WORK_AUTHORIZATION_DECISION_DATE', true);
                    }
                    break;
                case "ETHICS_CLEARANCE_STATUS":
                    if (fieldState.value === 'N/A' || fieldState.value === 'Pending') {
                        CDCCommon.hideField('ETHICS_DECISION_DATE', true, '');
                    } else {
                        CDCCommon.showField('ETHICS_DECISION_DATE', true);
                    }
                    break;
                case "SECURITY_CLEARANCE_STATUS":
                    if (fieldState.value === 'N/A' || fieldState.value === 'Pending') {
                        CDCCommon.hideField('SECURITY_DECISION_DATE', true, '');
                    } else {
                        CDCCommon.showField('SECURITY_DECISION_DATE', true);
                    }
                    break;
            }
        }
    },
    renderer: function() {
        var self = this;

        if (!self.initSetupDone) {
            self.initSetup();

        }

        self.actionOnChange('RETROACTIVE');
        self.actionOnChange('HR_PROCESSOR_ACKNOWLEDGE');
        self.actionOnChange('HR_STAFFING_ACKNOWLEDGE');
        self.actionOnChange('HR_SENIOR_STAFFING_ACKNOWLEDGE');
        self.actionOnChange('ATC_SIGN_OFF_REQ_2');
        self.actionOnChange('NEXT_APPROVER');
        self.actionOnChange('WORK_AUTHORIZATION_STATUS');
        self.actionOnChange('ETHICS_CLEARANCE_STATUS');
        self.actionOnChange('SECURITY_CLEARANCE_STATUS');

        self.showPocVar('Render');
        self.initSetupDone = true;

    },
    showPocVar: function(loc) {
        var self = this;
        console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        console.log("Location : ", loc)
        console.log("ATC Signoff 2 : ", $('#pv_atcSignOffReq2').val());
        console.log("ATC Approver 2 : ", $('#pv_atcApprover2').val());

        console.log("ATC Signoff 3 : ", $('#pv_atcSignOffReq3').val());
        console.log("ATC Approver 3 : ", $('#pv_atcApprover3').val());
        console.log("Show Processor: ", self.showProcessingApp);
        console.log("Show Staffing: ", self.showStaffingApp);
        console.log("Show Higher Approval: ", self.showHigherApp);
        console.log("Current Step ", self.currentStep);

        console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    },
    checkRoleStep: function() {
        var self = this;
        var hiringMethod = self.getHiringMethod();
        var isHSAssistant = aptMain.isCurrentUserHSAssistant();
        var isHRAssistant = aptMain.checkUserRoleByRoleName('HR Assistants');
        var isHRStaffing = aptMain.checkUserRoleByRoleName('Staffing Specialists');
        var isSeniorHRStaffing = aptMain.checkUserRoleByRoleName('Senior HR Staffing Specialist');
        var curActivity = $('#curActivity').val();
        var hasProcessor = (FormState.getState('HR_PROCESSOR_ACKNOWLEDGE')) ? (FormState.getState('HR_PROCESSOR_ACKNOWLEDGE')).value : false;;
        var hasHigherApp = (FormState.getState('HR_SENIOR_STAFFING_ACKNOWLEDGE')) ? (FormState.getState('HR_SENIOR_STAFFING_ACKNOWLEDGE')).value : false;;

        console.log(hiringMethod, isHRAssistant, isHRStaffing, hasProcessor);
        self.showProcessingApp = false;
        if ((hiringMethod === 'Title 5' && (isHRAssistant && !isHRStaffing) && curActivity === 'Track Clearances and Finalize Package/ATC') || hasProcessor) {
            self.showProcessingApp = true;
        }

        self.showStaffingApp = false;
        if (isHRStaffing || curActivity !== 'Track Clearances and Finalize Package/ATC') {
            self.showStaffingApp = true;
        }

        self.showHigherApp = false;
        if (curActivity === 'Provide Third ATC Approval' || (curActivity === 'Provide Second ATC Approval' && !hasProcessor) || hasHigherApp) {
            self.showHigherApp = true;
        }

        self.currentStep = 'processor';
        self.nextPVApprover = 0;
        if ((isHRStaffing && curActivity === 'Track Clearances and Finalize Package/ATC') || (hasProcessor && curActivity === 'Provide Second ATC Approval')) {
            self.currentStep = 'staffing';
            if (hasProcessor && curActivity === 'Provide Second ATC Approval') {
                self.nextPVApprover = 1;
            }
        }
        if ((!hasProcessor && curActivity === 'Provide Second ATC Approval') || curActivity === 'Provide Third ATC Approval') {
            self.currentStep = 'higherapproval';
        }



    },
    initSetup: function() {
        var self = this;
        var hiringMethod = self.getHiringMethod();
        self.checkRoleStep();

        if (!self.showProcessingApp) {
            self.hideHRStaffingGroup('HR_PROCESSOR');
        }
        if (!self.showStaffingApp) {
            self.hideHRStaffingGroup('HR_STAFFING');
        }
        if (!self.showHigherApp) {
            self.hideHRStaffingGroup('HR_SENIOR_STAFFING');
        }

        if (hiringMethod !== 'Title 5') {
            CDCCommon.showField('CAP_HR_POS_NUM', true);
            CDCCommon.showField('JOB_CODE', true);
            CDCCommon.showField('WORK_AUTHORIZATION_STATUS', true);
            CDCCommon.showField('WORK_AUTHORIZATION_DECISION_DATE', true);

            $('#ATC_SIGN_OFF_REQ_2').empty().append('<option value="Yes">Yes</Option>');
            FormState.doAction(StateAction.changeText('ATC_SIGN_OFF_REQ_2', 'Yes'), false);
            $('#pv_atcSignOffReq2').val('Yes');
            CDCCommon.hideField('SECURITY_DECISION_DATE', true);
            CDCCommon.hideField('ETHICS_DECISION_DATE', true);
            CDCCommon.hideField('WORK_AUTHORIZATION_DECISION_DATE', true);
        } else {
            CDCCommon.hideField('CAP_HR_POS_NUM', true);
            CDCCommon.hideField('JOB_CODE', true);
            CDCCommon.hideField('WORK_AUTHORIZATION_STATUS', true);
            CDCCommon.hideField('WORK_AUTHORIZATION_DECISION_DATE', true);
            CDCCommon.hideField('SECURITY_DECISION_DATE', true);
            CDCCommon.hideField('ETHICS_DECISION_DATE', true);
        }

        CDCCommon.setupFirstLoad(self.initSetupDone, self.fields);

        var nextApprover = FormState.getState('ATC_SIGN_OFF_REQ_2');
        if (!nextApprover || nextApprover.value !== 'Yes') {
            CDCCommon.hideField('ATC_APPROVER_2', true);
            CDCCommon.hideField('ATC_APPROVER_EMAIL_2', true);
        }

    },
    hideHRStaffingGroup: function(group) {
        switch (group) {
            case "HR_PROCESSOR":
                //HIDE HR PROCESSOR
                $('#HR_PROCESSOR_ACKNOWLEDGE').addClass('hidden');
                $('#HR_PROCESSOR_CUSTOM').addClass('hidden');
                CDCCommon.hideField('HR_PROCESSOR_APPROVAL', true);
                CDCCommon.hideField('HR_PROCESSOR_DATE', true);
                break;
            case "HR_STAFFING":
                //HIDE HR STAFFING
                $('#HR_STAFFING_ACKNOWLEDGE').addClass('hidden');
                $('#HR_STAFFING_CUSTOM').addClass('hidden');
                CDCCommon.hideField('HR_STAFFING_APPROVAL', true);
                CDCCommon.hideField('HR_STAFFING_DATE', true);
                CDCCommon.hideField('ATC_SIGN_OFF_REQ_2', true);
                CDCCommon.hideField('ATC_APPROVER_2', true);
                CDCCommon.hideField('ATC_APPROVER_EMAIL_2', true);
                break;
            case "HR_SENIOR_STAFFING":
                //HIDE HR SENIOR STAFFING
                $('#HR_SENIOR_STAFFING_ACKNOWLEDGE').addClass('hidden');
                $('#HR_SENIOR_STAFFING_CUSTOM').addClass('hidden');
                CDCCommon.hideField('HR_SENIOR_STAFFING_APPROVAL', true);
                CDCCommon.hideField('HR_SENIOR_STAFFING_DATE', true);
                break;
        }
    },
    postDisableTab: function() {
        var curActivity = $('#curActivity').val();

        if (curActivity === 'Provide Second ATC Approval') {
            var hasProcessor = $('#HR_PROCESSOR_DATE').val();
            if (hasProcessor.length > 0) {
                $('#HR_STAFFING_ACKNOWLEDGE').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');
                $('#ATC_SIGN_OFF_REQ_2').removeClass('disabled').attr('disabled', false).parent().removeClass('isDisabled');
                $('#ATC_APPROVER_2').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');
            } else {
                $('#HR_SENIOR_STAFFING_ACKNOWLEDGE').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');
            }
        }
        if (curActivity === 'Provide Third ATC Approval') {
            $('#HR_SENIOR_STAFFING_ACKNOWLEDGE').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');
        }
    },
    //**Function to get Hiring Method: Potential Output's Title 5, Title 42, SES/SL/ST */
    getHiringMethod: function(fieldState) {
        var self = this;
        var hiringMethod = '';
        if (!fieldState) {
            fieldState = FormState.getState('HM_ID');
        }
        if (fieldState && fieldState.value) {
            if (fieldState.value.indexOf('Title 5') === 0) {
                hiringMethod = 'Title 5';
            } else if (fieldState.value.indexOf('Title 42') === 0) {
                hiringMethod = 'Title 42';
            } else if (fieldState.value.indexOf('SES/SL/ST') === 0) {
                hiringMethod = 'SES/SL/ST';
            }
        }
        return hiringMethod;
    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        CDCCommon.setAutoComplete('HR_STAFFING_GRD', this.mappers, this.reduxBindFix);
        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });
    },
    mappers: {

        ATC_APPROVER_2: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        }
    },
    reduxBindFix: function() {
        if (!$(this).data('autocomplete')) {
            FormState.doAction(StateAction.changeText($(this).attr('id'), $(this).val()), false);
        }
    }

}