/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var p2wVld = {
    //**Variable to Store CurrentActivity */
    currentActivity: "",
    //**Flag indicating whether initialization is done or not; needed for renderer function, otherwise it calls init section all the time */
    initSetupDone: false,
    //**Check Field for First Load check */
    checkField: {
        name: 'valInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
        { name: 'PRE_RECRUIT_MTG_DATE', value: '' },
        { name: 'PRE_RECRUIT_MTG_DATE_STR', value: '' },
        { name: 'PRE_PPP_PCP_CLEARED', value: '' },
        { name: 'PRE_PPP_PCP_DT_CLEARED', value: '' },
        { name: 'PRE_PPP_PCP_JUST_RSN', value: '' }
    ],

    resetPPPPCP: function(initSetupDone, currentActivity) {
        var hmId = (FormState.getState('HM_ID')).value || "";
        if (hmId !== 'Title 42' && (currentActivity === 'Validate Recruitment' || currentActivity === 'Track USA Staffing Status')) {
            var pppPcpCleared = FormState.getState('PRE_PPP_PCP_CLEARED');
            if (pppPcpCleared && (!initSetupDone || pppPcpCleared.dirty)) {
                if (pppPcpCleared.value === 'No') {
                    CDCCommon.showField('PRE_PPP_PCP_JUST_RSN', true);
                    CDCCommon.hideField('PRE_PPP_PCP_DT_CLEARED', true, '');
                } else if (pppPcpCleared.value === 'Yes'){
                    CDCCommon.showField('PRE_PPP_PCP_DT_CLEARED', true);
                    CDCCommon.hideField('PRE_PPP_PCP_JUST_RSN', true, '');
                } else{
                    CDCCommon.hideField('PRE_PPP_PCP_DT_CLEARED', true, '');                 
                    CDCCommon.hideField('PRE_PPP_PCP_JUST_RSN', true, '');                 
                }
            }
        } else if (!initSetupDone) {
            CDCCommon.hideField('PRE_PPP_PCP_CLEARED', true, '');
            CDCCommon.hideField('PRE_PPP_PCP_DT_CLEARED', true, '');
            CDCCommon.hideField('PRE_PPP_PCP_JUST_RSN', true, '');
        }
    },

    renderer: function() {
        console.log("p2wValidation renderer Start");
        var self = this;
        CDCCommon.setupFirstLoad(self.checkField, self.fields);
        if (!self.initSetupDone) {
            self.currentActivity = BFActivityOption.getActivityName();
        }
        var mtgDateFormState = FormState.getState('PRE_RECRUIT_MTG_DATE');
        if (mtgDateFormState && mtgDateFormState.dirty) {
            FormState.doAction(StateAction.changeText('PRE_RECRUIT_MTG_DATE_STR', mtgDateFormState.value), false);
        }
        self.resetPPPPCP(self.initSetupDone, self.currentActivity);
        self.initSetupDone = true;
        console.log("p2wValidation renderer End");
    },

    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {}
}