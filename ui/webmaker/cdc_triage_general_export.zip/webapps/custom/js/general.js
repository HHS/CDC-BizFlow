/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var triageGen = {
    initSetupDone: false,
    lookup_paractions: [
        {"HM_ID": "Title 5", "PARActions":["Promotion", "Promotion NTE", "Change to Lower Grade", "Extension", "Reassignment"]},
        {"HM_ID": "Title 42", "PARActions":["Conversion", "Conversion NTE" , "Stipend Increase" , "Extension" , "Reassignment"]},
        {"HM_ID": "SES/SL/ST", "PARActions":["Conversion", "Conversion NTE" , "Stipend Increase" , "Extension" , "Reassignment"]}
    ],
    checkField: {
        name: 'genInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
    ],
    renderer: function() {
        console.log('triageGen renderer Start');
        var self = this;
        CDCCommon.setupFirstLoad(self.checkField, self.fields);
        if (!self.initSetupDone) {
            self.initSetup();
        }
        self.initSetupDone = true;
        self.actionOnChange("TRIAGE_TP");
        self.actionOnChange("HR_ACTION_TYPE_1");
        self.actionOnChange("HR_ACTION_TYPE_2");
        self.actionOnChange("HR_ACTION_TYPE_3");
        self.actionOnChange("PAR_ACTION_2");
        self.actionOnChange("PAR_ACTION_3");
        self.actionOnChange("HM_ID_1");
        self.actionOnChange("HM_ID_2");
        self.actionOnChange("HM_ID_3");
        self.actionOnChange("ADMIN_CD");
        self.actionOnChange("POS_CAN");
        self.actionOnChange("EMPL_ID");
        self.actionOnChange("EMPL_NAME");
        self.actionOnChange("POS_JOB_REQ_NUM");
        self.actionOnChange("ATC_NOAC");
        self.actionOnChange("ORG_NAME");
        self.actionOnChange("CAPHR_REMARKS");
        self.actionOnChange("REQUEST_TYPE");
        self.actionOnChange("PROPOSED_EFFECTIVE_DATE");
        self.actionOnChange("PAR_ACTION_TYPE_2");
        self.actionOnChange("PAR_ACTION_TYPE_3");
        self.actionOnChange("TR_PRE_CONSUL_REQD");
        console.log('triageGen renderer End');
    },
    actionOnChange: function(field) {
        //TODO:copy field value to pvFields
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        
        if( fieldState && fieldState.dirty ){
            console.log("[SET-PV] " + field + "=" + fieldState.value);
            switch (field) {
                case "TRIAGE_TP":
                    var initiationType = $("#pv_initiationType").val();

                    $("#lg_trtype_JR").addClass("hide");
                    $("#lg_trtype_PAR").addClass("hide");
                    $("#lg_NamedActionInfoContainer").addClass("hide");

                    if ("JR" == fieldState.value) {
                        $("#lg_trtype_JR").removeClass("hide");
                    } else if ("PAR" == fieldState.value) {
                        $("#lg_trtype_PAR").removeClass("hide");
                        $("#lg_NamedActionInfoContainer").removeClass("hide");
                        $("#pv_hrActionType").val("Named Action"); //Please note. This is a code to set a PV, because there is only one item in the dropdown. no change event occurs.
                        $("#HR_ACTION_TYPE").val("Named Action");
                    } else {

                    }
                    self.enableFieldsForManualIniitation(initiationType, fieldState.value);

                    $("#pv_triageType").val(fieldState.value); //update a mapping PV field

                    break;
                case "HR_ACTION_TYPE_1":
                    if ("Recruitment" == fieldState.value) {
                        hyf.util.showComponent("lg_ActionType_1", false, null, null);
                        hyf.util.hideComponent("lg_ActionType_2", false, null, null);
                        hyf.util.hideComponent("lg_IsPreConsultationRequired", false, null, null);
                        $("#pv_preConsultReq").val("");
                        FormState.doAction(StateAction.changeSelect('TR_PRE_CONSUL_REQD', "", ""), false);
                        FormState.doAction(StateAction.changeDate('TR_PRE_CONSUL_MTG_DATE', ""), false);
                        self.actionOnChange("TR_PRE_CONSUL_REQD");
                    } else if ("Named Action" == fieldState.value) {
                        hyf.util.hideComponent("lg_ActionType_1", false, null, null);
                        hyf.util.showComponent("lg_ActionType_2", false, null, null);
                        hyf.util.showComponent("lg_IsPreConsultationRequired", false, null, null);
                   }

                    $("#pv_hrActionType").val(fieldState.value); //update a mapping PV field
                    self.setTextFieldValueByScript('HR_ACTION_TYPE', fieldState.value, false);
                    break;
                case "HR_ACTION_TYPE_2":
                    $("#pv_hrActionType").val(fieldState.value); //update a mapping PV field
                    self.setTextFieldValueByScript('HR_ACTION_TYPE', fieldState.value, false);
                    break;
                case "HR_ACTION_TYPE_3":
                    $("#pv_hrActionType").val(fieldState.value); //update a mapping PV field
                    self.setTextFieldValueByScript('HR_ACTION_TYPE', fieldState.value, false);
                    break;
                case "PAR_ACTION_2":
                case "PAR_ACTION_3":
                    $("#pv_parAction").val(fieldState.value); //update a mapping PV field
                    self.setTextFieldValueByScript('PAR_ACTION', fieldState.value, false);
                    break;
                case "HM_ID_1":
                    $("#pv_hiringMethod").val(fieldState.value); //update a mapping PV field
                    self.setTextFieldValueByScript('HM_ID', fieldState.value, false);
                    break;
                case "HM_ID_2":
                    var parActions = triageGen.getPARActionsByHiringMethod(fieldState.value);
                    triageGen.populatePARActions("PAR_ACTION_TYPE_2", parActions);
                    if ("" == fieldState.value) {
                        hyf.util.disableComponent("PAR_ACTION_TYPE_2");
                        $("#PAR_ACTION_TYPE_2").addClass("triageFieldReadonly");
                    } else {
                        hyf.util.enableComponent("PAR_ACTION_TYPE_2");
                        $("#PAR_ACTION_TYPE_2").removeClass("triageFieldReadonly");
                    }
                    $("#pv_hiringMethod").val(fieldState.value); //update a mapping PV field
                    self.setTextFieldValueByScript('HM_ID', fieldState.value, false);
                    break;
                case "HM_ID_3":
                    var parActions = triageGen.getPARActionsByHiringMethod(fieldState.value);
                    triageGen.populatePARActions("PAR_ACTION_TYPE_3", parActions);
                    if ("" == fieldState.value) {
                        hyf.util.disableComponent("PAR_ACTION_TYPE_3");
                        $("#PAR_ACTION_TYPE_3").addClass("triageFieldReadonly");
                    } else {
                        hyf.util.enableComponent("PAR_ACTION_TYPE_3");
                        $("#PAR_ACTION_TYPE_3").removeClass("triageFieldReadonly");
                    }
                    $("#pv_hiringMethod").val(fieldState.value); //update a mapping PV field
                    self.setTextFieldValueByScript('HM_ID', fieldState.value, false);
                    break;
                case "PAR_ACTION_TYPE_2":
                case "PAR_ACTION_TYPE_3":
                    $("#pv_parActionType").val(fieldState.value); //update a mapping PV field
                    self.setTextFieldValueByScript('PAR_ACTION_TYPE', fieldState.value, false);
                    break;
                case "ADMIN_CD":
                    $("#pv_adminCode").val(fieldState.value); //update a mapping PV field
                    break;
                case "POS_CAN":
                    $("#pv_can").val(fieldState.value); //update a mapping PV field
                    break;
                case "EMPL_ID":
                    $("#pv_empId").val(fieldState.value); //update a mapping PV field
                    break;
                case "EMPL_NAME":
                    $("#pv_empName").val(fieldState.value); //update a mapping PV field
                    break;
                case "POS_JOB_REQ_NUM":
                    $("#pv_jobRequestNumber").val(fieldState.value); //update a mapping PV field
                    break;
                case "ATC_NOAC":
                    $("#pv_noac").val(fieldState.value); //update a mapping PV field
                    break;
                case "ORG_NAME":
                    $("#pv_orgName").val(fieldState.value); //update a mapping PV field
                    break;
                case "CAPHR_REMARKS":
                    $("#pv_remarks").val(fieldState.value); //update a mapping PV field
                    break;
                case "REQUEST_TYPE":
                    $("#pv_requestType").val(fieldState.value); //update a mapping PV field
                    break;
                case "PROPOSED_EFFECTIVE_DATE":
                    var dateParts = fieldState.value.split('/');
                    if (dateParts.length >= 3) {
                        var dateString = dateParts[2] + '/' + dateParts[0] + '/' + dateParts[1] + ' 12:00:00';
                        $("#pv_propEffectiveDate").val(dateString); //update a mapping PV field
                    } else {
                        $("#pv_propEffectiveDate").val("");
                    }
                    break;
                case "TR_PRE_CONSUL_REQD":
                    var preConsultRequired = fieldState.value;
                    var pv_isPreConsultEmailSent = $("#pv_isPreConsultEmailSent").val();
                    if ("Yes" != pv_isPreConsultEmailSent) { //Before loop back
                        if ("Yes" === preConsultRequired) {
                            hyf.util.disableComponent('button_Submit1');
                            hyf.util.enableComponent('button_SendEmailForPreConsultation');
                        } else {
                            hyf.util.enableComponent('button_Submit1');
                            hyf.util.disableComponent('button_SendEmailForPreConsultation');
                        }
                        hyf.util.hideComponent("lg_PreConsultationMeetingDate", false, null, null);

                    } else { //after loop back
                        hyf.util.enableComponent('button_Submit1');
                        hyf.util.disableComponent('button_SendEmailForPreConsultation');

                        if ("Yes" === preConsultRequired) {
                            hyf.util.showComponent("lg_PreConsultationMeetingDate", false, null, null);
                        } else {
                            hyf.util.hideComponent("lg_PreConsultationMeetingDate", false, null, null);
                            $('#TR_PRE_CONSUL_MTG_DATE').val("");
                        }

                    }
                    break;
            } // end switch
	       } // end fieldState conditions check
    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        var self = this;

        CDCCommon.setAutoComplete('group_general', this.mappers, this.reduxBindFix);
        $(document).on("click change keyup keypress keydown",".textbox.autoExpandTextarea",function() {
            CDCCommon.addCurrTextlengthStatus($(document.activeElement)); 
        });
                          
        $(document).on("focusout",".textbox.autoExpandTextarea",function() {
            CDCCommon.removeCurrTextlengthStatus();
        });

        var initiationType = $("#pv_initiationType").val();
        if ('ERA' != initiationType) {
            hyf.util.enableComponent("CAPHR_REMARKS");
            $("#CAPHR_REMARKS").removeClass("triageFieldReadonly");
        }

        var pv_isPreConsultEmailSent = $("#pv_isPreConsultEmailSent").val();
        var pv_preConsultRequired = $("#pv_preConsultRequired").val();
        if ("Yes" === pv_isPreConsultEmailSent) {
            hyf.util.showComponent("lg_PreConsultationMeetingDate", false, null, null);
        } else {
            if ("Yes" === pv_preConsultRequired) {
                hyf.util.showComponent("lg_PreConsultationMeetingDate", false, null, null);
            } else {
                hyf.util.hideComponent("lg_PreConsultationMeetingDate", false, null, null);
                $('#TR_PRE_CONSUL_MTG_DATE').val("");
            }
        }

        hyf.util.hideComponent("lg_PreConsultationMeetingDate", false, null, null);

    },
    mappers: {
        ADMIN_CD: function() {
            return {
                AC_ADMIN_CD: $("AC_ADMIN_CD", this).text(),
                AC_ADMIN_CD_DESCR: $('AC_ADMIN_CD_DESCR', this).text()
            }
        },
        ORG_NAME: function() {
            return {
                AC_ADMIN_CD: $("AC_ADMIN_CD", this).text(),
                AC_ADMIN_CD_DESCR: $('AC_ADMIN_CD_DESCR', this).text()
            }
        },
        SO_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $("PVMID", this).text()
            }
        },
        CIO_AutoComplete: function() {
                return {
                    MID: $("MID", this).text(),
                    DSPNAME: $('DSPNAME', this).text(),
                    DEPTNAME: $('DEPTNAME', this).text(),
                    EMAIL: $('EMAIL', this).text(),
                    PVMID: $("PVMID", this).text()                
                }
        },
        HROS_AutoComplete: function() {
                return {
                    MID: $("MID", this).text(),
                    DSPNAME: $('DSPNAME', this).text(),
                    DEPTNAME: $('DEPTNAME', this).text(),
                    EMAIL: $('EMAIL', this).text(),
                    PVMID: $("PVMID", this).text()
                }
        },
        CLASS_SPEC_AutoComplete: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $("PVMID", this).text()
            }
        },
        ATC_NOAC: function() {
            return {
                NOA_CODE: $('NOA_CODE', this).text() + '-' + $('NOA_SUFFIX_CD', this).text(),
                NOA_DESC: $('NOA_DESC', this).text()
            };
        }
    },
    reduxBindFix: function() {
        if (!$(this).data('autocomplete')) {
            FormState.doAction(StateAction.changeText($(this).attr('id'), $(this).val()), false);
        }
    },
    getPARActionsByHiringMethod: function(hiringMethod) {
        var parActions=[];
        for (var i=0; i<triageGen.lookup_paractions.length; i++) {
            if (triageGen.lookup_paractions[i].HM_ID == hiringMethod) {
                parActions = triageGen.lookup_paractions[i].PARActions;
                console.log("getPARActionsByHiringMethod=" + parActions);
                break;
            }
        }
        return parActions;
    },
    populatePARActions: function(fieldID, parActions) {
        console.log("populatePARActions...");
        var $select = $("#" + fieldID); // you might wanna empty it first with .empty()
        $select.empty();
        var o = $('<option/>', { value: ""}).text("Select One").prop('selected', true);
        o.appendTo($select);
        for (i=0; i<parActions.length; i++) {
            console.log("i=" + i);
            o = $('<option/>', {value: parActions[i]}).text(parActions[i]).prop('selected', false);
            o.appendTo($select);
        }
    },
    selectOptionByValue: function(fieldID, value) {
        $("#" + fieldID + " > option").each(function() {
            this.prop('selected', true);
        });
    },
    enableFieldsForManualIniitation: function(initiationType, triageType) {

        if ("ERA" == initiationType) {
            $("#lg_triageTypeSelectionContainer").addClass("hide");
            if ("JR" == triageType) {
                hyf.util.disableComponent("POS_JOB_REQ_NUM");
                $("#POS_JOB_REQ_NUM").addClass("triageFieldReadonly");
                hyf.util.disableComponent("ADMIN_CD");
                $("#ADMIN_CD").addClass("triageFieldReadonly");
                hyf.util.disableComponent("POS_CAN");
                $("#POS_CAN").addClass("triageFieldReadonly");
                hyf.util.disableComponent("CAPHR_REMARKS");
                $("#CAPHR_REMARKS").addClass("triageFieldReadonly");
            } else if ("PAR" == triageType) {
                hyf.util.disableComponent("EMPL_ID");
                $("#EMPL_ID").addClass("triageFieldReadonly");
                hyf.util.disableComponent("EMPL_NAME");
                $("#EMPL_NAME").addClass("triageFieldReadonly");
                hyf.util.disableComponent("ATC_NOAC");
                $("#ATC_NOAC").addClass("triageFieldReadonly");
            }
        } else {
            $("#lg_triageTypeSelectionContainer").removeClass("hide");
            if ("" == triageType) {
                $("#lg_trtype_JR").addClass("hide");
                $("#lg_trtype_PAR").addClass("hide");
                $("#lg_NamedActionInfoContainer").addClass("hide");
            }
        }
        hyf.util.disableComponent("ORG_NAME");
        $("#ORG_NAME").addClass("triageFieldReadonly");

    },
    postEnableTab: function() {

    },
    postDisableTab: function(readonlyForm) {
    },
    onTabLoaded: function() {
        //When the tab is fully loaded with FormState
        var self = this;
        var triageType = $("#pv_triageType").val();
        var initiationType = $("#pv_initiationType").val();
        self.enableFieldsForManualIniitation(initiationType, triageType);
        //self.actionOnChange('TRIAGE_TP');
        self.actionOnChange('HR_ACTION_TYPE_1');
        //self.actionOnChange('HM_ID_2');
        //self.actionOnChange('HM_ID_3');
        //self.actionOnChange('HR_ACTION_TYPE_3');
    },
    initSetup: function() {
        //Set initial field value from PV or lookup
        var triageType = $("#pv_triageType").val();
        var empID = $("#pv_empId").val();
        var empName = $("#pv_empName").val();
        var jrNo = $("#pv_jobRequestNumber").val();
        var adminCode = $("#pv_adminCode").val();
        var orgName = $("#pv_orgName").val();
        var parAction = $("#pv_parAction").val();
        var can = $("#pv_can").val();
        var noac = $("#pv_noac").val();
        var firstAuth = $("#pv_firstAuth").val();
        var secondAuth = $("#pv_secondAuth").val();
        var propEffectiveDate = $("#pv_propEffectiveDate").val();
        var propEffectiveDateParts = {};
        if (propEffectiveDate != null) {
            var dateDelimeter = "/";
            if (propEffectiveDate.indexOf("-") >= 0) {
                dateDelimeter = "-";
            }
            propEffectiveDateParts = propEffectiveDate.substring(0,10).split(dateDelimeter);
            if (propEffectiveDateParts.length >= 3) {
                propEffectiveDate = propEffectiveDateParts[1] + "/" + propEffectiveDateParts[2] + "/" + propEffectiveDateParts[0];
            }
        }
        var remarks = $("#pv_remarks").val();

        var pv_hroSpecialist = $("#pv_hroSpecialist").val();
        pv_hroSpecialist = pv_hroSpecialist.replace("[U]", "");
        if (pv_hroSpecialist != null && pv_hroSpecialist != "") {
            triageMain.searchBizFlowMember("HROS_AutoComplete", "HROS_EMAIL", pv_hroSpecialist);
        }

        var pv_cioAdminPOC = $("#pv_cioAdminPOC").val();
        pv_cioAdminPOC = pv_cioAdminPOC.replace("[U]", "");
        if (pv_cioAdminPOC != null && pv_cioAdminPOC != "") {
            triageMain.searchBizFlowMember("CIO_AutoComplete", "CIO_EMAIL", pv_cioAdminPOC);
        }

        var pv_selectOfficial = $("#pv_selectOfficial").val();
        pv_selectOfficial = pv_selectOfficial.replace("[U]", "");
        if (pv_selectOfficial != null && pv_selectOfficial != "") {
            triageMain.searchBizFlowMember("SO_AutoComplete", "SO_EMAIL", pv_selectOfficial);
        }

        var pv_classSpecialist = $("#pv_classSpecialist").val();
        pv_classSpecialist = pv_classSpecialist.replace("[U]", "");
        if (pv_classSpecialist != null && pv_classSpecialist != "") {
            triageMain.searchBizFlowMember("CLASS_SPEC_AutoComplete", "CLASS_SPEC_EMAIL", pv_classSpecialist);
        }

        FormState.doAction(StateAction.changeSelect('TRIAGE_TP', triageType, triageType), false);
        FormState.doAction(StateAction.changeSelect('PAR_ACTION_2', parAction, parAction), false);
        FormState.doAction(StateAction.changeSelect('PAR_ACTION_3', parAction, parAction), false);
        FormState.doAction(StateAction.changeText('EMPL_ID', empID), false);
        FormState.doAction(StateAction.changeText('EMPL_NAME', empName), false);
        FormState.doAction(StateAction.changeText('POS_JOB_REQ_NUM', jrNo), false);
        FormState.doAction(StateAction.changeText('ADMIN_CD', adminCode), false);
        FormState.doAction(StateAction.changeText('ORG_NAME', orgName), false);
        FormState.doAction(StateAction.changeText('POS_CAN', can), false);
        FormState.doAction(StateAction.changeText('ATC_NOAC', noac), false);
        FormState.doAction(StateAction.changeText('ATC_AUTHORITY', firstAuth), false);
        FormState.doAction(StateAction.changeText('ATC_SECOND_AUTHORITY', secondAuth), false);
        FormState.doAction(StateAction.changeText('CAPHR_REMARKS', remarks), false);
        FormState.doAction(StateAction.changeDate('PROPOSED_EFFECTIVE_DATE', propEffectiveDate), false);

    }
    ,setTextFieldValueByScript: function(fieldId, fieldValue, fireRendererEvent) {
        $("#" + fieldId).val(fieldValue);
        FormState.doAction(StateAction.changeText(fieldId, fieldValue), fireRendererEvent);
    }
}