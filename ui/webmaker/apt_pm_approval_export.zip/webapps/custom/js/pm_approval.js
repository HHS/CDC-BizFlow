/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var aptPMApp = {
    initSetupDone: false,
    //**Default values for First Load Fields */
    fields: [
        { name: 'POSITION_BUILD_APPROVAL', firstValue: true },
        { name: 'OF8_APPROVAL', firstValue: true },
        { name: 'CAPHR_POS_NUM_APPROVAL', value: "" },
        { name: 'JOB_CODE_APPROVAL', value: "" },
        { name: 'PM_STEWARD_APPROVAL', value: "" },
        { name: 'PM_BUS_APPROVAL', value: false },
        { name: 'PM_SUP_STAT_APPROVAL', value: false },
        { name: 'PM_FLSA_APPROVAL', value: false },
        { name: 'PM_ADMIN_CODE_APPROVAL', value: false },
        { name: 'PM_STEWARD_NAME_APPROVAL', value: "" },
        { name: 'PM_STEWARD_DATE_APPROVAL', value: "" }

    ],
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        if (fieldState && fieldState.dirty) {
            switch (field) {
                case 'POSITION_BUILD_APPROVAL':
                case 'OF8_APPROVAL':
                case 'PM_BUS_APPROVAL':
                case 'PM_SUP_STAT_APPROVAL':
                case 'PM_FLSA_APPROVAL':
                case 'PM_ADMIN_CODE_APPROVAL':
                case 'PM_STEWARD_APPROVAL':
                case 'CAPHR_POS_NUM_APPROVAL':
                case 'JOB_CODE_APPROVAL':
                    var PMAppDate = new Date();
                    var CK_POSITION_BUILD_APPROVAL = (FormState.getState('POSITION_BUILD_APPROVAL') !== undefined) ? FormState.getState('POSITION_BUILD_APPROVAL').value : false;
                    var CK_OF8_APPROVAL = (FormState.getState('OF8_APPROVAL') !== undefined) ? FormState.getState('OF8_APPROVAL').value : false;
                    var CK_PM_BUS_APPROVAL = (FormState.getState('PM_BUS_APPROVAL') !== undefined) ? FormState.getState('PM_BUS_APPROVAL').value : false;
                    var CK_PM_SUP_STAT_APPROVAL = (FormState.getState('PM_SUP_STAT_APPROVAL') !== undefined) ? FormState.getState('PM_SUP_STAT_APPROVAL').value : false;
                    var CK_PM_FLSA_APPROVAL = (FormState.getState('PM_FLSA_APPROVAL') !== undefined) ? FormState.getState('PM_FLSA_APPROVAL').value : false;
                    var CK_PM_ADMIN_CODE_APPROVAL = (FormState.getState('PM_ADMIN_CODE_APPROVAL') !== undefined) ? FormState.getState('PM_ADMIN_CODE_APPROVAL').value : false;
                    var CK_PM_STEWARD_APPROVAL = (FormState.getState('PM_STEWARD_APPROVAL') !== undefined) ? FormState.getState('PM_STEWARD_APPROVAL').value : false;
                    var CK_CAPHR_JOB_CODE = true;

                    var fldStateCapHR = FormState.getState('CAPHR_POS_NUM_APPROVAL');
                    var fldStateJobCode = FormState.getState('JOB_CODE_APPROVAL');

                    CK_CAPHR_JOB_CODE = fldStateCapHR && fldStateCapHR.value && fldStateJobCode && fldStateJobCode.value;


                    if (CK_POSITION_BUILD_APPROVAL && CK_OF8_APPROVAL && CK_PM_BUS_APPROVAL && CK_PM_SUP_STAT_APPROVAL && CK_PM_FLSA_APPROVAL && CK_PM_ADMIN_CODE_APPROVAL && CK_PM_STEWARD_APPROVAL && CK_CAPHR_JOB_CODE) {
                        FormState.doAction(StateAction.changeText('PM_STEWARD_NAME_APPROVAL', $('#current_user_name').val() + "/" + $('#current_user_title').val()), false);
                        FormState.doAction(StateAction.changeText('PM_STEWARD_DATE_APPROVAL', ('0' + (PMAppDate.getMonth() + 1)).slice(-2) + '/' + ('0' + PMAppDate.getDate()).slice(-2) + '/' + PMAppDate.getFullYear()), false);

                    } else {
                        FormState.doAction(StateAction.changeText('PM_STEWARD_NAME_APPROVAL', ''), false);
                        FormState.doAction(StateAction.changeText('PM_STEWARD_DATE_APPROVAL', ''), false);
                    }

                    break;
            }
        }
    },
    renderer: function() {
        var self = this;

        self.actionOnChange('POSITION_BUILD_APPROVAL');
        self.actionOnChange('OF8_APPROVAL');
        self.actionOnChange('PM_BUS_APPROVAL');
        self.actionOnChange('PM_SUP_STAT_APPROVAL');
        self.actionOnChange('PM_FLSA_APPROVAL');
        self.actionOnChange('PM_ADMIN_CODE_APPROVAL');
        self.actionOnChange('PM_STEWARD_APPROVAL');
        self.actionOnChange('CAPHR_POS_NUM_APPROVAL');
        self.actionOnChange('JOB_CODE_APPROVAL');



        if (!self.initSetupDone) {
            self.initSetupDone = true;
        }

    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {

    }
}