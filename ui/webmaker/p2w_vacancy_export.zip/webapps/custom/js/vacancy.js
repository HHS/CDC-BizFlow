/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var p2wVac = {
    checkField: {
        name: 'vacInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
        { name: 'FIELD_ID', value: "" }
    ],
    vacancies: {},
    certificates: {},
    applicants: {},
    renderer: function() {
        var self = this;
        self.actionOnChange('VIN');
        self.actionOnChange('CERT_NUM');

    },
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        if (fieldState && fieldState.dirty) {
            switch (field) {
                case "VIN":
                    if (fieldState.value !== '') {
                        self.setVINDisplay(fieldState.value);
                    } else {
                        self.clearPage()
                    }
                    break;
                case "CERT_NUM":
                    if (fieldState.value !== '') {
                        self.setCERTDisplay(fieldState.value);
                    } else {
                        self.clearCertData();
                    }
                    break;
            }
        }
    },
    setVacancyData: function() {
        var self = this;
        var getVacancyData = $.ajax({
            dataType: 'xml',
            method: 'GET',
            url: '/bizflowwebmaker/cdc_api/USAStaffing.do',
            cache: 'false'
        }).done(
            function(xml) {

                var vancancyData = $(xml).find('VacancyInfo');
                var certificateData = $(xml).find('CertificateInfo');
                var applicantData = $(xml).find('ApplicantInfo');

                var vacancyInfo = $(vancancyData).map(function() {
                    return {
                        VIN: $('Vacancy_Number', this).text(),
                        VAN: $('Announcement_Number', this).text(),
                        CERT_ANN_TYPE: $('Announcement_Type', this).text(),
                        CERTIFICATES: $('record', this).map(function() {
                            return $('Certificate_Number', this).text();
                        }),
                        VACANCY_STATUS: $('Vacancy_Status', this).text(),
                        TOT_NUM_APP: $('Vacancy_Total_Applicants', this).text(),
                        TOT_QUAL_APP: $('Vacancy_Total_Eligible_Applicants', this).text(),
                        TOT_REF_APP: $('Vacancy_Total_Referred_Applicants', this).text(),
                        APP_NOTIFY_DATE: $('Date_Applicants_Notified_Of_Referred_Status', this).text()

                    }
                });
                var certificateInfo = $(certificateData).map(function() {
                    return [
                        $('record', this).map(function() {
                            return {
                                VIN: $('Vacancy_Number', this).text(),
                                VAN: $('Announcement_Number', this).text(),
                                CERT_NUM: $('Certificate_Number', this).text(),
                                CERT_TYPE: $('Certificate_Type', this).text(),
                                CERT_AUDIT: $('Certificate_Audit_Complete', this).text(),
                                CERT_ISSUED: $('Date_Certificate_Issued', this).text(),
                                CERT_SENT_SO: $('Date_Certificate_Sent_To_SO', this).text(),
                                CERT_DUE: $('Date_Certificate_Due', this).text(),
                                POS_TITLE: $('Position_Title', this).text(),
                                PAY_SERIES_GRADE: $('Pay_Plan_Series_Grade', this).text()
                            }
                        })
                    ];
                });

                var applicantInfo = $(applicantData).map(function() {
                    return [
                        $('record', this).map(function() {
                            return {
                                VIN: $('Vacancy_Number', this).text(),
                                VAN: $('Announcement_Number', this).text(),
                                CERT_NUM: $('Certificate_Number', this).text(),
                                APPLICANTS: $('record', this).map(function() {
                                    return {
                                        APPLICANT_NAME: $('Applicant_Name', this).text(),
                                        AUDIT_CODE: $('Audit_Code', this).text(),
                                        SELECTEE_REQ_NUM: $('Selectee_Request_Number', this).text()

                                    }
                                })
                            }
                        })
                    ];
                });

                self.setVacancies(vacancyInfo);
                self.setCertificates(certificateInfo);
                self.setApplicants(applicantInfo);

            });
    },
    formatDisplayDate: function(dateStr) {
        var rtn = (dateStr) ? $.datepicker.formatDate('mm/dd/yy', new Date(dateStr)) : dateStr;
        return rtn;
    },
    setCertificates: function(data) {
        var self = this;
        self.certificates = data;
    },
    setApplicants: function(data) {
        var self = this;
        self.applicants = data;
    },
    setVacancies: function(data) {
        var self = this;
        self.vacancies = data;
        var $VIN = $('#VIN');
        $VIN.empty();
        for (var i = 0; i < self.vacancies.length; i++) {
            $VIN.append('<option value="' + self.vacancies[i].VIN + '" data-position="' + i + '">' + self.vacancies[i].VIN + '</option>');
        };

        if ($VIN.children().size() > 1) {
            $VIN.append('<option value="" selected>Select One</option>');
            $VIN.on('change', function() {
                self.setVINDisplay()
            });
        }

        // self.setVINDisplay();
    },
    setVINDisplay: function(vin) {
        var self = this;
        var $VIN = $('#VIN');
        var $CERT_NUM = $('#CERT_NUM');
        var pos = $('#VIN :selected').data('position');
        var vacancy = null;
        if (typeof pos !== "undefined" && pos != null) {
            vacancy = self.vacancies[pos];
        }

        if (typeof vacancy !== "undefined" && vacancy != null) {
            $('#VAN').val(vacancy.VAN);
            $('#CERT_ANN_TYPE').val(vacancy.CERT_ANN_TYPE);
            $('#VACANCY_STATUS').val(vacancy.VACANCY_STATUS);
            $('#TOT_NUM_APP').val(vacancy.TOT_NUM_APP);
            $('#TOT_QUAL_APP').val(vacancy.TOT_QUAL_APP);
            $('#TOT_REF_APP').val(vacancy.TOT_REF_APP);
            $('#APP_NOTIFIED_DATE').val(self.formatDisplayDate(vacancy.APP_NOTIFY_DATE));

            $CERT_NUM.empty();
            self.clearCertData();
            for (var i = 0; i < vacancy.CERTIFICATES.length; i++) {
                $CERT_NUM.append('<option value="' + vacancy.CERTIFICATES[i] + '" data-position="' + pos + '" data-cert="' + i + '">' + vacancy.CERTIFICATES[i] + '</option>');
            }

            if ($CERT_NUM.children().length > 1) {
                $CERT_NUM.append('<option value="" selected>Select One</option>');
                $CERT_NUM.on('change', function() { self.setCERTDisplay() });
            } else {
                self.setCERTDisplay();
            }
        }
    },
    setCERTDisplay: function() {
        var self = this;
        var $CERT_NUM = $('#CERT_NUM');
        var vacPos = $('#CERT_NUM :selected').data('position');
        var certPos = $('#CERT_NUM :selected').data('cert');
        var cert = self.certificates[vacPos][certPos];

        $('#CERT_TYPE').val(cert.CERT_TYPE);
        $('#CERT_AUDIT_COMP').val(self.formatDisplayDate(cert.CERT_AUDIT));
        $('#DATE_CERT_ISS').val(self.formatDisplayDate(cert.CERT_ISSUED));
        $('#DATE_CERT_SENT_SO').val(self.formatDisplayDate(cert.CERT_SENT_SO));
        $('#DATE_CERT_DUE').val(self.formatDisplayDate(cert.CERT_DUE));
        $('#CERT_POS_TITLE').val(cert.POS_TITLE);
        $('#CERT_PAY_PLAN').val(cert.PAY_SERIES_GRADE);

        self.setApplicantsDisplay();

    },
    setApplicantsDisplay: function() {
        var self = this;
        var $CERT_NUM = $('#CERT_NUM :selected');
        var vacPos = $('#CERT_NUM :selected').data('position');
        var apps = self.applicants[vacPos];
        var $tblBody = $('#applicantDisplay tbody');
        $tblBody.empty();
        console.log(apps);
        for (var a = 0; a < apps.length; a++) {
            if (apps[a].CERT_NUM === $CERT_NUM.val()) {
                var applicant = apps[a].APPLICANTS
                for (var x = 0; x < applicant.length; x++) {
                    $tblBody.append('<tr><td>' + applicant[x].APPLICANT_NAME + '</td><td>' + applicant[x].AUDIT_CODE + '</td><td>' + applicant[x].SELECTEE_REQ_NUM + '</td><td>Action</td></tr>');
                }

            }
        }


    },
    clearPage: function() {
        var self = this;

        $('#VAN').val('');
        $('#CERT_ANN_TYPE').val('');
        $('#VACANCY_STATUS').val();
        $('#TOT_NUM_APP').val('');
        $('#TOT_QUAL_APP').val('');
        $('#TOT_REF_APP').val('');
        $('#APP_NOTIFIED_DATE').val('');

        $('#NOTIFY_QUAL_STAT').val('');

        $('#SEL_MADE').val('');
        $('#ACT_TAKEN').val('');
        $('#HIRE_ACTION').val('');
        $('#HIRE_DEC_HR').val('');
        $('#CERT_NUM').empty().append('<option value="">Select a VIN to load Certificates</option>');
        self.clearCertData();
    },
    clearCertData: function() {

        $('#CERT_TYPE').val('');
        $('#CERT_AUDIT_COMP').val('');
        $('#DATE_CERT_ISS').val('');
        $('#DATE_CERT_SENT_SO').val('');
        $('#DATE_CERT_DUE').val('');
        $('#CERT_POS_TITLE').val('');
        $('#CERT_PAY_PLAN').val('');
    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        var self = this;

        self.setVacancyData();
        $('#USA_STAFFING').on('click', function(e) {
            e.preventDefault();
            var vin = $('#VIN').val();
            if (vin != '') {
                window.open('https://usastaffing.gov/staffing/vacancy/edit/' + vin, '_blank');
            }
        });
    }
}