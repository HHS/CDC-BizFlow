/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var aptTSAApp = {
    initSetupDone: false,
    //**Default values for First Load Fields */
    fields: [
        { name: 'PROCESSOR_APPROVAL', value: "" },
        { name: 'EOPF_APPROVAL', value: false },
        { name: 'QUALITY_APPROVAL', value: false },
        { name: 'PROCESSOR_NAME_APPROVAL', value: "" },
        { name: 'PROCESSOR_DATE_APPROVAL', value: "" },
        { name: 'LEAD_PROCESSOR_NEEDED', firstvalue: true },
        { name: 'LEAD_PROCESSOR', value: "" },
        { name: 'LEAD_PROCESSOR_EMAIL', value: "" },
        { name: 'LEAD_PROCESSOR_APPROVAL', value: "" },
        { name: 'LEAD_PROCESSOR_NAME_APPROVAL', value: "" },
        { name: 'LEAD_PROCESSOR_DATE_APPROVAL', value: "" }


    ],
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        var curActivity = $('#curActivity').val();
        if (fieldState) {
            switch (field) {
                case "PROCESSOR_APPROVAL":
                    var PROCAppDate = new Date();
                    var CK_PROCESSOR_APPROVAL = (FormState.getState('PROCESSOR_APPROVAL')) ? FormState.getState('PROCESSOR_APPROVAL').value : false;
                    if (curActivity === 'Complete TSA Processing') {
                        if (CK_PROCESSOR_APPROVAL) {
                            FormState.doAction(StateAction.changeText('PROCESSOR_NAME_APPROVAL', $('#current_user_name').val() + "/" + $('#current_user_title').val()), false);
                            FormState.doAction(StateAction.changeText('PROCESSOR_DATE_APPROVAL', ('0' + (PROCAppDate.getMonth() + 1)).slice(-2) + '/' + ('0' + PROCAppDate.getDate()).slice(-2) + '/' + PROCAppDate.getFullYear()), false);

                        } else {
                            FormState.doAction(StateAction.changeText('PROCESSOR_NAME_APPROVAL', ''), false);
                            FormState.doAction(StateAction.changeText('PROCESSOR_DATE_APPROVAL', ''), false);
                        }
                    }
                    break;
                case "LEAD_PROCESSOR_APPROVAL":
                    var PROCAppDate = new Date();
                    var CK_PROCESSOR_APPROVAL = (FormState.getState('LEAD_PROCESSOR_APPROVAL')) ? FormState.getState('LEAD_PROCESSOR_APPROVAL').value : false;
                    if (curActivity !== 'Complete TSA Processing') {
                        if (CK_PROCESSOR_APPROVAL) {
                            FormState.doAction(StateAction.changeText('LEAD_PROCESSOR_NAME_APPROVAL', $('#current_user_name').val() + "/" + $('#current_user_title').val()), false);
                            FormState.doAction(StateAction.changeText('LEAD_PROCESSOR_DATE_APPROVAL', ('0' + (PROCAppDate.getMonth() + 1)).slice(-2) + '/' + ('0' + PROCAppDate.getDate()).slice(-2) + '/' + PROCAppDate.getFullYear()), false);

                        } else {
                            FormState.doAction(StateAction.changeText('LEAD_PROCESSOR_NAME_APPROVAL', ''), false);
                            FormState.doAction(StateAction.changeText('LEAD_PROCESSOR_DATE_APPROVAL', ''), false);
                        }
                    }
                    break;
            }
        }
    },
    renderer: function() {
        var self = this;
        var curActivity = $('#curActivity').val();
        self.actionOnChange('PROCESSOR_APPROVAL');
        self.actionOnChange('LEAD_PROCESSOR_APPROVAL');
        if (!self.initSetupDone) {
            if (curActivity !== 'Complete TSA Processing') {
                $('#LEAD_PROCESSOR_ROW_1').removeClass('hidden');
                $('#LEAD_PROCESSOR_ROW_2').removeClass('hidden');
                CDCCommon.showField('LEAD_PROCESSOR_NAME_APPROVAL', true);
                CDCCommon.showField('LEAD_PROCESSOR_DATE_APPROVAL', true);
                $('#PROCESSOR_APPROVAL').addClass('disabled').attr('disabled', 'disabled').attr('readonly', 'readonly').parent().addClass('isDisabled');
                $('#LEAD_PROCESSOR').addClass('disabled').attr('disabled', 'disabled').attr('readonly', 'readonly').parent().addClass('isDisabled');

            } else {
                $('#LEAD_PROCESSOR_ROW_1').addClass('hidden');
                $('#LEAD_PROCESSOR_ROW_2').addClass('hidden');
                CDCCommon.hideField('LEAD_PROCESSOR_NAME_APPROVAL', true);
                CDCCommon.hideField('LEAD_PROCESSOR_DATE_APPROVAL', true);
            }
            self.initSetupDone = true;
        }

    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        CDCCommon.setAutoComplete('TSA_APP_GRID', this.mappers, this.reduxBindFix);
    },
    mappers: {

        LEAD_PROCESSOR: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text(),
                PVMID: $('PVMID', this).text()
            }
        }
    },
    reduxBindFix: function() {
        if (!$(this).data('autocomplete')) {
            FormState.doAction(StateAction.changeText($(this).attr('id'), $(this).val()), false);
        }
    }

}