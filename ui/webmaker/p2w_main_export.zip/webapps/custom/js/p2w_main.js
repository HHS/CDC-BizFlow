/* global $ TabManager BFUtility BFActivityOption BFLog FormState StateAction bootbox hyf LookupManager p2wGen _ */

var p2wMain = {

    //TAEHO 05/31/2018 to store initial form data, it will be used to compare form data when user exits the form.
    initialXML: "",

    CONST_ALL_FORM_READONLY_FALSE: false,
    CONST_ALL_FORM_READONLY_TRUE: true,

    activityList: [{
        name: 'Identify Staffing Need',
        usergroup: [],
        tabs: ['tab1', 'tab8', 'tab9', 'tab10'],
        readonly: []
    }, {
        name: 'Prepare Pre-Recruitment Documents',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab8', 'tab9', 'tab10'],
        readonly: []
    }, {
        name: 'Finalize the Pre-Recruitment Checklist',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab8', 'tab9', 'tab10'],
        readonly: []
    }, {
        name: 'Validate Recruitment',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab8', 'tab9', 'tab10'],
        readonly: []
    }, {
        name: 'Track USA Staffing Status',
        usergroup: [],
        tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab8', 'tab9', 'tab10'],
        readonly: ['tab1', 'tab2', 'tab3', 'tab4']
    }],

    tabList: [{
        id: 'tab1',
        targetUrl: '/p2w_general/general.do',
        targetGroup: 'partial_tab1',
        name: 'General',
        loaded: false,
        completed: false,
        disabledHeader: false,
        postEnableTab: function() {
            if (p2wGen.postEnableTab !== undefined) {
                p2wGen.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (p2wGen.postDisableTab !== undefined) {
                p2wGen.postDisableTab();
            }
        },
        postClearTabContents: function () {
            // $('#RI_OA_APRV_ITEM').val('NA');
        },
        renderer: function () {
            p2wGen.renderer();            
        },
        mainContainer: function() {
            return p2wMain;  //Taeho 03/08/2018 - Section 508 friendly error message if defied in each tab.
        }
        // onInit: function() {
        // }
    }, {
        id: 'tab2',
        targetUrl: '/p2w_position/position.do',
        targetGroup: 'partial_tab2',
        name: 'Documents',
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function () {
            return true;
        },
        postEnableTab: function() {
            if (p2wPosition.postEnableTab !== undefined) {
                p2wPosition.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (p2wPosition.postDisableTab !== undefined) {
                p2wPosition.postDisableTab(p2wMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function () {
            p2wPosition.renderer();
        },
        mainContainer: function() {
            return p2wMain;  //Taeho 03/08/2018 - Section 508 friendly error message if defied in each tab.
        }

    }, {
        id: 'tab3',
        targetUrl: '/p2w_conditions/conditions.do',
        targetGroup: 'partial_tab3',
        name: 'Conditions of Emp',
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function () {
            return true;
        },
        postEnableTab: function() {
            if (p2wConditions.postEnableTab !== undefined) {
                p2wConditions.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (p2wConditions.postDisableTab !== undefined) {
                p2wConditions.postDisableTab(p2wMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function () {
            p2wConditions.renderer();
        },
        mainContainer: function() {
            return p2wMain;  //Taeho 03/08/2018 - Section 508 friendly error message if defied in each tab.
        }
    },{
        id: 'tab4',
        targetUrl: '/p2w_validation/validation.do',
        targetGroup: 'partial_tab4',
        name: 'Validation',
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function () {
            return true;
        },
        postEnableTab: function() {
            if (p2wVld.postEnableTab !== undefined) {
                p2wVld.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (p2wVld.postDisableTab !== undefined) {
                p2wVld.postDisableTab(p2wMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function () {
            p2wVld.renderer();
        },
        mainContainer: function() {
            return p2wMain;  //Taeho 03/08/2018 - Section 508 friendly error message if defied in each tab.
        }
    },{
        id: 'tab5',
        targetUrl: '/p2w_vacancy/vacancy.do',
        targetGroup: 'partial_tab5',
        name: 'Vacancy Info',
        loaded: false,
        completed: false,
        disabledHeader: false,
        validator: function () {
            return true;
        },
        postEnableTab: function() {
            if (p2wVac.postEnableTab !== undefined) {
                p2wVac.postEnableTab();
            }
        },
        postDisableTab: function() {
            if (p2wVac.postDisableTab !== undefined) {
                p2wVac.postDisableTab(p2wMain.CONST_ALL_FORM_READONLY_FALSE);
            }
        },
        renderer: function () {
            p2wVac.renderer();
        },
        mainContainer: function() {
            return p2wMain;  //Taeho 03/08/2018 - Section 508 friendly error message if defied in each tab.
        }
    },{
        id: 'tab8',
        targetUrl: '/p2w_resources/resources.do',
        targetGroup: 'partial_tab8',
        name: 'Resources',
        loaded: false,
        completed: false,
        disabledHeader: false,
        renderer: function () {
            p2wResources.renderer();            
        },
        mainContainer: function() {
            return p2wMain;  //Taeho 03/08/2018 - Section 508 friendly error message if defied in each tab.
        }
    }, {
        id: 'tab9',
        targetUrl: '/p2w_common/showAttachment.do',
        targetGroup: 'partial_tab9',
        name: 'Documents',
        loaded: false,
        completed: false,
        disabledHeader: false
    }, {
        id: 'tab10',
        targetUrl: '/p2w_common/showComment.do?proctype=Recruitment',
        targetGroup: 'partial_tab10',
        name: 'Notes',
        loaded: false,
        completed: false,
        disabledHeader: false
    }],

    initBasedOnActivity: function () {
        if (BFUtility.isReadOnly() === true) {
            $('#bottomSection').hide();
            $('#layout_TabPreviousNext').hide();
            if (p2wGen.postDisableTab !== undefined) {
                p2wGen.postDisableTab(p2wMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (p2wPosition.postDisableTab !== undefined) {
                p2wPosition.postDisableTab(p2wMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (p2wConditions.postDisableTab !== undefined) {
                p2wConditions.postDisableTab(p2wMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (p2wVld.postDisableTab !== undefined) {
                p2wVld.postDisableTab(p2wMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            if (p2wVac.postDisableTab !== undefined) {
                p2wVac.postDisableTab(p2wMain.CONST_ALL_FORM_READONLY_TRUE);
            }
            return;
        }

        BFLog.log('DEBUG', 'p2wMain - initBasedOnActivity - START');

        var activityName = BFActivityOption.getActivityName();
        if (activityName === 'Identify Staffing Need') {
            $('#actionButton_Activity1').removeClass('hide');
            $('#h_hardStopRequired').val('false');
            p2wMain.addButtonHandler('button_SendToAdminPOC', true, false, [{
                id: 'WIH_complete_requested', value: 'true'
            }]);
        }
        //else if (activityName === 'Prepare Pre-Recruitment Documents' || activityName === 'Schedule Pre-Recruitment Consultation'){ 
        else if (activityName === 'Prepare Pre-Recruitment Documents'){
            $('#actionButton_Activity2').removeClass('hide');
            $('#h_hardStopRequired').val('true');
            p2wMain.addButtonHandler('button_SendPrerecruitMeetingDocs', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, { 
        		id: 'pv_packageSubmissionDate', value: ''
            }]);
        }
        else if (activityName === 'Finalize the Pre-Recruitment Checklist'){
            $('#actionButton_Activity3').removeClass('hide');
            $('#h_hardStopRequired').val('true');
            p2wMain.addButtonHandler('button_Submit', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }]);
        }
        else if (activityName === 'Validate Recruitment'){ 
            $('#actionButton_Activity3').removeClass('hide');
            $('#h_hardStopRequired').val('true');
            p2wMain.addButtonHandler('button_Submit', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }]);
        }
        else if (activityName === 'Track USA Staffing Status'){
            $('#actionButton_Activity3').removeClass('hide');
            $('#h_hardStopRequired').val('true');
            $('#button_CancelWorkitem').hide();
            p2wMain.addButtonHandler('button_Submit', true, true, [{
                id: 'WIH_complete_requested', value: 'true'
            }]);
        }
        else {
             BFLog.log('DEBUG', 'p2wMAIN - initBasedOnActivity() - No activity name matched [' + activityName + ']');
        }
            
            
        //     if (BFUtility.isCurrentUserMemberOf('Selecting Officials') === true) {
        //         $('#button_cr_send_2').hide();
        //         p2wMain.addButtonHandler('button_cr_notify_2', true, [{
        //             id: 'WIH_complete_requested', value: 'true'
        //         }, {
        //             id: 'pv_requestStatus', value: 'Request Created'
        //         }, {
        //             id: 'pv_requestStatusDate', value: ''
        //         }, {
        //             id: 'pv_selectOfficialReviewReq', value: 'No'
        //         }]);
        //     } else {
        //         $('#button_cr_notify_2').hide();
        //         p2wMain.addButtonHandler('button_cr_send_2', true, [{
        //             id: 'WIH_complete_requested', value: 'true'
        //         }, {
        //             id: 'pv_requestStatus', value: 'Request Created'
        //         }, {
        //             id: 'pv_requestStatusDate', value: ''
        //         }, {
        //             id: 'pv_selectOfficialReviewReq', value: 'Yes'
        //         }]);
        //     }
        //     $('#actionButton_CreateRequest_2').removeClass('hide');
        // } else if (activityName === 'Activity 2') {
        //     p2wMain.addButtonHandler('button_rr_notify_2', true, [{
        //         id: 'WIH_complete_requested', value: 'true'
        //     }, {
        //         id: 'pv_requestStatusDate', value: ''
        //     }]);
        //     $('#actionButton_ReviewRequest_2').removeClass('hide');
        // } else {
        //     BFLog.log('DEBUG', 'STRATCONMAIN - initBasedOnActivity() - No activity name matched [' + activityName + ']');
        // }

        BFLog.log('DEBUG', 'p2wMain - initBasedOnActivity - END');
    },
    //addButtonHandler: function (buttonID, validationRequired, buttonOptions, confirmMessage) {
    addButtonHandler: function (buttonID, validationRequired, mandatoryDocValidationRequired, buttonOptions, confirmMessage) {
        if (buttonID != null && buttonOptions != null) {
            $('#' + buttonID).off('click').click(function () {
                if (validationRequired === true) {
                    var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
                    for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                        var validated = TabManager.validateTab(activeTabs[tabIndex]);
                        if (validated === false) {
                            return;
                        }
                    }

                    if (mandatoryDocValidationRequired === true) {
                    	var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
                        if (mandatoryDocumentsValid !== 'true') {
                            TabManager.enableTabHeader('tab9');
                            TabManager.enableTab('tab9');
                            $('#' + TabManager.getAnchorID('tab9')).click();
                            bootbox.alert('Please upload the missing required document(s).');
                            return;
                        }    
                    }                    
                }

                if (confirmMessage != null && confirmMessage.length > 0) {
                    bootbox.dialog({
                            message: '<p class="bootbox-body">' + confirmMessage + '</p>',
                            onEscape: true,
                            buttons: [{
                                label: 'Yes',
                                className: 'btn-success',
                                callback: function () {
                                    buttonOptions.forEach(function (option) {
                                        //if (option.id === 'pv_requestStatusDate') {
                                        if (option.id === 'pv_requestStatusDate' || option.id === 'pv_packageSubmissionDate') {
                                            option.value = BFUtility.getNowUTCString();
                                        }                                       
                                        $('#' + option.id).val(option.value);
                                    })
                                    BFUtility.greyOutScreen(true);
                                    var xml = FormState.getFinalStateXML();
                                    $('#h_formData').val(xml);
                                    BFUtility.submitFormPage(buttonID, 'saveNewForm');
                                }
                            }, {
                                label: 'No',
                                className: 'btn-danger'
                            }]
                        });
                } else {
                    buttonOptions.forEach(function (option) {
                        //if (option.id === 'pv_requestStatusDate') {
                        if (option.id === 'pv_requestStatusDate' || option.id === 'pv_packageSubmissionDate') {
                            option.value = BFUtility.getNowUTCString();
                        }
                        $('#' + option.id).val(option.value);
                    })
                    BFUtility.greyOutScreen(true);
                    var xml = FormState.getFinalStateXML();
                    $('#h_formData').val(xml);
                    BFUtility.submitFormPage(buttonID, 'saveNewForm');
                }
            });
        } else {
            BFLog.log('DEBUG', 'p2wMain - addButtonHandler() - buttonID or buttonOption is null.');
        }
    },
    
    // Request Type in General Tab
    resetRequestType: function () {
        var requestTypeLabel = $('#RT_ID option:selected').text();
        var requestTypeValue = $('#RT_ID option:selected').val();

        if (requestTypeValue !== '') {
            $('#requestType').text(requestTypeLabel);
        } else {
            $('#requestType').text('');
        }
        TabManager.resetTabs();
    },
    // This function will be called after getRequestNumber.do is completed.
    resetRequestNumber: function () {
        var requestNumber = $('#h_response_requestNumber').val();
        FormState.doAction(StateAction.changeVariable('requestNumber', requestNumber));
        $('#pv_requestStatus').val('Request Created');
        var requestedStatusDate = $('#h_now').val();
        $('#pv_requestStatusDate').val(requestedStatusDate);
    },
    loadForm: function () {
        var xml = $('#h_formData').val();
        FormState.initWithXML(p2wMain.renderer, xml);
        _.forEach(p2wMain.tabList, function (tab) {
            if (typeof tab.renderer === 'function') {
                FormState.addRenderer(tab.renderer);
            }
        });        
        
        FormState.doRender();
    },

    onAllTabLoaded: function () {
        BFLog.log('DEBUG', 'Received HHS_ALL_TAB_LOADED!');

        //
        // Code to remove certain tab based on certain condition.
        //
        // TabManager.clearTabContent(tabID);
        // TabManager.hideTabHeader(tabID);
        // BFActivityOption.removeTabFromCurrentActivity(activityName, tabID);

        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);
        BFUtility.initMaxSize(tabs);
        BFUtility.setDateIconTabOrder(tabs);

        p2wMain.showHidePreNextButtons();
        $(document).on('ON_TAB_CHANGE', p2wMain.onTabChange);

        //TAEHO 05/31/2018 #161528 -store form data when form is loaded, it will be use to check if form is changed when user exits the form.
        setTimeout(p2wMain.storeInitialXML, 1000);
    },
       
    //TAEHO 05/31/2018 #161528 -store form data when form is loaded, it will be use to check if form is changed when user exits the form.
    storeInitialXML: function() {
        initialXML = FormState.getFinalStateXML();
    },

    onTabChange: function () {
        if (BFUtility.isReadOnly() === false) {
            // var requestNumber = FormState.getState('requestNumber');
            // if (typeof requestNumber === 'undefined' || requestNumber.value == null  requestNumber.value.length === 0) {
            //     $('#h_now').val(BFUtility.getNowUTCString());
            //     BFUtility.callPartialPage(null, 'getRequestNumber.do', 'system', 'layoutForResponse');
            // };

            //var activityName = BFActivityOption.getActivityName();
            //var memberID = $('#h_currentUserMemberID').val();
            //var memberName = $('#h_currentUserName').val();
            //var xml = FormState.getFinalStateXML(activityName, memberID, memberName);
            var xml = FormState.getFinalStateXML();
            $('#h_formData').val(xml);

            BFUtility.callPartialPage(null, 'saveTabContent.do', null, 'layoutForResponse2');
        }

        p2wMain.showHidePreNextButtons();
    },

    renderer: function () {
        // var requestNumber = FormState.getState('requestNumber');
        // if (requestNumber && requestNumber.value && requestNumber.dirty === true) {
        //     $('#requestNumber').text(requestNumber.value);
        // }
    },

    showHidePreNextButtons: function () {
        var selectedTabID = TabManager.getSelectedTabID();
        var activeTabs = BFActivityOption.getTabList();

        var currentTabIndex = 0;
        for (var index = 0; index < activeTabs.length; index++) {
            if (activeTabs[index] === selectedTabID) {
                currentTabIndex = index;
                break;
            }
        }

        if (currentTabIndex === 0) {
            hyf.util.disableComponent('button_Previous');
            hyf.util.enableComponent('button_Next');
        } else if (currentTabIndex === activeTabs.length - 1) {
            hyf.util.enableComponent('button_Previous');
            hyf.util.disableComponent('button_Next');
        } else {
            BFUtility.enableComponents(['button_Previous', 'button_Next'])
        }
    },
    saveForm: function (e) {
		$('#h_currentTabID').val(TabManager.getSelectedTabID()); // store current tabid to reset after page reload
        // var activityName = BFActivityOption.getActivityName();
        // var memberID = $('#h_currentUserMemberID').val();
        // var memberName = $('#h_currentUserName').val();
        var xml = FormState.getFinalStateXML();

        $('#h_formData').val(xml);
        BFUtility.saveForm(e);
    },
    exitForm: function (btnId){        
        //TAEHO 05/31/2018 customize WIH exit message
        var xml = FormState.getFinalStateXML();
        var isFormChangedAfterLoaded = false;
        if (initialXML === xml || initialXML === "") {
            basicWIHActionClient.exit({confirmMsg: null,
                            eventFn: function(){return true}});
        } else {
            basicWIHActionClient.exit({confirmMsg: "Are you sure you want to quit without saving?",
                            eventFn: function(){return true}});
        }        
        //BFUtility.exitWitemHandler(btnId);
    },
    cancelForm: function (btnId) {
        var reasons = LookupManager.findByLTYPE('CancellationReason');
        var options = '<option value>Select one</option>';
		reasons.forEach(function(reason) {
			options = options + '<option value=' + reason.LABEL + '>' + reason.LABEL + '</option>';
        });
        
        var dialog = bootbox.dialog({
			title: 'Reason for Cancellation',
			message: '<span>Cancellation Reason</span><span class="mandatory" style="" title="Mandatory field"> * </span><span>:&nbsp;</span><select name="CancellationReason">' + options + '</select>',
			onEscape: true,
			buttons: {
				confirm: {
					label: 'OK',
					className: 'btn-success',
					callback: function() {
						var message = $('div.bootbox select option:selected').text();
						if (message == null || message.length == 0) {
							return false;
						}

						setTimeout(function() {
							BFUtility.greyOutScreen(true);							
							$('#WIH_complete_requested').val('true');
							$('#pv_requestStatus').val('Request Cancelled');							
							$('#pv_CancelReason').val(message);
							BFUtility.submitFormPage(btnId, 'saveNewForm');
						}, 0);
					}
				},
				cancel: {
					label: 'Cancel',
					className: 'btn-danger'
				}
			}
        });
        
        $('div.bootbox button.btn-success').prop('disabled', true);

		$('div.bootbox select').on('change keyup', function() {
			var message = $('div.bootbox select option:selected').val();
			if (message == '') {
				$('div.bootbox button.btn-success').prop('disabled', true);
			} else {
				$('div.bootbox button.btn-success').prop('disabled', false);
			}
		});
    },
    restoreBizFlowParameter: function() {
        var sessionInfo = $('#sessioninfo').attr('value');
        if (sessionInfo != null && sessionInfo.length > 0) {         // Backup
            $('#sessioninfo2').attr('value', $('#sessioninfo').attr('value'));
            $('#procid2').attr('value', $('#procid').attr('value'));
            $('#actseq2').attr('value', $('#actseq').attr('value'));
            $('#workseq2').attr('value', $('#workseq').attr('value'));
            $('#appseq2').attr('value', $('#appseq').attr('value'));
            $('#isarchive2').attr('value', $('#isarchive').attr('value'));
            $('#readOnly2').attr('value', $('#readOnly').attr('value'));
        } else { // Restore
            $('#sessioninfo').attr('value', $('#sessioninfo2').attr('value'));
            $('#procid').attr('value', $('#procid2').attr('value'));
            $('#actseq').attr('value', $('#actseq2').attr('value'));
            $('#workseq').attr('value', $('#workseq2').attr('value'));
            $('#appseq').attr('value', $('#appseq2').attr('value'));
            $('#isarchive').attr('value', $('#isarchive2').attr('value'));
            $('#readOnly').attr('value', $('#readOnly2').attr('value'));
        }
    },

    errorMsg: function(tab){
        var cnt = 0;
        var $errList = $('#errlist-' + tab);
        var $errCnt = $('#errcnt-' + tab);
        if($errList.length > 0){
            $errList.empty();
            $errCnt.text();
            $('span.hasError').each(function(key, value) {
                if (typeof $(":first-child", this).data('wm-error-msg') != 'undefined') { //Taeho 03/08/2018 - skip 'undefined' items.
                    cnt++;
                    $errList.append("<li>" + $(":first-child", this).data('wm-error-msg') + "</li>");    
                }
            });
            if (cnt > 0) {
                $errCnt.text('There are ' + cnt + ' errors on the form.');
                $('#reqmsg-' + tab).focus()
            }
        }
    },

    //
    // Main ENTRY POINT
    //
    init: function () {
        BFLog.setLogLevel('DEBUG');
        BFLog.log('DEBUG', 'p2wMain - init START');

        BFActivityOption.init(p2wMain.activityList);

        var activityName = BFActivityOption.getActivityName();

        if (BFUtility.isReadOnly() === true) {
            var readonlyTabs = ['tab1', 'tab2', 'tab3'];
            BFActivityOption.setReadOnlyTabList(activityName, readonlyTabs);
        }

        LookupManager.init();
        // In order to send the BizFlow parameters to tab projects so that they can use the workitem context
		p2wMain.restoreBizFlowParameter();

        TabManager.initTab(p2wMain.tabList, p2wMain.loadForm);
        $(document).on('HHS_ALL_TAB_LOADED', p2wMain.onAllTabLoaded);

        //--------------------------------
        // static button event handler
		//----------------------------------------
		// save
        $('#button_SaveWorkitem').on('click', p2wMain.saveForm);

        // Exit
        $('#button_ExitWIH').on('click', (function(){
            p2wMain.exitForm('button_ExitWIH');
        }).bind(this));

        // Cancel
        $('#button_CancelWorkitem').on('click', (function(){
            p2wMain.cancelForm('button_CancelWorkitem');
        }).bind(this));

        // Previous
        $('#button_Previous').off('click').click(function (e) {
            TabManager.loadPreviousTab();
        });

        // Next
        $('#button_Next').off('click').click(function (e) {
            TabManager.loadNextTab();
        });

        // Request Date
        var requestedDateString = $('#h_creationdate').val();
        if (requestedDateString != null && requestedDateString.length > 0) {
            var requestedDate = new Date(requestedDateString); // requestedDateString is GMT
            var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
            var requestedDateLabel = BFUtility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, newDate);
            $('#initiatedDate').text(requestedDateLabel);
        }

        // // Request Number
        // var requestNumber = $('#h_requestNumber').val();
        // $('#requestNumber').text(requestNumber);

        // // Request Status
        // var requestStatus = $('#pv_requestStatus').val();
        // $('#output_requestStatus').text(requestStatus);

        hyf.util.disableComponent('button_Previous');
        hyf.util.enableComponent('button_Next');

        p2wMain.initBasedOnActivity();

        // set focus on the current tab
        $('a.selectedTab').focus();

        // For section 508 compliant date picker icon
        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });

        //TAEHO #164173 - Remove Attachment section in left-hand pane
        var ui = basicWIHActionClient.getUI();
        ui.getPane(ui.PANE_ATTACHMENT).hide();

        if ($("#WIH_complete_requested").val() === "true") {
            if (activityName === 'Prepare Pre-Recruitment Documents'
                || activityName === 'Finalize the Pre-Recruitment Checklist') {
                try {
                        p2wMain.generateFiles();
                } catch (e) {
                    alert("Pre-Recruitment Checklist generation error " + e);
                }
            }
        }

        p2wMain.overwriteWIHCommentButtonEventHandlers();

        BFLog.log('DEBUG', 'p2wMain - init END');
    },

    generateFiles: function() {
    
        console.log("generateFiles...");

        var item = basicWIHActionClient.getWorkitemContext();            
        var xml = $('#h_formData').val();
        FormState.initWithXML(p2wMain.renderer, xml); //initialize formstate to access field values below

        var fdata = {
                        processid: item.Process.ID,
                        activityid: item.Activity.Sequence,
                        workitemseq: item.Workitem.Sequence,
        }

        var activityName = BFActivityOption.getActivityName();

        console.log("generateFiles... generating ATC file(s) when to complete the workitem");
        $.ajax({
                    type: 'POST',
                    url: '/bizflow/solutions/hhs/cdc/generate_prc.jsp',
                    data: fdata,
                    dataType: 'json',
                    cache: false,
                    success: function (response) {
                    }
                });
    },

    //Taeho
    addCommentEx: function() {
        try {
            window.parent.wihDiscussion.add();
            $("#btnRefreshComments").click();
        } catch (e) {
            console.log(e);
        }
    },

    //Taeho
    deleteCommentEx: function(procid, commentid) {
        try {
            var CONFIRM_DELETE_COMMENT = "Click OK to delete, or Cancel";
            if (confirm(CONFIRM_DELETE_COMMENT)) {
                window.parent.wihDiscussion.remove(procid, commentid);
            }
            $("#btnRefreshComments").click();
        } catch (e) {
            console.log(e);
        }
    },

    //Taeho
    modifyCommentEx: function() {
        try {
            var currentCommentProcID = window.parent.currentCommentProcID;
            var currentCommentID = window.parent.currentCommentID;
            window.parent.wihDiscussion.modify(currentCommentProcID, currentCommentID);
            $("#btnRefreshComments").click();
        } catch (e) {
            console.log(e);
        }
    },

    //Taeho
    overwriteWIHCommentButtonEventHandlers: function() {
        var old_addComment;
        if (typeof window.parent.addComment != "undefined") {
            old_addComment = window.parent.addComment;
            window.parent.addComment = p2wMain.addCommentEx;
        }

        var old_deleteComment;
        if (typeof window.parent.deleteComment != "undefined") {
            old_deleteComment = window.parent.deleteComment;
            window.parent.deleteComment = p2wMain.deleteCommentEx;
        }

        var old_modifyComment;
        if (typeof window.parent.modifyComment != "undefined") {
            old_modifyComment = window.parent.modifyComment;
            window.parent.modifyComment = p2wMain.modifyCommentEx;
        }
    }
}
