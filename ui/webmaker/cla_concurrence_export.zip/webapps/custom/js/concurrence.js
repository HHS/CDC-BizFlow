/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var claCon = {
    checkField: {
        name: 'concInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
        { name: 'CERT_IMMEDIATE_SUP', value: false },
        { name: 'CERT_IMMEDIATE_SUP_NAME', value: "" },
        { name: 'CERT_IMMEDIATE_SUP_DATE_BFDATE', value: "" },
        { name: 'CERT_IMMEDIATE_SUP_DATE', value: "" },
        { name: 'HIGHER_SUP_NEEDED', firstValue: true },
        { name: 'HIGHER_SUP_REQUEST', value: "" },
        { name: 'HIGHER_SUP_EMAIL', value: "" },
        { name: 'CERT_HIGHER_SUP', value: "" },
        { name: 'CERT_HIGHER_SUP_NAME', value: "" },
        { name: 'CERT_HIGHER_SUP_DATE_BFDATE', value: "" },
        { name: 'CERT_HIGHER_SUP_DATE', value: "" },
        { name: 'CERT_CLASS', value: "" },
        { name: 'CERT_CLASS_NAME', value: "" },
        { name: 'CERT_CLASS_DATE_BFDATE', value: "" },
        { name: 'CERT_CLASS_DATE', value: "" }
    ],
    renderer: function() {
        var self = this;

        CDCCommon.setupFirstLoad(self.checkField, self.fields);
        self.actionOnChange('CERT_IMMEDIATE_SUP');
        self.actionOnChange('CERT_HIGHER_SUP');
        self.actionOnChange('CERT_CLASS');
        self.actionOnChange('HIGHER_SUP_REQUEST_PART_ID');
        self.actionOnChange('HIGHER_SUP_NEEDED');
        self.actionOnChange('HIGHER_SUP_REQUEST');
    },
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        var curActivity = $('#curActivity').val();
        if (fieldState && fieldState.dirty === true) {
            switch (field) {
                case "CERT_IMMEDIATE_SUP":
                    if (curActivity === 'Provide Concurrence on Classification') {
                        var certDate = new Date();
                        if (fieldState.value.toString() === "true") {
                            FormState.doAction(StateAction.changeText(field + '_NAME', $('#current_user_name').val() + "/" + $('#current_user_title').val()), false);
                            FormState.doAction(StateAction.changeText(field + '_PART_ID', $('#current_user_memberid').val()), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE_BFDATE', Date.now()), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE', ('0' + (certDate.getMonth() + 1)).slice(-2) + '/' + ('0' + certDate.getDate()).slice(-2) + '/' + certDate.getFullYear()), false);

                        } else {
                            FormState.doAction(StateAction.changeText(field + '_NAME', ''), false);
                            FormState.doAction(StateAction.changeText(field + '_PART_ID', ''), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE_BFDATE', ''), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE', ''), false);
                        }
                    }
                    break;
                case "CERT_HIGHER_SUP":
                    if (curActivity === 'Provide Additional Concurrence on Classification') {
                        var certDate = new Date();
                        if (fieldState.value.toString() === "true") {
                            FormState.doAction(StateAction.changeText(field + '_NAME', $('#current_user_name').val() + "/" + $('#current_user_title').val()), false);
                            FormState.doAction(StateAction.changeText(field + '_PART_ID', $('#current_user_memberid').val()), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE_BFDATE', Date.now()), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE', ('0' + (certDate.getMonth() + 1)).slice(-2) + '/' + ('0' + certDate.getDate()).slice(-2) + '/' + certDate.getFullYear()), false);

                        } else {
                            FormState.doAction(StateAction.changeText(field + '_NAME', ''), false);
                            FormState.doAction(StateAction.changeText(field + '_PART_ID', ''), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE_BFDATE', ''), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE', ''), false);
                        }
                    }
                    break;
                case "CERT_CLASS":
                    if (curActivity === 'Finalize Classification') {
                        var certDate = new Date();
                        if (fieldState.value.toString() === "true") {
                            FormState.doAction(StateAction.changeText(field + '_NAME', $('#current_user_name').val() + "/" + $('#current_user_title').val()), false);
                            FormState.doAction(StateAction.changeText(field + '_PART_ID', $('#current_user_memberid').val()), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE_BFDATE', Date.now()), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE', ('0' + (certDate.getMonth() + 1)).slice(-2) + '/' + ('0' + certDate.getDate()).slice(-2) + '/' + certDate.getFullYear()), false);

                        } else {
                            FormState.doAction(StateAction.changeText(field + '_NAME', ''), false);
                            FormState.doAction(StateAction.changeText(field + '_PART_ID', ''), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE_BFDATE', ''), false);
                            FormState.doAction(StateAction.changeText(field + '_DATE', ''), false);
                        }
                    }
                    break;
                case "HIGHER_SUP_REQUEST_PART_ID":
                    if ((fieldState.value).indexOf('[U]') < 0) {
                        FormState.doAction(StateAction.changeText(field, '[U]' + fieldState.value), false);
                    }
                    break;
                case "HIGHER_SUP_NEEDED":
                    if (fieldState.value === 'Yes') {
                        CDCCommon.showField('HIGHER_SUP_REQUEST', true);
                        CDCCommon.showField('HIGHER_SUP_EMAIL', true);

                    } else {
                        CDCCommon.hideField('HIGHER_SUP_REQUEST', true, '');
                        CDCCommon.hideField('HIGHER_SUP_EMAIL', true, '');                        
                        FormState.doAction(StateAction.changeText('HIGHER_SUP_REQUEST_PART_ID', ''), false);

                    }
                    break;
            }
        }
    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        CDCCommon.setAutoComplete('group_concurrence', this.mappers, this.reduxBindFix);
        this.manageDisplay();

    },
    manageDisplay: function() {
        var curActivity = $('#curActivity').val();

        $('#CERT_IMMEDIATE_SUP').attr('readonly', true).attr('disabled', true);
        $('#HIGHER_SUP_NEEDED').attr('readonly', true).attr('disabled', true);
        $('#HIGHER_SUP_REQUEST').attr('readonly', true).attr('disabled', true);
        $('#CERT_HIGHER_SUP').attr('readonly', true).attr('disabled', true).attr('required', false);
        $('#CERT_CLASS').attr('readonly', true).attr('disabled', true).attr('required', false);;
        if (curActivity === 'Provide Concurrence on Classification') {
            $('#CERT_IMMEDIATE_SUP').attr('readonly', false).attr('disabled', false);
            $('#HIGHER_SUP_NEEDED').attr('readonly', false).attr('disabled', false);
            $('#HIGHER_SUP_REQUEST').attr('readonly', false).attr('disabled', false);
            $('#HIGHER_SUP_GRD').addClass('hidden')
            $('#CLASS_GRD').addClass('hidden');
            $('#HIGHER_SUP_NEEDED').removeClass('lowOpacityNoCursor');
            $('#HIGHER_SUP_REQUEST').removeClass('lowOpacityNoCursor');						
        } else if (curActivity === 'Provide Additional Concurrence on Classification') {
            $('#CERT_HIGHER_SUP').attr('readonly', false).attr('disabled', false).attr('required', true);
            $('#CLASS_GRD').addClass('hidden');
            $('#HIGHER_SUP_NEEDED').addClass('lowOpacityNoCursor');
            $('#HIGHER_SUP_REQUEST').addClass('lowOpacityNoCursor');			
        } else if (curActivity === 'Finalize Classification') {
            if ($('#HIGHER_SUP_NEEDED').val() != 'Yes') {
                $('#HIGHER_SUP_GRD').addClass('hidden');
            }
            $('#CERT_CLASS').attr('readonly', false).attr('disabled', false).attr('required', true);
            $('#HIGHER_SUP_NEEDED').addClass('lowOpacityNoCursor');
            $('#HIGHER_SUP_REQUEST').addClass('lowOpacityNoCursor');			
        }
    },
    reworkClear: function() {
        FormState.doAction(StateAction.changeCheckbox('CERT_IMMEDIATE_SUP', false), false);
        FormState.doAction(StateAction.changeText('CERT_IMMEDIATE_SUP_NAME', ''), false);
        FormState.doAction(StateAction.changeText('CERT_IMMEDIATE_SUP_DATE_BFDATE'), '', false);
        FormState.doAction(StateAction.changeText('CERT_IMMEDIATE_SUP_DATE', ''), false);
        FormState.doAction(StateAction.changeSelect('HIGHER_SUP_NEEDED', ''), false);
        FormState.doAction(StateAction.changeText('HIGHER_SUP_REQUEST', ''), false);
        FormState.doAction(StateAction.changeText('HIGHER_SUP_EMAIL', ''), false);
        FormState.doAction(StateAction.changeCheckbox('CERT_HIGHER_SUP', false), false);
        FormState.doAction(StateAction.changeText('CERT_HIGHER_SUP_NAME'), '', false);
        FormState.doAction(StateAction.changeText('CERT_HIGHER_SUP_DATE_BFDATE'), '', false);
        FormState.doAction(StateAction.changeText('CERT_HIGHER_SUP_DATE', ''), false);
        FormState.doAction(StateAction.changeCheckbox('CERT_CLASS', false), false);
        FormState.doAction(StateAction.changeText('CERT_CLASS_NAME', ''), false);
        FormState.doAction(StateAction.changeText('CERT_CLASS_DATE_BFDATE', ''), false);
        FormState.doAction(StateAction.changeText('CERT_CLASS_DATE', ''), false);
    },
    mappers: {
        HIGHER_SUP_REQUEST: function() {
            return {
                MID: $("MID", this).text(),
                DSPNAME: $('DSPNAME', this).text(),
                DEPTNAME: $('DEPTNAME', this).text(),
                EMAIL: $('EMAIL', this).text()
            }
        }
    },
    reduxBindFix: function() {
        if (!$(this).data('autocomplete')) {
            FormState.doAction(StateAction.changeText($(this).attr('id'), $(this).val()), false);
        }
    }
}