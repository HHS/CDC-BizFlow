/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var aptGen = {
    initSetupDone: false,
    checkField: {
        name: 'genInitComplete',
        value: 'true'
    },
    //**Default values for First Load Fields */
    fields: [
        { name: 'REQUEST_TYPE', firstValue: true },
        { name: 'ADMIN_CD', value: "" },
        { name: 'HM_ID', firstValue: true },
        { name: 'ORG_NAME', value: "" },
        { name: 'NON_COMP_TYPE', firstValue: true },
        { name: 'SHRD_CERT', firstValue: true },
        { name: 'CERT_NUM', value: "" },
        { name: 'POS_AOC', firstValue: true },
        { name: 'STF_VAL', firstValue: true },        
        { name: 'FND_CONF', firstValue: true },
        { name: 'HIRE_GUIDE_REV', firstValue: true },
        { name: 'SLOT_REQ', firstValue: true },        
        { name: 'VAN', value: "" },        
        { name: 'JOB_REC_POS_NUM', value: "" },
        { name: 'PBMS_ID', value: "" },
        { name: 'SO_AutoComplete', value: "" },
        { name: 'SO_EMAIL', value: "" },
        { name: 'CIO_AutoComplete', value: "" },
        { name: 'CIO_EMAIL', value: "" },
        { name: 'HROS_AutoComplete', value: "" },
        { name: 'HROS_EMAIL', value: "" },
        { name: 'CLASS_SPEC_AutoComplete', value: "" },
        { name: 'CLASS_SPEC_EMAIL', value: "" },        
        { name: 'HROA_AutoComplete', value: "" },
        { name: 'HROA_EMAIL', value: "" },
        { name: 'STF_VAL_JUST', value: "" },
        { name: 'FND_CONF_JUST', value: "" },
        { name: 'HIRE_GUIDE_REV_JUST', value: "" },
        { name: 'SLOT_REQ_JUST', value: "" },
        { name: 'CAPHR_REMARKS', value: "" }        
    ],
    actionOnChange: function(field) {
        var self = this;
        var fieldState = field ? FormState.getState(field) : null;
        
        if( fieldState && fieldState.dirty ){
            switch (field) {
                /*case "ADMIN_CD":
                
                    var ajax_url = '/bizflowwebmaker/cdc_api/Organization.do?parentOrg=';

                        FormState.doAction(StateAction.changeText('ORG_NAME_LVL1', ''), false);
                        FormState.doAction(StateAction.changeText('ORG_NAME_LVL2', ''), false);
                        FormState.doAction(StateAction.changeText('ORG_NAME_LVL3', ''), false);
                        FormState.doAction(StateAction.changeText('ORG_NAME_LVL4', ''), false);
                        FormState.doAction(StateAction.changeText('ORG_NAME_LVL5', ''), false);

                        if(fieldState.value.length > 0 && $('#ADMIN_CD').val() !== "" && fieldState.value !== $('#ADMIN_CD').val()) { //Don't call AJAX if no change in $('#ADMIN_CD')
                            CDCCommon.ajaxCallXML(ajax_url + fieldState.value + '!')
                                .done(function(data) {
                                    var dataFromApi = $('record', data).map(function() {
                                        return {
                                            fldid: $("FLDID", this).text(),
                                            org_desc: $('ORG_DESC', this).text(),
                                            ac_admin_cd: $('AC_ADMIN_CD', this).text()
                                        };
                                    }).get();

                                    $.map(dataFromApi, function(item) {
                                        FormState.doAction(StateAction.changeText(item['fldid'], item['org_desc']), true);
                                        return null;
                                    });
                                });
                            
                        }
                        $('#pv_adminCode').val(fieldState.value);
                        var org_name = FormState.getState('ORG_NAME');
                        $('#pv_orgName').val(org_name.value);
                        
                    break;*/
                case "HM_ID":
                
                        var hiringMethod = FormState.getState('HM_ID');
                        var hiringMethodOptions = LookupManager.findByLTYPE('HireMethod');
                        var hm_id = $('#HM_ID');
                        if(self.initSetupDone !== true ){
                            hm_id.find('option').remove();
                            hm_id.append('<option value="">Select One</option>');
                            hiringMethodOptions.forEach(function(hm_idOption){
                                hm_id.append('<option value="' + hm_idOption.LABEL + '">' + hm_idOption.LABEL + '</option>');
                            });
                        }
                        var hmFieldState = FormState.getState('HM_ID');                     
                        if(self.initSetupDone === true ){
                            $('#HM_ID').val(fieldState.value);
                            hmFieldState.text = fieldState.value;
                            hmFieldState.value = fieldState.value;                    
                        } else {
                            if(hiringMethod && hiringMethod.value !==''){
                            $('#HM_ID').val(hiringMethod.value);
                            hmFieldState.text = hiringMethod.value;
                            hmFieldState.value = hiringMethod.value;                    
                                
                            }
                        }
                    
                        var reqType = FormState.getState('REQUEST_TYPE');
                        if ((reqType.value === 'Appointment Only' || reqType.value === 'Appointment with Classification') && fieldState.value === 'Title 5') {
                            CDCCommon.showField('NON_COMP_TYPE', true);                            
                        } else {
                            CDCCommon.hideField('NON_COMP_TYPE', true,'');                            
                        }
                        
                        if (fieldState.value === 'Title 42') {
                            CDCCommon.showField('SLOT_REQ', true);
                            var slotReq = FormState.getState('SLOT_REQ');
                            if(slotReq && slotReq.value === 'No'){
                                CDCCommon.showField('SLOT_REQ_JUST', true);
                            } else {
                                CDCCommon.hideField('SLOT_REQ_JUST', true,'');
                            }

                            var emplType = FormState.getState('EMPL_TYPE');
                            if(emplType && emplType.value === 'Non-FTE'){
                                CDCCommon.hideField('PBMS_ID', true,'');                                
                            } else {
                                CDCCommon.showField('PBMS_ID',false);
                            }

                        } else {
                            CDCCommon.hideField('SLOT_REQ', true,'');
                            CDCCommon.hideField('SLOT_REQ_JUST', true,'');
                            CDCCommon.showField('PBMS_ID',false);                            
                        }

                        if (fieldState.value === 'Title 5') {
                            CDCCommon.showField('HROA_AutoComplete', false);
                            CDCCommon.showField('HROA_EMAIL', false);                            
                        } else {
                            CDCCommon.hideField('HROA_AutoComplete', true,'');
                            CDCCommon.hideField('HROA_EMAIL', true,'');
                        }
                        $('#pv_hiringMethod').val(fieldState.value);
                        
                    break;
                    
                    /*
                case "POS_STATUS":
                        if (fieldState.value === 'Competitive') {
                            CDCCommon.showField('SHRD_CERT', true);
                            CDCCommon.showField('VAN', true);
                            CDCCommon.showField('CERT_NUM', true);
                            CDCCommon.showField('POS_AOC', true);
                            $('#SHRD_CERT_ROW_1').css('display','block');
                             
                            //$('#HM_ID option:not(:selected)').prop('disabled', true);
                            
                        } else {
                            CDCCommon.hideField('SHRD_CERT', true,'');
                            CDCCommon.hideField('VAN', true,'');
                            CDCCommon.hideField('CERT_NUM', true,'');
                            CDCCommon.hideField('POS_AOC', true,'');
                            $('#SHRD_CERT_ROW_1').css('display','none');
                            
                            //$('#HM_ID option:not(:selected)').prop('disabled', false);                            
                        }

                    break;*/
                case "REQUEST_TYPE":

                        var reqType = FormState.getState('REQUEST_TYPE');
                        var reqTypeOptions=LookupManager.findByLTYPE('RequestType_Appointment');
                        var reqTypeID = $('#REQUEST_TYPE');
                        if(self.initSetupDone === true ){
                            reqTypeID.find('option').remove();
                            reqTypeID.append('<option value="">Select One</option>');                        
                        }

                        reqTypeOptions.forEach(function(reqTypeOption){
                            reqTypeID.append('<option value="' + reqTypeOption.LABEL + '">' + reqTypeOption.LABEL + '</option>');
                        });
                        if(self.initSetupDone === true ){
                            $('#REQUEST_TYPE').val(fieldState.value);
                            reqType.value = fieldState.value;                        
                            reqType.text = fieldState.value;
                        } else {
                        }

                        CDCCommon.addRequired('HROS_AutoComplete');
                        CDCCommon.addRequired('HROS_EMAIL');
                        if (fieldState.value === 'Appointment Only') {
                            $('#HM_ID').removeClass('disabled').attr('disabled', false).attr('readonly', false).parent().removeClass('isDisabled');
                        } else {
                            $('#HM_ID').addClass('disabled').attr('disabled', true).attr('readonly', true).parent().addClass('isDisabled');                            
                        }
                        
                        if ((fieldState.value === 'Appointment Only' || fieldState.value === 'Appointment with Classification') && $('#HM_ID').val() === 'Title 5') {
                            CDCCommon.showField('NON_COMP_TYPE', true);                            
                        } else {
                            CDCCommon.hideField('NON_COMP_TYPE', true,'');                            
                        }

                        $('#pv_requestType').val(fieldState.value);

                    break;
                case "JOB_REC_POS_NUM":

                        $('#pv_jobRequestNumber').val(fieldState.value);

                    break;
                case "STF_VAL":
                
                        if (fieldState.value === 'No') {
                            CDCCommon.showField(field + "_JUST", true);
                        }
                        else {
                            CDCCommon.hideField(field + "_JUST", true, '');                         
                        }

                    break;
                case "FND_CONF":
                
                        if (fieldState.value === 'No') {
                            CDCCommon.showField(field + "_JUST", true);
                        }
                        else {
                            CDCCommon.hideField(field + "_JUST", true, '');
                        }

                    break;
                case "HIRE_GUIDE_REV": 
                
                        if (fieldState.value === 'No') {
                            CDCCommon.showField(field + "_JUST", true);
                        }
                        else {
                            CDCCommon.hideField(field + "_JUST", true, '');
                        }

                    break;
                case "SLOT_REQ": 

                        if (fieldState.value === 'No') {
                            CDCCommon.showField(field + "_JUST", true);                            
                        }
                        else {
                            CDCCommon.hideField(field + "_JUST", true, '');
                        }

                    break;
            } // end switch
	       } // end fieldState conditions check
    },
    renderer: function() {

        console.log('aptGen renderer Start');
        var self = this;
        CDCCommon.setupFirstLoad(self.checkField, self.fields);        
        
        self.actionOnChange('REQUEST_TYPE');
        self.actionOnChange('JOB_REC_POS_NUM');
        self.actionOnChange('HM_ID');
        self.actionOnChange('STF_VAL');        
        self.actionOnChange('FND_CONF');        
        self.actionOnChange('HIRE_GUIDE_REV');        
        self.actionOnChange('SLOT_REQ');

        //A temporary place for this code until the functionality, to start Appointment from Recruitment vacancy Info with USA Staffing data, is implemented
        CDCCommon.hideField('SHRD_CERT', true,'');
        CDCCommon.hideField('VAN', true,'');
        CDCCommon.hideField('CERT_NUM', true,'');
        CDCCommon.hideField('POS_AOC', true,'');
        $('#SHRD_CERT_ROW_1').css('display','none');
        
        if (!self.initSetupDone) self.initSetupDone = true;
        console.log('aptGen renderer End');   

    },
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function() {
        CDCCommon.setAutoComplete('group_general', this.mappers, this.reduxBindFix);

        $(document).on("click change keyup keypress keydown",".textbox.autoExpandTextarea",function() {
            CDCCommon.addCurrTextlengthStatus($(document.activeElement)); 
        });
                          
        $(document).on("focusout",".textbox.autoExpandTextarea",function() {
            CDCCommon.removeCurrTextlengthStatus();
        });
        
        /*$('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });*/
       
    },
    mappers: {

        ADMIN_CD: function() {
            return {
                AC_ADMIN_CD: $("AC_ADMIN_CD", this).text(),
                AC_ADMIN_CD_DESCR: $('AC_ADMIN_CD_DESCR', this).text()
            }
        },
        ORG_NAME: function() {
            return {
                AC_ADMIN_CD: $("AC_ADMIN_CD", this).text(),
                AC_ADMIN_CD_DESCR: $('AC_ADMIN_CD_DESCR', this).text()
            }
        },
        SO_AutoComplete: function() {
                return {
                    MID: $("MID", this).text(),
                    DSPNAME: $('DSPNAME', this).text(),
                    DEPTNAME: $('DEPTNAME', this).text(),
                    EMAIL: $('EMAIL', this).text(),
                    PVMID: $("PVMID", this).text()
                }
        },
        CIO_AutoComplete: function() {
                return {
                    MID: $("MID", this).text(),
                    DSPNAME: $('DSPNAME', this).text(),
                    DEPTNAME: $('DEPTNAME', this).text(),
                    EMAIL: $('EMAIL', this).text(),
                    PVMID: $("PVMID", this).text()                
                }
        },
        HROS_AutoComplete: function() {
                return {
                    MID: $("MID", this).text(),
                    DSPNAME: $('DSPNAME', this).text(),
                    DEPTNAME: $('DEPTNAME', this).text(),
                    EMAIL: $('EMAIL', this).text(),
                    PVMID: $("PVMID", this).text()
                }
        },
        CLASS_SPEC_AutoComplete: function() {
                return {
                    MID: $("MID", this).text(),
                    DSPNAME: $('DSPNAME', this).text(),
                    DEPTNAME: $('DEPTNAME', this).text(),
                    EMAIL: $('EMAIL', this).text(),
                    PVMID: $("PVMID", this).text()                
                }
        },
        HROA_AutoComplete: function() {
                return {
                    MID: $("MID", this).text(),
                    DSPNAME: $('DSPNAME', this).text(),
                    DEPTNAME: $('DEPTNAME', this).text(),
                    EMAIL: $('EMAIL', this).text(),
                    PVMID: $("PVMID", this).text()                
                }
        }

    },
    reduxBindFix: function() {
        if (!$(this).data('autocomplete')) {
            FormState.doAction(StateAction.changeText($(this).attr('id'), $(this).val()), false);
        }
    }

}