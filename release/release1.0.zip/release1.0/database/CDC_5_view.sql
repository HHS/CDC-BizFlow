------------------------------------------------------------------------------------------
--  Name	            : 	CDC_5_view.sql
--	Author				:	Taeho Lee <thee@bizflow.com>
--	
--	Project				:	HHS CDC HR Workflow Solution - EWITS 2.0
--	Purpose				:	Creating views in HHS_CDC_HR database schema
--	
--  Notes               :   Run on HHS_CDC_HR schema
--
-- 	WHEN		WHO			WHAT		
-- 	-----------	--------	-------------------------------------------------------
-- 	11/14/2018	THLEE		Created
------------------------------------------------------------------------------------------

-- Nothing to run at this point

