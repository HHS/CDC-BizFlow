

function mycustomaction(param) {

	//param
	//	param.bizcoveid

    //debugger;
    var items = getBizCoveComponent(param.bizcoveid).getSelectedItems();
    /*
		items[0]
			actname
			actseq
			bfindicator
			creationdtime
			deadlinedtime
			dirty
			dscpt
			id
			issurrogater [ T | F ]
			passwdflag
			priority
			proccreatorname
			procid
			procname
			reqpseq
			rowIndex
			state
			svrid
			uid
			witemseq
	*/
    if(items)
    {
	    if(1==items.length)
	    {
	        console.log(items[0]);
	        //TO-DO implment your business logic here
	        var msg = "The selected workitem information is " +
	        		"\nprocname=" + items[0].procname +
	        		"\nprocid=" + items[0].procid +
	        		"\nactname=" + items[0].actname +
	        		"\nactseq=" + items[0].actseq +
	        		"\nwitemseq=" + items[0].witemseq +
	        		"\nproccreatorname=" + items[0].proccreatorname +
	        		"\nstate=" + items[0].state +
	        		"\npriority=" + items[0].priority;
	        alert(msg);


	    }
	    else
	    {
			notify("More than one item cannot be selected for this action. Please select only one item.", "warn");
	    }
    }
    else
    {
			notify("In order to proceed with this action, please select at least one item.", "warn");
    }

}
//# sourceURL=custom-actions.js